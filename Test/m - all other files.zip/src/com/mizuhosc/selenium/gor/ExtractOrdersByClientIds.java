package com.mizuhosc.selenium.gor;

import com.mizuhosc.quattro.util.function.*;
import com.mizuhosc.selenium.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;

public class ExtractOrdersByClientIds
{
	private final List<String> _clientIds;
	
	public ExtractOrdersByClientIds(final List<String> clientIds)
	{
		_clientIds = clientIds;
	}
	
	public void extract(final int eventCountLimit, final int orderCountLimit) throws Exception
	{
		final String outputFolder = new SimpleDateFormat("yyyy-MM-dd_HHmmss").format(new Date());
		final File folder = new File(outputFolder);
		folder.mkdir();
		for(final String s: _clientIds)
		{
			final long clientId = Long.parseLong(s);
			try
			{
				_log(String.format("Extracting orders for client %d", clientId));
				final List<String> clientOrders = getOrdersToRepaly(clientId);
				final int count =
					new ExtractOrders(clientOrders, outputFolder + "/" + clientId + ".log")
						.extract(eventCountLimit, orderCountLimit)
						.size();
				_log(String.format("Extracted %d orders for client %d", count, clientId));
			}
			catch(final Exception e)
			{
				_log("Failed to extract order for client " + clientId);
				e.printStackTrace();
			}
		}
	}
	
	List<String> getOrdersToRepaly(final long clientId) throws Exception
	{
		final List<String> result = new LinkedList<>();
		try(
			final Connection conn = Configuration.SINGLETON.createConnection("OSPREY_DB");
			final PreparedStatement pstmt =
				conn.prepareStatement(
					"select GlobalOrderId from OspreyOrderClient where FixClientId= ? ");)
		
		{
			pstmt.setLong(1, clientId);
			try(final ResultSet rs = pstmt.executeQuery();)
			{
				while(rs.next())
				{
					result.add(rs.getString("GlobalOrderId"));
				}
			}
		}
		
		return result;
	}
	
	private static final ThreadLocal<SimpleDateFormat> _FORMAT = new ThreadLocal<SimpleDateFormat>()
	{
		
		@Override
		protected SimpleDateFormat initialValue()
		{
			return new SimpleDateFormat("HH:mm:ss");
		}
	};
	
	private static void _log(final String s)
	{
		System.out.println(_FORMAT.get().format(new Date()) + "\t" + s);
	}
	
	public static void main(final String[] args)
	{
		if(args.length < 3)
		{
			System.out.println("Usage: ExtractOrdersByClientIds <eventCount> <orderCount> <clinetID1> [clinetID2...]");
			return;
		}
		
		final int eventCountLimit = Result.attempt(() -> Integer.parseInt(args[0]))
			.getOptional()
			.orElseThrow(() -> new IllegalArgumentException("eventCount must be a number."));
		
		final int orderCountLimit = Result
			.attempt(() -> Integer.parseInt(args[1]))
			.getOptional()
			.orElseThrow(() -> new IllegalArgumentException("orderCount must be a number."));
		
		final List<String> clientIDs = Arrays.asList(Arrays.copyOfRange(args, 2, args.length));
		
		try
		{
			new ExtractOrdersByClientIds(clientIDs).extract(eventCountLimit, orderCountLimit);
		}
		catch(final Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
