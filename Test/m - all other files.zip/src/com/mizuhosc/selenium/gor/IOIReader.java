package com.mizuhosc.selenium.gor;

import com.mizuhosc.quattro.util.function.*;
import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.log.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.util.zip.*;
import javax.annotation.*;

public class IOIReader
{
	private final String _fileName;
	private final LinkedBlockingQueue<String> _msgs;
	private final Optional<Integer> _maxCount;
	private final Optional<String> _ioiBatchCancelStartTime;
	
	public IOIReader(final String fileName, final @Nullable String ioiBatchCancelStartTime)
	{
		_fileName = fileName;
		_msgs = new LinkedBlockingQueue<>();
		_maxCount =
			Optional
				.ofNullable(Configuration.SINGLETON.getProperty("FIX.IOI.replay.max.message.count"))
				.flatMap(Result.trivialise(Integer::parseInt));
		_ioiBatchCancelStartTime = Optional.ofNullable(ioiBatchCancelStartTime);
	}
	
	public void start()
	{
		new Thread(this::_read, "ULBridgeLogReader").start();
	}

	private void _read()
	{
		try(
			final FileInputStream fileInputStream = new FileInputStream(_fileName);
			final InputStream inputStream =
				_fileName.endsWith(".gz") ? new GZIPInputStream(fileInputStream) : fileInputStream;
			final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream)))
		{
			int count = 0;
			while(true)
			{
				final String line = reader.readLine();
				if(line == null)
				{
					break;
				}
				
				// Filter out non FIX message. Checked recent IOI messages in production ULBridge log file. Non
				// of them is logged in two lines.
				if(!line.contains("|35=6|"))
				{
					continue;
				}
				
				// Ignore re-send of IOI to client. There are times we tried to send IOI but client FIX session
				// not
				// connected yet.
				if(line.contains("|43=Y|") && line.contains("Sending:"))
				{
					continue;
				}
				
				// Ignore all the cancel IOI messages scheduled by the timer at 16:00, when there is no cancel
				// time passed in.
				if(!_ioiBatchCancelStartTime.isPresent() && line.matches(".+52=\\d{8}-07:00.+"))
				{
					continue;
				}
					
				count++;
				// Break if message count reaches max count.
				if(_maxCount.isPresent() && _maxCount.get() < count) break;
				
				final String fixMsg = line.substring(line.indexOf("8=FIX.4"));
				if(line.contains(" (INFO) Receiving:"))
				{
					if(line.contains("[Neptune]"))
					{
						_msgs.add("Inbound type=FIX");
						_msgs.add(fixMsg);
					}
					else
					{
						// Ignore IOI response from client. Quattro sets the IOI status but there is nothing IOI
						// replay
						// can verify on message level
						continue;
					}
				}
				
				// Outbound IOI
				else
				{
					_msgs.add("Outbound type=FIX");
					_msgs.add(fixMsg);
				}
			}
		}
		catch(final Exception e)
		{
			Log.error(e, "Exception when reading IOI message from log file", e.getMessage());
		}
		
		_msgs.add(_END_OF_FILE);
	}
	
	public String readLine()
	{
		try
		{
			final String line = _msgs.take();
			if(_END_OF_FILE == line)
			{
				return null;
			}
			return line;
		}
		catch(final InterruptedException e)
		{
			Thread.currentThread().interrupt();
			return null;
		}
	}
	
	private static final String _END_OF_FILE = "EndOfReading";
	
	private final static Pattern _IOI_PATTERN =
		Pattern.compile(".+\\|52=(\\d{8}\\-\\d{2}:\\d{2}:\\d{2}).+\\|23=([0-9\\-]+)\\|.+");
	
	public static void main(final String[] args)
	{
		final String message =
			"8=FIX.4.2|9=151|35=6|49=MIZUHO|56=MFS|34=1|52=20180204-22:24:38|15=JPY|22=2|48=B292RC1|55=3092|23=1000002|27=185000|28=N|54=1|58=vwap|62=20180205-06:00:00|130=Y|207=T|10=136|";
		final Matcher matcher = _IOI_PATTERN.matcher(message);
		if(matcher.matches())
		{
			System.out.println(matcher.group(1));
			System.out.println(matcher.group(2));
		}
	}
}
