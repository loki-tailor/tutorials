package com.mizuhosc.selenium.gor;

import com.mizuhosc.selenium.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;
import java.util.stream.*;

public class ExtractOrdersInRange
{
	private final Connection _connection;
	private final String _startDay;
	private final String _endDay;
	private final String[] _clientIds;
	
	public ExtractOrdersInRange(final String startDay, final String endDay, final String[] clientIds) throws Exception
	{
		
		_startDay = startDay;
		_endDay = endDay;
		_clientIds = clientIds;
		_connection = Configuration.SINGLETON.createConnection("OSPREY_DB");
		_log(String.format("Parameters: %s, %s, %s", _startDay, _endDay, Arrays.asList(_clientIds)));
	}
	
	public void execute() throws Exception
	{
		final String outputFolder = new SimpleDateFormat("yyyy-MM-dd_HHmmss").format(new Date());
		final File folder = new File(outputFolder);
		folder.mkdir();
		final List<Long> clientIds =
			"ALL".equals(_clientIds[0])
				? getOrderClientIdsInRange()
				: Arrays
					.asList(_clientIds)
					.stream()
					// Filter out empty string
					.filter($ -> !$.trim().isEmpty())
					.map($ -> Long.parseLong($))
					.collect(Collectors.toList());
		_log(String.format("Number of clients: %d", clientIds.size()));
		for(int i = 0; i < clientIds.size(); i++)
		{
			final Long clientId = clientIds.get(i);
			_log(
				String.format(
					"Extracting orders for client(%d of %d): FixClientId=%d",
					i + 1,
					clientIds.size(),
					clientId));
			final List<String> globalOrderIds = getClientGlobalOrderIds(clientId);
			final int count =
				new ExtractOrders(globalOrderIds, outputFolder + "/" + clientId + ".log").extract().size();
			_log(String.format("Extracted %d orders for client %d", count, clientId));
			_log(String.format(
				"Extracted orders for client(%d of %d): FixClientId=%d",
				i + 1,
				clientIds.size(),
				clientId));
			
		}
	}
	
	private static final SimpleDateFormat _FORMAT = new SimpleDateFormat("MM-dd HH:mm");
	
	private static void _log(final String s)
	{
		System.out.println(_FORMAT.format(new Date()) + "\t" + s);
	}
	
	/**
	 * Returns the list of client ids that has order in the specified week
	 */
	public List<Long> getOrderClientIdsInRange() throws Exception
	{
		final List<Long> result = new LinkedList<>();
		final PreparedStatement pstmt = _connection.prepareStatement(
			" select distinct ooc.FixClientId" +
				" from OspreyOrder oo" +
				" inner join OspreyOrderClient ooc on oo.GlobalOrderId = ooc.GlobalOrderId" +
				" where oo.OnMarketDate >= ? and oo.OnMarketDate <= ? ");
		pstmt.setString(1, _startDay);
		pstmt.setString(2, _endDay);
		final ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			result.add(rs.getLong("FixClientId"));
		}
		rs.close();
		pstmt.close();
		return result;
	}
	
	public List<String> getClientGlobalOrderIds(final long clientId) throws Exception
	{
		final List<String> result = new LinkedList<>();
		final PreparedStatement pstmt = _connection.prepareStatement(
			" select oo.GlobalOrderId" +
				" from OspreyOrder oo" +
				" inner join OspreyOrderClient ooc on oo.GlobalOrderId = ooc.GlobalOrderId" +
				" where oo.OnMarketDate >= ? and oo.OnMarketDate <= ? " +
				" and ooc.FixClientId = ? ");
		pstmt.setString(1, _startDay);
		pstmt.setString(2, _endDay);
		pstmt.setLong(3, clientId);
		final ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			result.add(rs.getString("GlobalOrderId"));
		}
		rs.close();
		pstmt.close();
		return result;
	}
	
	public static void main(final String[] args)
	{
		if(args.length < 3)
		{
			_log("Usage: ExtractOrdersInOneWeek 2017-07-10 2017-07-14 clientId[ clientId]");
			_log("Usage: ExtractOrdersInOneWeek 2017-07-10 2017-07-14 ALL");
			return;
		}
		try
		{
			final String[] clientIds = Arrays.copyOfRange(args, 2, args.length);
			new ExtractOrdersInRange(args[0], args[1], clientIds).execute();
		}
		catch(final Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
