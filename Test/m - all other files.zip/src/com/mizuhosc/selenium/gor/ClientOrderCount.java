package com.mizuhosc.selenium.gor;

import com.mizuhosc.quattro.util.*;
import com.mizuhosc.selenium.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

public class ClientOrderCount
{
	private final Map<_Key, Integer> _counts = new ConcurrentHashMap<>();
	
	public void execute()
	{
		try(final Connection db = _createOspreyDBConnection())
		{
			final Statement stmt = db.createStatement();
			final ResultSet rs = stmt.executeQuery("select om.Message " +
				" from OspreyOrderMessage oom inner join OspreyMessage om " +
				" on oom.GlobalOrderId = om.GlobalOrderId and oom.LastMessageId = om.Id" +
				" where oom.Type = 'TK_KeyholeState'");
			while(rs.next())
			{
				final String keyholeStateString = new String(ExtractGORMessages.UncompressByte(rs.getBytes("Message")));
				final MessageMap keyholeState = MessageMap.parseString(keyholeStateString);
				final Long fixClientId = keyholeState.getLong("FixClientId");
				
				// Ignore orders that don't have FixClientId.
				if(fixClientId == null)
				{
					continue;
				}
				final String handling = keyholeState.getString("Handling");
				final String broker = keyholeState.getString("Broker");
				final String status = keyholeState.getString("Status");
				final String onMarketDate = keyholeState.getString("OnMarketDate");
				
				// Ignore count of rejected orders
				if("REJECTED".equals(status))
				{
					continue;
				}
				
				final _Key key = new _Key(fixClientId, onMarketDate, handling, broker);
				final Integer count = _counts.computeIfAbsent(key, $ -> new Integer(0));
				_counts.put(key, count.intValue() + 1);
			}
			
			System.out.println("FixClientId, OnMarketDate, Handling, Broker, Count");
			_counts.entrySet().forEach($ -> System.out.println($.getKey().toString() + $.getValue()));
			
		}
		catch(final SQLException | MessagingException e)
		{
			e.printStackTrace();
		}
	}
	
	private static Connection _createOspreyDBConnection() throws SQLException
	{
		final Properties p = new Properties();
		p.put("user", Configuration.SINGLETON.getProperty("db.OSPREY_DB.username"));
		p.put("password", Configuration.SINGLETON.getProperty("db.OSPREY_DB.password"));
		
		return DriverManager.getConnection(Configuration.SINGLETON.getProperty("db.OSPREY_DB.url"), p);
	}
	
	class _Key
	{
		private final long _fixClientId;
		private final String _onMarketDate;
		private final String _handling;
		private final String _broker;
		
		private _Key(final long fixClientId, final String onMarketDate, final String handling, final String broker)
		{
			_fixClientId = fixClientId;
			_onMarketDate = onMarketDate;
			_handling = handling;
			_broker = broker;
		}
		
		public long getFixClientId()
		{
			return _fixClientId;
		}
		
		public String getHandling()
		{
			return _handling;
		}
		
		public String getBroker()
		{
			return _broker;
		}
		
		@Override
		public int hashCode()
		{
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + ((_broker == null) ? 0 : _broker.hashCode());
			result = prime * result + (int)(_fixClientId ^ (_fixClientId >>> 32));
			result = prime * result + ((_handling == null) ? 0 : _handling.hashCode());
			result = prime * result + ((_onMarketDate == null) ? 0 : _onMarketDate.hashCode());
			return result;
		}
		
		@Override
		public boolean equals(final Object obj)
		{
			if(this == obj) return true;
			if(obj == null) return false;
			if(getClass() != obj.getClass()) return false;
			final _Key other = (_Key)obj;
			if(!getOuterType().equals(other.getOuterType())) return false;
			if(_broker == null)
			{
				if(other._broker != null) return false;
			}
			else if(!_broker.equals(other._broker)) return false;
			if(_fixClientId != other._fixClientId) return false;
			if(_handling == null)
			{
				if(other._handling != null) return false;
			}
			else if(!_handling.equals(other._handling)) return false;
			if(_onMarketDate == null)
			{
				if(other._onMarketDate != null) return false;
			}
			else if(!_onMarketDate.equals(other._onMarketDate)) return false;
			return true;
		}
		
		@Override
		public String toString()
		{
			return String.format("%d, %s, %s, %s, ", _fixClientId, _onMarketDate, _handling, _broker);
		}
		
		private ClientOrderCount getOuterType()
		{
			return ClientOrderCount.this;
		}
		
	}
	
	public static void main(final String[] args)
	{
		new ClientOrderCount().execute();
	}
}
