package com.mizuhosc.selenium.gor;

import com.mizuhosc.selenium.*;
import java.sql.*;
import java.text.*;
import java.util.Date;

public class DeleteUlMessagesFromOspreyMessage
{
	private final int _batchSize;
	
	public DeleteUlMessagesFromOspreyMessage(final int batchSize)
	{
		_batchSize = batchSize;
	}
	
	public void execute() throws Exception
	{
		final Connection gorQ6 = Configuration.SINGLETON.createConnection("OSPREY_DB");
		final Statement stmt = gorQ6.createStatement();
		stmt.execute("set rowcount " + _batchSize);
		int totalDeleted = 0;
		while(true)
		{
			final int deleted = stmt.executeUpdate(
				"delete from OspreyMessage where HopStatus in ('KeyholeToBridge', 'BridgeToKeyhole') ");
			totalDeleted += deleted;
			_log(String.format("%d rows deleted from OspreyMessage. Deleted in total: %d", deleted, totalDeleted));
			if(deleted == 0)
			{
				break;
			}
		}
		_log("All KeyholeToBridge and BridgeToKeyhole messages deleted");
		stmt.close();
		gorQ6.close();
		
	}
	
	private static final ThreadLocal<SimpleDateFormat> _FORMAT = new ThreadLocal()
	{
		
		@Override
		protected SimpleDateFormat initialValue()
		{
			return new SimpleDateFormat("HH:mm:ss");
		}
	};
	
	private static void _log(final String s)
	{
		System.out.println(_FORMAT.get().format(new Date()) + "\t" + s);
	}
	
	public static void main(final String[] args)
	{
		try
		{
			new DeleteUlMessagesFromOspreyMessage(2000).execute();
		}
		catch(final Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
