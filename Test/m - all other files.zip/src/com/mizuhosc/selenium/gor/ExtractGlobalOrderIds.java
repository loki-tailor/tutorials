package com.mizuhosc.selenium.gor;

import com.mizuhosc.quattro.util.*;
import com.mizuhosc.selenium.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class ExtractGlobalOrderIds
{
	private final List<String> _globalOrderIds = new ArrayList<>();
	
	public List<String> execute(final String targetFIXClientId, final String targetHandling)
	{
		try(final Connection db = _createOspreyDBConnection())
		{
			try(final Statement stmt = db.createStatement();
				final ResultSet rs = stmt.executeQuery("select om.Message " +
					" from OspreyOrderMessage oom inner join OspreyMessage om " +
					" on oom.GlobalOrderId = om.GlobalOrderId and oom.LastMessageId = om.Id" +
					" inner join OspreyOrderClient c on c.GlobalOrderId = oom.GlobalOrderId" +
					" where oom.Type = 'TK_KeyholeState'" +
					" and c.FixClientId = " +
					targetFIXClientId))
			{
				System.out.println("Start to extract GlobalOrderIds...");
				
				while(rs.next())
				{
					final String keyholeStateString =
						new String(ExtractGORMessages.UncompressByte(rs.getBytes("Message")));
					
					final MessageMap keyholeState = MessageMap.parseString(keyholeStateString);
					final String fixClientId = keyholeState.getString("FixClientId");
					
					// Ignore orders that don't have FixClientId or not the target FixClientId.
					if(fixClientId == null || !fixClientId.equals(targetFIXClientId))
					{
						continue;
					}
					final String handling = keyholeState.getString("Handling");
					final String status = keyholeState.getString("Status");
					
					// Ignore count of rejected orders
					if("REJECTED".equals(status))
					{
						continue;
					}
					
					if(!targetHandling.equals(handling))
					{
						continue;
					}
					
					final String globalOrderId = keyholeState.getString("GlobalOrderId");
					
					_globalOrderIds.add(globalOrderId);
				}
			}
			
		}
		catch(final SQLException | MessagingException e)
		{
			e.printStackTrace();
		}
		
		return _globalOrderIds;
	}
	
	private static Connection _createOspreyDBConnection() throws SQLException
	{
		final Properties p = new Properties();
		p.put("user", Configuration.SINGLETON.getProperty("db.OSPREY_DB.username"));
		p.put("password", Configuration.SINGLETON.getProperty("db.OSPREY_DB.password"));
		
		return DriverManager.getConnection(Configuration.SINGLETON.getProperty("db.OSPREY_DB.url"), p);
	}
	
	public static void main(final String[] args) throws IOException
	{
		if(args.length < 2)
		{
			System.out.println("Usage: ExtractGlobalOrderIds {fixClientId} {handling}");
			return;
		}
		
		final List<String> globalOrderIds = new ExtractGlobalOrderIds().execute(args[0], args[1]);
		System.out.println(String.format("Found %d GlobalOrderIds:", globalOrderIds.size()));
		
		if(args.length > 2)
		{
			try(BufferedWriter writer = new BufferedWriter(new FileWriter(args[2])))
			{
				for(final String globalOrderId: globalOrderIds)
				{
					writer.write(globalOrderId);
					writer.newLine();
				}
			}
		}
		else
		{
			globalOrderIds.forEach(System.out::println);
		}
		
		System.out.println("Finished writing GlobalOrderIds.");
	}
}
