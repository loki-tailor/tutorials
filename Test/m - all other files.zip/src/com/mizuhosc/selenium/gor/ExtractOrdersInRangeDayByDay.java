package com.mizuhosc.selenium.gor;

import com.mizuhosc.selenium.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;
import java.util.stream.*;

public class ExtractOrdersInRangeDayByDay
{
	private final Connection _connection;
	private final String _startDay;
	private final String _endDay;
	private final String _clientIds;
	
	public ExtractOrdersInRangeDayByDay(final String clientIds, final String startDay, final String endDay)
		throws Exception
	{
		_startDay = startDay;
		_endDay = endDay;
		_clientIds = clientIds;
		_connection = Configuration.SINGLETON.createConnection("OSPREY_DB");
		
	}
	
	public void execute() throws Exception
	{
		final String outputFolder = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		final List<Long> clientIds =
			"ALL".equals(_clientIds)
				? getOrderClientIdsInRange()
				: Stream.of(_clientIds.split(",")).map($ -> Long.parseLong($)).collect(Collectors.toList());
		_log(String.format("Number of clients: %d", clientIds.size()));
		for(int i = 0; i < clientIds.size(); i++)
		{
			final Long clientId = clientIds.get(i);
			_log(
				String.format(
					"Extracting orders for client(%d of %d): FixClientId=%d",
					i + 1,
					clientIds.size(),
					clientId));
			final Map<String, List<String>> globalOrderIds = getClientGlobalOrderIds(clientId);
			final List<String> decreasingOrder = new LinkedList<>(globalOrderIds.keySet());
			Collections.reverse(decreasingOrder);
			for(final String onMarketDates: decreasingOrder)
			{
				final String outputFolderName = onMarketDates + "_" + outputFolder;
				final File folder = new File(outputFolderName);
				if(!folder.exists())
				{
					folder.mkdir();
				}
				final String fileName = outputFolderName + "/" + clientId + ".log";
				final File file = new File(fileName);
				if(!file.exists())
				{
					file.createNewFile();
				}
				
				final int count =
					new ExtractOrders(
						globalOrderIds.get(onMarketDates),
						fileName)
							.extract()
							.size();
				_log(String.format("Extracted %d orders for client %d", count, clientId));
				_log(String.format(
					"Extracted orders for client(%d of %d): FixClientId=%d",
					i + 1,
					clientIds.size(),
					clientId));
			}
			
		}
	}
	
	private static final SimpleDateFormat _FORMAT = new SimpleDateFormat("MM-dd HH:mm");
	
	private static void _log(final String s)
	{
		System.out.println(_FORMAT.format(new Date()) + "\t" + s);
	}
	
	/**
	 * Returns the list of client ids that has order in the specified week
	 */
	public List<Long> getOrderClientIdsInRange() throws Exception
	{
		final List<Long> result = new LinkedList<>();
		final PreparedStatement pstmt = _connection.prepareStatement(
			" select distinct ooc.FixClientId" +
				" from OspreyOrder oo" +
				" inner join OspreyOrderClient ooc on oo.GlobalOrderId = ooc.GlobalOrderId" +
				" where oo.OnMarketDate >= ? and oo.OnMarketDate <= ? ");
		pstmt.setString(1, _startDay);
		pstmt.setString(2, _endDay);
		final ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			result.add(rs.getLong("FixClientId"));
		}
		rs.close();
		pstmt.close();
		return result;
	}
	
	public Map<String, List<String>> getClientGlobalOrderIds(final long clientId) throws Exception
	{
		final Map<String, List<String>> result = new TreeMap<>();
		final PreparedStatement pstmt = _connection.prepareStatement(
			" select oo.OnMarketDate, oo.GlobalOrderId" +
				" from OspreyOrder oo" +
				" inner join OspreyOrderClient ooc on oo.GlobalOrderId = ooc.GlobalOrderId" +
				" where oo.OnMarketDate >= ? and oo.OnMarketDate <= ? " +
				" and ooc.FixClientId = ? ");
		pstmt.setString(1, _startDay);
		pstmt.setString(2, _endDay);
		pstmt.setLong(3, clientId);
		final ResultSet rs = pstmt.executeQuery();
		while(rs.next())
		{
			result.computeIfAbsent(rs.getString("OnMarketDate"), k -> new ArrayList<>()).add(
				rs.getString("GlobalOrderId"));
		}
		rs.close();
		pstmt.close();
		return result;
	}
	
	public static void main(final String[] args)
	{
		if(args.length < 3)
		{
			_log("Usage: ExtractOrdersInRangeDayByDay clientId[,clientId] 2017-07-10 2017-07-14");
			_log("Usage: ExtractOrdersInRangeDayByDay ALL 2017-07-10 2017-07-14");
			return;
		}
		try
		{
			new ExtractOrdersInRangeDayByDay(args[0], args[1], args[2]).execute();
		}
		catch(final Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
