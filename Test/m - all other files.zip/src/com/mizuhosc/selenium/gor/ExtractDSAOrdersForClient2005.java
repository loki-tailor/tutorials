package com.mizuhosc.selenium.gor;

import java.util.*;

public class ExtractDSAOrdersForClient2005
{
	public static void main(final String[] args)
	{
		if(args.length < 2)
		{
			System.out.println("Usage: ExtractDSAOrdersForClient2005 {fixClientId} {handling}");
			return;
		}
		
		try
		{
			final List<String> globalOrderIds = new ExtractGlobalOrderIds().execute(args[0], args[1]);
			System.out.println("GlobalOrderIds:" + globalOrderIds);
			new ExtractOrders(globalOrderIds.toArray(new String[0])).extract();
		}
		catch(final Exception e)
		{
			e.printStackTrace();
		}
	}
}
