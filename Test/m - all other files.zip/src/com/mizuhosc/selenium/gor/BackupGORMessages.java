package com.mizuhosc.selenium.gor;

import com.mizuhosc.selenium.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;

public final class BackupGORMessages
{
	
	private static final StringBuilder _OSPREY_ORDER_QUERY = new StringBuilder()
		.append("select \n")
		.append(" GlobalOrderId,ParentGlobalOrderId,KeyholeId,OnMarketDate,SourceRegion \n")
		.append(",ProcessRegion,InsertTimeUTC,UpdateTimeUTC \n")
		.append(" from OspreyOrder \n");
	
	private static final StringBuilder _OSPREY_ORDER_INSERT = new StringBuilder()
		.append("insert into OspreyOrder \n")
		.append(" (GlobalOrderId,ParentGlobalOrderId,KeyholeId,OnMarketDate,SourceRegion \n")
		.append(",ProcessRegion,InsertTimeUTC,UpdateTimeUTC) \n")
		.append(" values \n")
		.append(" (?,?,?,?,? \n")
		.append(",?,?,?) \n");
	
	private static final StringBuilder _OSPREY_ORDER_CHECK_QUERY = new StringBuilder()
		.append("select \n")
		.append(" GlobalOrderId \n")
		.append(" from OspreyOrder \n")
		.append(" where GlobalOrderId = ? \n");
	
	private static final StringBuilder _OSPREY_MESSAGE_MAX_ID_QUERY = new StringBuilder()
		.append("select max(Id) as Id from OspreyMessage");
	
	private static final StringBuilder _OSPREY_MESSAGE_INSERT = new StringBuilder()
		.append("insert into OspreyMessage \n")
		.append(" (Id,GlobalOrderId,EventId,EventRegion,HopStatus,ExecutionEvent,MessageSource \n")
		.append(",Message,EventTimeUTC,InsertTimeUTC,Sent) \n")
		.append("select \n")
		.append(" Id,GlobalOrderId,EventId,EventRegion,HopStatus,ExecutionEvent,MessageSource \n")
		.append(",Message,EventTimeUTC,InsertTimeUTC,Sent \n")
		.append(" from gor_q6v.ullink.OspreyMessage where HopStatus not in ('KeyholeToBridge', 'BridgeToKeyhole') \n")
		.append(" and Id not in ( select Id from OspreyMessage )");
	// TODO: use line below from Dec 26th. Main reason is previous commit missed messages because it fetched record not
	// sorted
	// .append(" and Id > ? order by Id asc");
	
	private static final StringBuilder _OSPREY_ORDER_MESSAGE_QUERY = new StringBuilder()
		.append("select \n")
		.append(" GlobalOrderId,Type,InsertTimeUTC,UpdateTimeUTC,LastMessageId \n")
		.append(" from OspreyOrderMessage \n");
	
	private static final StringBuilder _OSPREY_ORDER_MESSAGE_INSERT = new StringBuilder()
		.append("insert into OspreyOrderMessage \n")
		.append(" (GlobalOrderId,Type,InsertTimeUTC,UpdateTimeUTC,LastMessageId) \n")
		.append(" values \n")
		.append(" (?,?,?,?,?) \n");
	
	private static final StringBuilder _OSPREY_ORDER_MESSAGE_CHECK_QUERY = new StringBuilder()
		.append("select \n")
		.append(" GlobalOrderId \n")
		.append(" from OspreyOrderMessage \n")
		.append(" where GlobalOrderId = ? and Type= ? \n");
	
	/**
	 * @param args
	 */
	public static void main(final String... args)
	{
		try(final Connection targetConn =
			DriverManager.getConnection(
				Configuration.SINGLETON.getProperty("db.OSPREY_DB.url"),
				_createTagetDBConnectionProperties());
			final Connection sourceConn =
				DriverManager.getConnection(
					Configuration.SINGLETON.getProperty("db.SOURCE_DB.url"),
					_createSourceDBConnectionProperties());)
		{
			// copy OspreyOrder
			_copyOspreyOrder(targetConn, sourceConn);
			
			// copy OspreyMessage
			System.out.println("Starting copy OspreyMessage.");
			
			// Row count set to 1000 to avoid big transaction
			// 1000 rows for OspreyMessage will took 42% transaction space
			final Statement stmt = targetConn.createStatement();
			stmt.execute("set rowcount 1000");
			
			_copyOspreyMessage(targetConn);
			
			// copy OspreyOrderMessage
			System.out.println("Starting copy OspreyOrderMessage.");
			// reset recodeCount
			int recodeCount = 0;
			
			try(final PreparedStatement statement = sourceConn
				.prepareStatement(_OSPREY_ORDER_MESSAGE_QUERY.toString());
				final ResultSet result = statement.executeQuery();
				
				final PreparedStatement tagetStatement = targetConn
					.prepareStatement(_OSPREY_ORDER_MESSAGE_INSERT.toString());
				final PreparedStatement tagetCheckStatement = targetConn
					.prepareStatement(_OSPREY_ORDER_MESSAGE_CHECK_QUERY.toString());)
			{
				
				while(result.next())
				{
					
					tagetCheckStatement.setString(1, result.getString("GlobalOrderId"));
					tagetCheckStatement.setString(2, result.getString("Type"));
					final ResultSet resultCheck = tagetCheckStatement.executeQuery();
					boolean existCheck = false;
					
					while(resultCheck.next())
					{
						existCheck = true;
						break;
					}
					
					resultCheck.close();
					
					if(!existCheck)
					{
						tagetStatement.setString(1, result.getString("GlobalOrderId"));
						tagetStatement.setString(2, result.getString("Type"));
						tagetStatement.setTime(3, result.getTime("InsertTimeUTC"));
						tagetStatement.setTime(4, result.getTime("UpdateTimeUTC"));
						tagetStatement.setLong(5, result.getLong("LastMessageId"));
						
						tagetStatement.executeUpdate();
						_log(String.format("Copied %d OspreyOrderMessage record", recodeCount++));
					}
				}
			}
			System.out.println("Finished copy OspreyOrderMessage.");
			
		}
		catch(final SQLException ex)
		{
			System.out.println("Copied failed because of: " + ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	static void _copyOspreyMessage(final Connection targetConn) throws SQLException
	{
		int osperyMessageCount = 0;
		while(true)
		{
			// final PreparedStatement statement = targetConn
			// .prepareStatement(_OSPREY_MESSAGE_MAX_ID_QUERY.toString());
			// final ResultSet result = statement.executeQuery();
			// if(result.next())
			// {
			// final long maxId = result.getLong("Id");
			// result.close();
			// final PreparedStatement tagetStatement = targetConn
			// .prepareStatement(_OSPREY_MESSAGE_INSERT.toString());
			// tagetStatement.setLong(1, maxId);
			// final int count = tagetStatement.executeUpdate();
			// osperyMessageCount += count;
			// _log(String.format("Copied %d OspreyMessage record. Total: %d", count, osperyMessageCount));
			// if(count == 0)
			// {
			// break;
			// }
			//
			// }
			
			final PreparedStatement tagetStatement = targetConn
				.prepareStatement(_OSPREY_MESSAGE_INSERT.toString());
			final int count = tagetStatement.executeUpdate();
			osperyMessageCount += count;
			_log(String.format("Copied %d OspreyMessage record. Total: %d", count, osperyMessageCount));
			if(count == 0)
			{
				break;
			}
			
		}
		
		System.out.println("Finished copy OspreyMessage.");
	}
	
	static void _copyOspreyOrder(final Connection targetConn, final Connection sourceConn) throws SQLException
	{
		System.out.println("Starting copy OspreyOrder.");
		int recodeCount = 0;
		
		try(final PreparedStatement statement = sourceConn
			.prepareStatement(_OSPREY_ORDER_QUERY.toString());
			final ResultSet result = statement.executeQuery();
			
			final PreparedStatement tagetStatement = targetConn
				.prepareStatement(_OSPREY_ORDER_INSERT.toString());
			final PreparedStatement tagetCheckStatement = targetConn
				.prepareStatement(_OSPREY_ORDER_CHECK_QUERY.toString());)
		{
			
			while(result.next())
			{
				
				tagetCheckStatement.setString(1, result.getString("GlobalOrderId"));
				final ResultSet resultCheck = tagetCheckStatement.executeQuery();
				boolean existCheck = false;
				
				while(resultCheck.next())
				{
					existCheck = true;
					break;
				}
				
				resultCheck.close();
				
				if(!existCheck)
				{
					tagetStatement.setString(1, result.getString("GlobalOrderId"));
					tagetStatement.setString(2, result.getString("ParentGlobalOrderId"));
					tagetStatement.setString(3, result.getString("KeyholeId"));
					tagetStatement.setString(4, result.getString("OnMarketDate"));
					tagetStatement.setString(5, result.getString("SourceRegion"));
					tagetStatement.setString(6, result.getString("ProcessRegion"));
					tagetStatement.setTime(7, result.getTime("InsertTimeUTC"));
					tagetStatement.setTime(8, result.getTime("UpdateTimeUTC"));
					
					tagetStatement.executeUpdate();
					_log(String.format("Copied %d OspreyOrder record", recodeCount++));
				}
			}
		}
		System.out.println("Finished copy OspreyOrder.");
	}
	
	/**
	 * Factory method to load properties.
	 */
	private static Properties _createTagetDBConnectionProperties()
	{
		final Properties p = new Properties();
		p.put("user", Configuration.SINGLETON.getProperty("db.OSPREY_DB.username"));
		p.put("password", Configuration.SINGLETON.getProperty("db.OSPREY_DB.password"));
		
		return p;
	}
	
	/**
	 * Factory method to load properties.
	 */
	private static Properties _createSourceDBConnectionProperties()
	{
		final Properties p = new Properties();
		p.put("user", Configuration.SINGLETON.getProperty("db.SOURCE_DB.username"));
		p.put("password", Configuration.SINGLETON.getProperty("db.SOURCE_DB.password"));
		
		return p;
	}
	
	private static final ThreadLocal<SimpleDateFormat> _FORMAT = new ThreadLocal()
	{
		
		@Override
		protected SimpleDateFormat initialValue()
		{
			return new SimpleDateFormat("HH:mm:ss");
		}
	};
	
	private static void _log(final String s)
	{
		System.out.println(_FORMAT.get().format(new Date()) + "\t" + s);
	}
}
