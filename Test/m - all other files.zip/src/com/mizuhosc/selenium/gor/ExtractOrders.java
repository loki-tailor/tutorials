package com.mizuhosc.selenium.gor;

import com.mizuhosc.quattro.util.*;
import com.mizuhosc.selenium.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.*;
import javax.annotation.*;

public final class ExtractOrders
{
	private static final StringBuilder _INBOUND_OUTBOUND_QUERY = new StringBuilder()
		.append("select \n")
		.append(" ks.Id as ksId, ks.GlobalOrderId, ks.Message as keyholeState \n")
		.append(", inbound.Id as inboundId, inbound.Message as inboundMessage \n")
		.append(", outbound.Id as outboundId, outbound.Message as outboundMessage \n")
		.append(", inbound.HopStatus as inboundHopStatus, outbound.HopStatus as outboundHopStatus \n")
		.append(" from OspreyMessage ks \n")
		
		.append(" inner join OspreyOrder osOr \n")
		.append(" on osOr.GlobalOrderId = ks.GlobalOrderId \n")
		
		.append(" left join OspreyMessage inbound \n")
		.append(" on ks.EventId = inbound.EventId and ks.GlobalOrderId = inbound.GlobalOrderId \n")
		.append(" and inbound.HopStatus in('ClientToBridge','KeyholeInternal','MarketToBridge') \n")
		
		.append(" left join OspreyMessage outbound \n")
		.append(" on ks.EventId = outbound.EventId and ks.GlobalOrderId = outbound.GlobalOrderId \n")
		.append(" and outbound.HopStatus in('BridgeToClient','KeyholeToFidessa','BridgeToMarket') \n")
		
		.append(" where ks.HopStatus = 'KeyholeInternal'\n")
		.append(" and ks.GlobalOrderId like ? " + " \n")
		.append(" order by ks.Id asc , outbound.Id asc \n");
	
	private final List<String> _globalOrderIds;
	private final String _outputFileName;
	
	public ExtractOrders(final String... globalOrderIds)
	{
		_globalOrderIds = Arrays.asList(globalOrderIds);
		_outputFileName = "local_input/GOR.log";
	}
	
	public ExtractOrders(final List<String> globalOrderIds, final String outputFileName)
	{
		_globalOrderIds = globalOrderIds;
		_outputFileName = outputFileName;
	}
	
	/**
	 * @param args
	 */
	public static void main(final String... args) throws Exception
	{
		if(args.length == 0)
		{
			System.out.println("Usage: java ExtractGOROrder $GlobalOrderId");
			return;
		}
		
		new ExtractOrders(args).extract();
		
		System.exit(0);
	}
	
	public LinkedHashSet<String> extract(
		final @Nullable Integer eventCountLimit,
		final @Nullable Integer orderCountLimit)
		throws Exception
	{
		final LinkedHashSet<String> actualGlobalOrderIds = new LinkedHashSet<>();
		int totalEventCount = 0;
		int outputFileCounter = 1;
		
		final List<String> globalOrderIds =
			orderCountLimit != null && orderCountLimit > 0 && orderCountLimit < _globalOrderIds.size()
				? _globalOrderIds.subList(0, orderCountLimit)
				: _globalOrderIds;
		
		for(final String globalOrderId: globalOrderIds)
		{
			try(
				final Connection conn = DriverManager.getConnection(
					Configuration.SINGLETON.getProperty("db.OSPREY_DB.url"),
					_createDBConnectionProperties());
				final PreparedStatement pstmt = _prepareStatement(conn, globalOrderId);
				final ResultSet result = pstmt.executeQuery();
				final FileWriter writer = eventCountLimit != null
					// Set file to append mode
					? new FileWriter(rollFileName(_outputFileName, outputFileCounter), true)
					// Set file to override mode (by default)
					: new FileWriter(_outputFileName);)
			{
				// boundId set
				final Set<Long> inboundKeySet = new HashSet<>();
				final Set<Long> outboundKeySet = new HashSet<>();
				while(result.next())
				{
					final _Record record = new _Record(result);
					
					_processRecord(record, inboundKeySet, outboundKeySet, writer);
					
					// Add up the event count
					totalEventCount++;
					actualGlobalOrderIds.add(record._globalOrderId);
				}
				writer.flush();
			}
			
			if(eventCountLimit != null && totalEventCount >= eventCountLimit)
			{
				// Reset the total count for the next rolling file
				totalEventCount = 0;
				
				// Roll to the next output file
				outputFileCounter++;
			}
		}
		
		return actualGlobalOrderIds;
	}
	
	private static String rollFileName(final String fileName, final int fileCounter)
	{
		final int fileExtensionIndex = fileName.indexOf(".log");
		return String.format("%s.%d.log", fileName.substring(0, fileExtensionIndex), fileCounter);
	}
	
	public LinkedHashSet<String> extract() throws Exception
	{
		return extract(null, null);
	}
	
	private static PreparedStatement _prepareStatement(final Connection connection, final String globalOrderId)
		throws SQLException
	{
		final PreparedStatement statement = connection.prepareStatement(_INBOUND_OUTBOUND_QUERY.toString());
		statement.setString(1, globalOrderId);
		return statement;
	}
	
	private static void _processRecord(
		final _Record record,
		final Set<Long> inboundKeySet,
		final Set<Long> outboundKeySet,
		final FileWriter writer) throws IOException
	{
		
		final String keyholeStateString = new String(UncompressByte(record.getKeyholeState()));
		try
		{
			
			final MessageMap keyholeState = MessageMap.parseString(keyholeStateString);
			
			// Ignore states that have reject reason "out of range:". For PROD replay, we will loose the
			// price range so that
			// most the orders can pass price range validation. The result is that we will replay orders
			// that got reject
			// because of price range.
			// Exclude orders rejected with "Market is closed", replay will replay when market is open. No queuing
			// replay.
			// Exclude orders rejected with "Order value limit exceeded". We will change currentPrice to very small
			// value to avoid order got "Order value limit exceeded" in amend request.
			// Order value limit validation is covered by marathon and no need to replay. Since current price changes.
			
			final String rejectReason = keyholeState.getString("RejectReason");
			final String orderStatus = keyholeState.getString("Status");
			if(rejectReason != null &&
				(rejectReason.contains("out of range:") ||
					rejectReason.contains("Market is closed") && "REJECTED".equals(orderStatus) ||
					rejectReason.contains("Order value limit exceeded")))
			{
				return;
			}
			final Long inbountId = record.getInboundId();
			final Long outbountId = record.getOutboundId();
			final String inboundHopStatus = record.getInboundHopStatus();
			final String outboundHopStatus = record.getOutboundHopStatus();
			
			final String senderCompId = Optional
				.ofNullable(keyholeState.getString("SenderCompID"))
				.map($ -> $.toUpperCase())
				.orElse(null);
			
			final String inboudMessage = record.getInboundMessage() != null
				? new String(UncompressByte(record.getInboundMessage()))
				: "";
			final String outboudMessage = record.getOutboundMessage() != null
				? new String(UncompressByte(record.getOutboundMessage()))
				: "";
			
			// output inbound message
			if(senderCompId != null &&
				!inboundKeySet.contains(inbountId) &&
				!inboudMessage.isEmpty())
			{
				if("KeyholeInternal".equals(inboundHopStatus))
				{
					final boolean inboundPrinted =
						_printNonFIXKeyholeInboundMessage(inboudMessage, inboundHopStatus, writer);
					if(!inboundPrinted)
					{
						// DO NOT continue to print outbound if there row doesn't have a valid inbound
						return;
					}
				}
				else
				{
					printNewLine("Inbound", "FIX", writer);
					_writeLine(writer, inboudMessage);
				}
				
				inboundKeySet.add(inbountId);
			}
			
			// output outbound message
			if(senderCompId != null &&
				!outboundKeySet.contains(outbountId) &&
				!outboudMessage.isEmpty())
			{
				final String outboundType =
					"KeyholeToFidessa".equals(outboundHopStatus) || "KeyholeInternal".equals(outboundHopStatus)
						? "FIDESSA"
						: "FIX";
				// Ignore Outbound FIX messages that has 43=Y
				if("FIX".equals(outboundType) && outboudMessage.contains("43=Y")) return;
				printNewLine("Outbound", outboundType, writer);
				_writeLine(writer, outboudMessage);
				outboundKeySet.add(outbountId);
			}
			
		}
		catch(final MessagingException e)
		{
			System.out.println("Failed to parse Messagemap: " + keyholeStateString);
			e.printStackTrace();
		}
	}
	
	private static void _writeLine(final FileWriter writer, final String msg) throws IOException
	{
		writer.write(msg);
		writer.write(System.getProperty("line.separator"));
	}
	
	// For Non FIX inbound message, they are embeded in keyhole's order state.
	// Return true if the outbound message on same row should be printed.
	private static boolean _printNonFIXKeyholeInboundMessage(
		final String inboundMessage,
		final String inboundHopStatus,
		final FileWriter writer)
		throws MessagingException,
		IOException
	{
		if(!"KeyholeInternal".equals(inboundHopStatus))
		{
			return false;
		}
		final MessageMap map = MessageMap.parseString(inboundMessage);
		final String inboundType = map.getString("InboundType");
		String realInbound = map.getString("InboundMessage");
		if(realInbound == null)
		{
			realInbound = map.getString("LastMarketMessage");
		}
		if("FIDESSA".equals(inboundType))
		{
			
			if(realInbound != null)
			{
				printNewLine("Inbound", "FIDESSA", writer);
				_writeLine(writer, realInbound);
				return true;
			}
		}
		else if("TELNET".equals(inboundType))
		{
			final String eventType = map.getString("EventType");
			final String globalOrderId = map.getString("GlobalOrderId");
			// Compose to MessageFormat Quattor is expected
			final String inboundMessageToQuattroFormat = "";
			if("DFD_PAUSE".equals(eventType))
			{
				printNewLine("Inbound", "COMMAND", writer);
				final MessageMap newMap = new MessageMap();
				newMap.set("Command", "pauseDFD");
				newMap.set("OrderId", globalOrderId);
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
			else if("DFD_RESUME".equals(eventType))
			{
				printNewLine("Inbound", "COMMAND", writer);
				final MessageMap newMap = new MessageMap();
				newMap.set("Command", "resumeDFD");
				newMap.set("OrderId", globalOrderId);
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
			else if("DFD".equals(eventType))
			{
				printNewLine("Inbound", "COMMAND", writer);
				final MessageMap newMap = new MessageMap();
				newMap.set("Command", "dfd");
				newMap.set("OrderId", globalOrderId);
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
			else if("UNDFD".equals(eventType))
			{
				printNewLine("Inbound", "COMMAND", writer);
				final MessageMap newMap = new MessageMap();
				newMap.set("Command", "unDfd");
				newMap.set("OrderId", globalOrderId);
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
			else if("FORCE_CANCEL".equals(eventType))
			{
				printNewLine("Inbound", "COMMAND", writer);
				final MessageMap newMap = new MessageMap();
				newMap.set("Command", "forceCancel");
				newMap.set("OrderId", globalOrderId);
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
			else if("DEQUEUE".equals(eventType))
			{
				// No need to print dequeue message.
				return true;
			}
			else if("EXECUTION".equals(eventType))
			{
				printNewLine("Inbound", "ADD_EXECUTION", writer);
				final MessageMap keyholeMap = MessageMap.parseString(realInbound);
				final MessageMap newMap = new MessageMap();
				newMap.set("EXECUTION_EXCHANGE", keyholeMap.getString("Execution_Exchange"));
				newMap.set("EXECUTION_MARKET_REF_ID", keyholeMap.getString("Execution_MarketRefId"));
				newMap.set("EXECUTION_PRICE", keyholeMap.getString("Execution_Price"));
				newMap.set("EXECUTION_QUANTITY", keyholeMap.getString("Execution_Quantity"));
				final String executionTime = keyholeMap.getString("Execution_ExecTime");
				if(executionTime != null)
				{
					newMap.set("EXECUTION_TIME", executionTime.replaceAll("/", "-"));
				}
				newMap.set(
					"FILLED_IN_DARK_POOL",
					Boolean.valueOf(keyholeMap.getString("TTM")) &&
						isTosFills(keyholeMap.getString("Execution_Exchange")));
				newMap.set("SECURITY_TYPE", "FUTURE");
				newMap.set("SIDE", map.getString("Side"));
				newMap.set("QUATTRO_ORDER_ID", globalOrderId);
				newMap.set("LAST_CAPACITY", lastCapacityToQuattro(keyholeMap.getString("Last_Capacity")));
				
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
			else if("EXECUTION_CORRECT".equals(eventType))
			{
				printNewLine("Inbound", "CORRECT_EXECUTION", writer);
				final MessageMap keyholeMap = MessageMap.parseString(realInbound);
				final MessageMap newMap = new MessageMap();
				newMap.set("EXECUTION_EXCHANGE", keyholeMap.getString("Execution_Exchange"));
				final Map<String, String> refIdOfCurrentOrder = _EXECUTION_REF_ID_PER_ORDER.computeIfAbsent(
					globalOrderId,
					t -> new HashMap<>());
				final String currentRefId = keyholeMap.getString("Execution_MarketRefId");
				
				String prefRefId = null;
				if(currentRefId != null && refIdOfCurrentOrder.containsKey(currentRefId))
				{
					prefRefId = refIdOfCurrentOrder.get(currentRefId);
				}
				else
				{
					prefRefId = currentRefId;
				}
				final String newRefId = UUID.randomUUID().toString();
				refIdOfCurrentOrder.put(currentRefId, newRefId);
				newMap.set("EXECUTION_MARKET_REF_ID", newRefId);
				newMap.set("EXECUTION_MARKET_PREV_REF_ID", prefRefId);
				newMap.set("EXECUTION_PRICE", keyholeMap.getString("Execution_Price"));
				newMap.set("EXECUTION_QUANTITY", keyholeMap.getString("Execution_Quantity"));
				final String executionTime = keyholeMap.getString("Execution_ExecTime");
				if(executionTime != null)
				{
					newMap.set("EXECUTION_TIME", executionTime.replaceAll("/", "-"));
				}
				newMap.set(
					"FILLED_IN_DARK_POOL",
					Boolean.valueOf(keyholeMap.getString("TTM")) &&
						isTosFills(keyholeMap.getString("Execution_Exchange")));
				newMap.set("SECURITY_TYPE", "FUTURE");
				newMap.set("SIDE", map.getString("Side"));
				newMap.set("QUATTRO_ORDER_ID", globalOrderId);
				newMap.set("LAST_CAPACITY", lastCapacityToQuattro(keyholeMap.getString("Last_Capacity")));
				
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
			else if("EXECUTION_BUST".equals(eventType))
			{
				printNewLine("Inbound", "BUST_EXECUTION", writer);
				final MessageMap keyholeMap = MessageMap.parseString(realInbound);
				final MessageMap newMap = new MessageMap();
				newMap.set("EXECUTION_EXCHANGE", keyholeMap.getString("Execution_Exchange"));
				final Map<String, String> refIdOfCurrentOrder = _EXECUTION_REF_ID_PER_ORDER.computeIfAbsent(
					globalOrderId,
					t -> new HashMap<>());
				final String currentRefId = keyholeMap.getString("Execution_MarketRefId");
				
				String prefRefId = null;
				if(currentRefId != null && refIdOfCurrentOrder.containsKey(currentRefId))
				{
					prefRefId = refIdOfCurrentOrder.get(currentRefId);
				}
				else
				{
					prefRefId = currentRefId;
				}
				final String newRefId = UUID.randomUUID().toString();
				refIdOfCurrentOrder.put(currentRefId, newRefId);
				newMap.set("EXECUTION_MARKET_REF_ID", newRefId);
				newMap.set("EXECUTION_MARKET_PREV_REF_ID", prefRefId);
				// Osprey doesn't send time for bust, just use EventTime
				newMap.set("EXECUTION_TIME", map.getString("EventTime"));
				newMap.set("FILLED_IN_DARK_POOL", Boolean.valueOf(keyholeMap.getString("TTM")));
				newMap.set("SECURITY_TYPE", "FUTURE");
				newMap.set("SIDE", map.getString("Side"));
				newMap.set("QUATTRO_ORDER_ID", globalOrderId);
				_writeLine(writer, newMap.getTransmitString());
				return true;
			}
		}
		return false;
	}
	
	static boolean isTosFills(final String lastMarket)
	{
		return "TOS".equals(lastMarket) ||
			"TOS1".equals(lastMarket) ||
			"TOS2".equals(lastMarket) ||
			"TOS3".equals(lastMarket);
	}
	
	static String lastCapacityToQuattro(final String lastCapacityInGOR)
	{
		if("agent".equals(lastCapacityInGOR))
		{
			return "AGENT";
		}
		if("crossagent".equals(lastCapacityInGOR))
		{
			return "CROSS_AGENT";
		}
		if("crossprincipal".equals(lastCapacityInGOR))
		{
			return "CROSS_PRINCIPAL";
		}
		if("principal".equals(lastCapacityInGOR))
		{
			return "PRINCIPAL";
		}
		return null;
	}
	
	// When keyhole sends manual correct/bust, it always uses same ExecutionMarketRefId. This is not applicable for
	// Quattro.
	// We will make fake execution ref id/prev ref id to change the message to be quattro applicable.
	private static Map<String, Map<String, String>> _EXECUTION_REF_ID_PER_ORDER =
		new ConcurrentHashMap<>();
	
	private static void printNewLine(final String direction, final String messageType, final FileWriter writer)
		throws IOException
	{
		_writeLine(writer, "########################################################################");
		_writeLine(writer, String.format("%s type=%s", direction, messageType));
	}
	
	static String getSessionName(final String sessionClients)
	{
		final int index = sessionClients.indexOf("(");
		if(index == -1)
		{
			return sessionClients.toUpperCase();
		}
		return sessionClients.substring(0, index);
	}
	
	static List<String> getClientIds(final String sessionClients)
	{
		final int index = sessionClients.indexOf("(");
		if(index == -1)
		{
			return new ArrayList<>();
		}
		return Arrays.asList(sessionClients.substring(index + 1, sessionClients.length() - 1).split(","));
	}
	
	/**
	 * Factory method to load properties.
	 */
	private static Properties _createDBConnectionProperties()
	{
		final Properties p = new Properties();
		p.put("user", Configuration.SINGLETON.getProperty("db.OSPREY_DB.username"));
		p.put("password", Configuration.SINGLETON.getProperty("db.OSPREY_DB.password"));
		
		return p;
	}
	
	/**
	 * Uncompress compressed bytes
	 *
	 * @param compressed
	 * @return Uncompressed bytes
	 */
	public static byte[] UncompressByte(final byte[] compressed)
	{
		if(compressed == null)
		{
			return new byte[0];
		}
		
		final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try(final InputStream in = new GZIPInputStream(new ByteArrayInputStream(compressed));
			final Writer out = new OutputStreamWriter(byteArrayOutputStream);)
		{
			int c;
			while((c = in.read()) != -1)
			{
				out.write(c);
			}
			in.close();
			out.close();
			
			return byteArrayOutputStream.toByteArray();
		}
		catch(final IOException e)
		{
			// if any exception occurs during uncompression, return the original
			return compressed;
		}
	}
	
	static class _Record
	{
		private final String _globalOrderId;
		private final byte[] _keyholeState;
		private final byte[] _inboundMessage;
		private final byte[] _outboundMessage;
		private final Long _inboundId;
		private final Long _outboundId;
		private final String _inboundHopStatus;
		private final String _outboundHopStatus;
		
		public _Record(final ResultSet rs) throws SQLException
		{
			_globalOrderId = rs.getString("GlobalOrderId");
			_keyholeState = rs.getBytes("keyholeState");
			_inboundMessage = rs.getBytes("inboundMessage");
			_outboundMessage = rs.getBytes("outboundMessage");
			_inboundId = rs.getLong("inboundId");
			_outboundId = rs.getLong("outboundId");
			_inboundHopStatus = rs.getNString("inboundHopStatus");
			_outboundHopStatus = rs.getNString("outboundHopStatus");
			
		}
		
		public String getGlobalOrderId()
		{
			return _globalOrderId;
		}
		
		public byte[] getKeyholeState()
		{
			return _keyholeState;
		}
		
		public byte[] getInboundMessage()
		{
			return _inboundMessage;
		}
		
		public byte[] getOutboundMessage()
		{
			return _outboundMessage;
		}
		
		public Long getInboundId()
		{
			return _inboundId;
		}
		
		public Long getOutboundId()
		{
			return _outboundId;
		}
		
		public String getInboundHopStatus()
		{
			return _inboundHopStatus;
		}
		
		public String getOutboundHopStatus()
		{
			return _outboundHopStatus;
		}
		
	}
}
