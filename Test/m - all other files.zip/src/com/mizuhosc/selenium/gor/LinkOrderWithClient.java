package com.mizuhosc.selenium.gor;

import java.sql.*;
import java.util.*;
import com.mizuhosc.quattro.util.*;
import com.mizuhosc.selenium.*;

public class LinkOrderWithClient
{

	public static void main(final String[] args) throws Exception
	{
		if(args.length > 0)
		{
			execute(args[0]);
		}
		else
		{
			execute(null);
		}

	}

	public static void execute(final String session) throws Exception
	{
		final Connection connection = createConnection();
		connection.setAutoCommit(false);
		final Statement stmt = connection.createStatement();
		final Statement insertStmt = connection.createStatement();
		final String sql = "select om.GlobalOrderId, om.Message " +
			"from OspreyOrderMessage oom " +
			"inner join OspreyMessage om on oom.LastMessageId = om.Id " +
			"where oom.Type = 'TK_KeyholeState' " +
			(session != null ? "and oom.GlobalOrderId like '%:" + session + ":%' " : " ") +
			"and om.GlobalOrderId not in (select GlobalOrderId from OspreyOrderClient)";
		final ResultSet rs = stmt.executeQuery(sql);
		int rowIndex = 1;
		final int batchSize = 500;
		while(rs.next())
		{
			final String globalOrderId = rs.getString("GlobalOrderId");
			final String keyholeStateString = new String(ExtractGORMessages.UncompressByte(rs.getBytes("Message")));
			final MessageMap keyholeState = MessageMap.parseString(keyholeStateString);
			final String fixClientId = keyholeState.getString("FixClientId");
			if(fixClientId == null)
			{
				continue;
			}
			insertStmt.addBatch(
				String.format("insert into OspreyOrderClient(GlobalOrderId, FixClientId) values('%s',%s)",
					globalOrderId, fixClientId));
			if(rowIndex % batchSize == 0)
			{
				System.out.println("inserting batch " + rowIndex);
				insertStmt.executeBatch();
				connection.commit();
				insertStmt.clearBatch();
				insertStmt.clearWarnings();
			}
			rowIndex++;
		}
		insertStmt.executeBatch();
		connection.commit();

	}
	
	static Connection createConnection() throws SQLException
	{
		return DriverManager.getConnection(Configuration.SINGLETON.getProperty("db.OSPREY_DB.url"),
			_createDBConnectionProperties());
	}

	private static Properties _createDBConnectionProperties()
	{
		final Properties p = new Properties();
		p.put("user", Configuration.SINGLETON.getProperty("db.OSPREY_DB.username"));
		p.put("password", Configuration.SINGLETON.getProperty("db.OSPREY_DB.password"));
		return p;
	}
}
