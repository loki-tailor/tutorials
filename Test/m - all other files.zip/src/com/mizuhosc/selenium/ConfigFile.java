package com.mizuhosc.selenium;

import java.nio.file.*;

/**
 * Get the user configuration file if it exists, otherwise get the common
 * configuration file.
 */
public class ConfigFile {
	private final String _fileName;

	public ConfigFile(final String fileName) {
		_fileName = fileName;
	}

	public Path getPath() {
		final String userPathString = String.format("conf/%s/%s", System.getProperty("user.name"), _fileName);
		final Path userPath = Paths.get(userPathString);
		return Files.exists(userPath) ? userPath : Paths.get(String.format("conf/%s", _fileName));
	}
}
