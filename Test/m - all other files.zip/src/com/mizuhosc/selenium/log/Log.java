package com.mizuhosc.selenium.log;

import java.text.*;
import java.util.*;

/**
 * Log bridge before we introduce log implementation.
 *
 */
public class Log {
	static ThreadLocal<SimpleDateFormat> _FORMAT = new ThreadLocal<SimpleDateFormat>() {

		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("HH:mm:ss.SSS");
		}
	};

	public static void info(final String message, final Object... parameters) {
		// Do a check for paramters. To abvoid message with "%" but not
		// paramter(fidessa message) break the flow.
		try {
			final String formattedMessage = parameters.length == 0 ? message : String.format(message, parameters);
			System.out.println(_FORMAT.get().format(new Date()) + " " + Thread.currentThread().getName() + ": "
					+ formattedMessage);
		} catch (final Exception e) {
			// If we can't log, print stack trace, but don't break application
			// thread.
			e.printStackTrace();
		}
	}

	public static void error(final String messsage, final Object... parameters) {
		final String formattedMessage = String.format(messsage, parameters);
		System.out.println(
				_FORMAT.get().format(new Date()) + " " + Thread.currentThread().getName() + ": " + formattedMessage);
	}

	public static void error(final Throwable e, final String messsage, final Object... parameters) {
		error(messsage, parameters);
		e.printStackTrace();
	}
	//
	// public static void main(String[] args) {
	//
	// Log.info("This is the only message in Log.info()");
	// Log.info("This is the first parameter of Log.info() | %1$s | %2$s", "2nd
	// parameter", "3rd parameter");
	// System.out.println();
	//
	// try {
	// float x = 1 / 0;
	// } catch (Exception e) {
	// Log.error("This is the only mesage in Log.error()");
	// Log.error(e, "This is the first parameter of Log.error() | %1$s | %2$s",
	// "3nd parameter", "4rd parameter");
	// }
	// }
}
