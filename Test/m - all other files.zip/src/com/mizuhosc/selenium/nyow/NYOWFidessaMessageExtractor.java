package com.mizuhosc.selenium.nyow;

import com.mizuhosc.quattro.util.value.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import javax.annotation.*;

public class NYOWFidessaMessageExtractor
{
	public static void main(final String[] args) throws FileNotFoundException, IOException
	{
		if(args.length < 2)
		{
			System.out.println("Usage: NYOWFidessaMessageExtractor {InputFilePath} {OutputFilePath}");
			return;
		}
		
		new NYOWFidessaMessageExtractor().extract(args[0], args[1]);
	}
	
	public void extract(final String inputFilePath, final String outputFliePath)
		throws FileNotFoundException,
		IOException
	{
		final List<String> messages = new LinkedList<>();
		try(FileInputStream fileInputStream = new FileInputStream(inputFilePath);
			GZIPInputStream gzInputStream = new GZIPInputStream(fileInputStream);
			BufferedReader reader = new BufferedReader(new InputStreamReader(gzInputStream)))
		{
			@Nullable String inputLine;
			boolean writeInAppendMode = false;
			while((inputLine = reader.readLine()) != null)
			{
				if(!messages.isEmpty())
				{
					if(SimpleString.isEmpty.test(inputLine))
					{
						messages.add(inputLine);
						try(FileOutputStream fileOutputStream = new FileOutputStream(outputFliePath, writeInAppendMode);
							BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fileOutputStream)))
						{
							writeInAppendMode = true;
							for(final String outputLine: messages)
							{
								writer.write(outputLine);
								writer.write(System.getProperty("line.separator"));
							}
						}
						
						// Clear the list for one piece of Fidessa messages after writing to file.
						messages.clear();
					}
					else
					{
						// Add one more Fidessa message line.
						messages.add(inputLine);
					}
				}
				else
				{
					if(!inputLine.contains("NYOW-Fidessa"))
					{
						continue;
					}
					
					// Start of Fidessa message
					final int index = inputLine.indexOf("MESSAGE_TYPE.s");
					if(index == -1)
					{
						continue;
					}
					
					final String fidessaMessageStartLine = inputLine.substring(index);
					messages.add("########################################################################");
					messages.add("Inbound type=FIDESSA");
					messages.add(fidessaMessageStartLine);
				}
			}
		}
	}
}
