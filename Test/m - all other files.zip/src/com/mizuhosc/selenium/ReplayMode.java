package com.mizuhosc.selenium;

import static com.mizuhosc.selenium.ReplayModeSection.*;

public enum ReplayMode
{
	TWO_WAY_ORDERS(TWO_WAY),
	IOI(ReplayModeSection.IOI),
	ONE_WAY_ORDERS(ONE_WAY),
	NYOW_ORDERS(TWO_WAY),
	JOURNAL(TWO_WAY);
	
	public final ReplayModeSection section;
	
	ReplayMode(final ReplayModeSection section)
	{
		this.section = section;
	}
}
