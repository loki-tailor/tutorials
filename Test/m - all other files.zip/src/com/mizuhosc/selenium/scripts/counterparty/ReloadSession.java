package com.mizuhosc.selenium.scripts.counterparty;

import com.mizuhosc.selenium.functionlibraries.CommonFunctions;
import com.mizuhosc.selenium.scripts.util.*;
import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class ReloadSession

{
	String testResult;
	WebDriver driver = null; // Selects appropraite driver

	@Parameters({ "username", "password", "quattroEnv", "browser", "File_Order1", "File_Order2", "File_Order3" })
	@Test
	public void ReloadButton(final String user, final String pass, final String monEnv, final String browser, final String Order1, final String Order2,
			final String Order3) {
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try {
			// System.out.println("My username is " + user + ", monitoring Env "
			// + monEnv + ", browser " + browser);

			if (browser.equals("Mozilla")) {
				driver = new FirefoxDriver();
			} else if (browser.equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			} else if (browser.equals("IE")) {
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();

			final ULBridgeFIXReplay ulBridgeFIXReplay = new ULBridgeFIXReplay(Order1,
					ULBridgeFIXReplay.ConnectionType.CLIENT2GOR, 5000);

			
			// Wait for order to receive
			try {
				Thread.sleep(45000);
			} catch (final InterruptedException e2) {
				e2.printStackTrace();
			}

			System.out.println("Order 1 sent");
			final boolean result1 = VerifyOrderStatus("ACTIVE");
			if (result1==true)
			{
			System.out.println("State of order is Active");
			}
			else
			{System.out.println("State of order is not Active");
			}
			
			// Go to session page
			driver.get("http://tkqtrapq18.mizuho-sc.com:9050/session/53");
           
			// Add reject order validator plugin
			CommonFunctions.PluginAdd(driver);

			// Reload the session page
			driver.get("http://tkqtrapq18.mizuho-sc.com:9050/session/53");
			CommonFunctions.ReloadButton(driver);
			try {
				Thread.sleep(1000);
			} catch (final InterruptedException e2) {
				e2.printStackTrace();
			}

			// Navigate to monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");

			ulBridgeFIXReplay.sendAnotherOrder(Order2);
			System.out.println("Order 2 sent");
			
	 		final boolean result2 = VerifyOrderStatus("REJECTED");
	 		if (result2==true)
			{
			System.out.println("State of order is Rejected");
			}
			else
			{System.out.println("State of order is not Rejected");
			}
			// Wait for order to receive
			try {
				Thread.sleep(10000);
			} catch (final InterruptedException e2) {
				e2.printStackTrace();
			}

			// Remove the plugin
			driver.get("http://tkqtrapq18.mizuho-sc.com:9050/session/53");
			CommonFunctions.PluginRemove(driver);

			// Reload Session page again
			driver.get("http://tkqtrapq18.mizuho-sc.com:9050/session/53");
			CommonFunctions.ReloadButton(driver);
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");

			ulBridgeFIXReplay.sendAnotherOrder(Order3);
			System.out.println("Sent another order");
			
			final boolean result3 = VerifyOrderStatus("ACTIVE");
			if (result3==true)
			{
			System.out.println("State of order is Active");
			}
			else
			{System.out.println("State of order is not Active");
			}
			// Wait for order to receive
			try {
				Thread.sleep(10000);
			} catch (final InterruptedException e2) {
				e2.printStackTrace();
			}


			
			if (result1 == true && result2 == true && result3 == true) {
				UpdateResult(11690, true);
			} else{
				UpdateResult(11690, false);
				
			}
			
			
			
			driver.close();
			driver.quit();

		} catch (final Exception e) {
			Reporter.log("Test Case for Reload button has Failed due to an exception");

			Assert.fail("Selenium Error : check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");

			driver.close();
			driver.quit();
		}
	}
	
	
	public boolean VerifyOrderStatus(final String ExpectedStatus)
	{
		final String ActualOrderStaus=driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]/td[6]")).getText();
		if(ActualOrderStaus.equalsIgnoreCase(ExpectedStatus))
			return true;
		else
			return false;		
	}
	
	public void UpdateResult(final int MarathonID, final boolean Result) throws InterruptedException
	{
		// Get release version for QA1- from release version dashboard and update Marathon case
		driver.get("http://tkqtrapq2:8000/FidessaConnectivity.html");
		
		final WebElement fetchData = driver.findElement(By.xpath("//*[@id='env-status']/tbody/tr/td[1][contains(.,'QA10')]//..//td[2]"));
		CharSequence releaseVersion = fetchData.getText();
		releaseVersion=releaseVersion.subSequence(3,9).toString();
		
		System.out.println("Release version ruuning on QA10 is " + releaseVersion);
		
		driver.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + MarathonID);
		try {
			Thread.sleep(1000);
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//*[contains(text(),'Enter Result')]")).click();
		try {
			Thread.sleep(1000);
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//*[contains(text(),'Edit')]")).click();
		if (Result==true){
				driver.findElement(By.xpath("//*[contains(text(),'Passed')]")).click();
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input")).sendKeys("Passed on "+ releaseVersion );
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input")).sendKeys("QTR-10354");
				driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
				Thread.sleep(3000);
				System.out.println("Case Passed");
				
		}
		else{
			driver.findElement(By.xpath("//*[contains(text(),'Failed')]")).click();
			driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input")).sendKeys("Failed on "+ releaseVersion );
			driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input")).sendKeys("QTR-10354");
			driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
			Thread.sleep(3000);
			System.out.println("Case Failed");
		}
		

		
		
	}

}