package com.mizuhosc.selenium.scripts.users;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.testng.*;
import org.testng.annotations.*;


public class CheckRoleChange {
	
	
	String testResult;
	WebDriver driver = null; // Selects appropraite driver
	WebDriver driver1 = null;
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickDfd(String user, String pass, String monEnv, String browser)
	{
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			//	System.setProperty("webdriver.chrome.driver", "I:\\Temp1\\Rahuljai\\Dev\\selenium-2.53.1\\chromedriver.exe");
				driver = new ChromeDriver(options);
				System.out.println(user);
				System.out.println(pass);
				System.out.println(monEnv);
				System.out.println(browser);
				//File file = new File("drivers\\IEDriverServer.exe");
				//System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				//driver1 = new InternetExplorerDriver();
				//System.out.println("2");
		
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			
			
			//driver1.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			//System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			//driver1.findElement(By.name("username")).sendKeys(user);
			//driver1.findElement(By.name("password")).sendKeys(pass);
			//driver1.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			
			
		}
		catch(Exception e)
		{
			Reporter.log(
				"Test Case for DFD has Failed due to an exception : It has fetched the value : " + testResult,
				false);
			Assert.fail("Selenium Error : DFD check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Dfd check : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
			driver.close();
			
			// driver.quit();
		}
	}

}
