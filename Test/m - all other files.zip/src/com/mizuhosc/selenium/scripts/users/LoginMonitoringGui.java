package com.mizuhosc.selenium.scripts.users;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.testng.annotations.*;

public class LoginMonitoringGui
{
	WebDriver driver = null; // Selects appropraite driver
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void loginScreen(String user, String pass, String monEnv, String browser)
	{
		
		// System.out.println(
		// "My username is " + user + "My password is " + pass + "monitoring Env" + monEnv + "browser" + browser);
		
		
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		if(browser.equals("Mozilla"))
		{
			driver = new FirefoxDriver();
		}
		else if(browser.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
		}
		else if(browser.equals("IE"))
		{
			File file = new File("drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
		}
		// Log into Monitoring screen
		driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.id("username")).sendKeys(user);
		driver.findElement(By.id("password")).sendKeys(pass);
		driver.findElement(By.id("signin")).click();
		
		try
		{
			Thread.sleep(5000);
		}
		catch(InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		driver.close();
		// driver.quit();
		
	}
	@AfterTest
	public void CloseBrowser()
	{
		driver.close();
		driver.quit();
	}
	
}
