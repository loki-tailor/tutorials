package com.mizuhosc.selenium.scripts.users;

import java.io.*;
import java.util.*;
import jxl.*;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class GlobalPermissionCheck
{
	String actualOrderCount;
	WebDriver driver = null; // Selects appropraite driver
	int totalAllowedRows1Page = 200;
	String home = System.getProperty("user.home");
	String downloadDir = home + "\\Downloads\\";
	
	@Parameters({
		"username",
		"password",
		"quattroEnv",
		"browser",
		"no_of_orders",
		"order_ids",
		"DFDText",
		"NoOfDFD",
		"NoOfTab",
		"AccessibleTabs",
		"EMClickable",
		"PositionAdd",
		"PositionReload",
		"AddClient",
		"IntmntReload",
		"ReloadButtons",
		"AddUser","ShowMore"})
	@Test
	public void permissionCheck(
		final String user,
		final String pass,
		final String monEnv,
		final String browser,
		final String nooforders,
		final String orderids,
		final String dfdtext,
		final String noofdfd,
		final String nooftabs,
		final String acctabs,
		final String ExpectedEMClick,
		final String ExpectedPosAdd,
		final String ExpectedPosReload,
		final String ExpAddClient,
		final String ExpInsReload,
		final String ExpInsReloadButtons,
		final String ExpAddUser,
		final String ExpShowMore)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
	
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			
			int fail1 = 1;
			int fail2 = 1;
			int fail3 = 1;
			int fail4 = 1;
			int fail5 = 1;
			int fail6 = 1;
			int fail7 = 1;
			int fail8 = 1;
			int fail9 = 1;
			int fail10 = 1;
			int fail11 = 1;
			int fail12 = 1;
			int fail13 = 1;
			int fail14 = 1;
			
			Reporter.log("User : " + user, true);
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			
			final List<WebElement> tabs = driver.findElements(By.xpath("//*[@id='menu']//li"));
			
			final String Actualnooftabs = Integer.toString(tabs.size());
			final int tab_count = tabs.size();
			
			if(Actualnooftabs.equals(nooftabs))
			{
				
				Reporter.log("Test Case for verification of number of tabs has been Passed.", true);
				Reporter.log("Number of Tabs are maching, Expected: " + nooftabs + " Actual: " + Actualnooftabs, true);
				try
				{
					Thread.sleep(5000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
			}
			else
			{
				
				Reporter.log("Test Case for verification of number of tabs has been Failed.", true);
				Reporter.log("Number of tabs are not maching, Expected: " + nooftabs + " Actual: " + Actualnooftabs,
					true);
				
				fail4 = 0;
			}
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			final String[] Accesstabs_split = acctabs.split("\\|");
			String Actualtab;
			
			for(int tab = 0; tab < Accesstabs_split.length; tab++)
			{
				Boolean flag = false;
				
				System.out.println("Expected Tab : " + Accesstabs_split[tab]);
				for(int i = 1; i <= tab_count; i++)
				{
					Actualtab = driver.findElement(By.xpath("//*[@id='menu']//li[" + i + "]")).getText().trim();
					
					if(Accesstabs_split[tab].equals(Actualtab))
					{
						
						Reporter.log(Accesstabs_split[tab] + " tab is accesible by user as expected", true);
						flag = true;
						break;
					}
					
				}
				
				if(!flag)
				{
					
					Reporter.log(Accesstabs_split[tab] + " tab is not accessible by user which is not expected", true);
					fail5 = 0;
				}
			}
			
			Reporter.log("-------------------------------------------------------------------------------------", true);
			
			final String Alltabs[] = {
				"engines",
				"orders",
				"history",
				"clients",
				"symbols",
				"ioi",
				"allocs",
				"alerts",
				"positions",
				"users",
				"docs",
				"logs"};
			
			// int l = 0;
			
			final ArrayList<String> NoAccesstabs_list = new ArrayList<String>();
			
			for(int j = 0; j < Alltabs.length; j++)
			{
				Boolean flag = false;
				
				for(int k = 0; k < Accesstabs_split.length; k++)
				{
					if(Alltabs[j].equals(Accesstabs_split[k]))
					{
						flag = true;
						break;
					}
					
				}
				
				if(!flag)
				{
					NoAccesstabs_list.add(Alltabs[j]);
				}
			}
			
			final String[] NoAccesstabs_split = new String[NoAccesstabs_list.size()];
			for(int m = 0; m < NoAccesstabs_split.length; m++)
				
				NoAccesstabs_split[m] = NoAccesstabs_list.get(m).toString();
			
			System.out.println(NoAccesstabs_split.length);
			
			for(int tab = 0; tab < NoAccesstabs_split.length; tab++)
			{
				Boolean flag = true;
				
				System.out.println("Not Expected Tab : " + NoAccesstabs_split[tab]);
				for(int i = 1; i <= tab_count; i++)
				{
					Actualtab = driver.findElement(By.xpath("//*[@id='menu']//li[" + i + "]")).getText().trim();
					// System.out.println("Actual Tab : "+ Actualtab);
					if(Actualtab.equals(NoAccesstabs_split[tab]))
					{
						
						Reporter.log(NoAccesstabs_split[tab] + " tab is accesible by user which is not expected", true);
						flag = false;
						fail6 = 0;
						break;
					}
					
				}
				
				if(flag)
				{
					
					Reporter.log(NoAccesstabs_split[tab] + " tab is not accessible by user as expected", true);
					
				}
			}
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			
			Reporter.log("Waiting for 30 secs to get orders loaded", true);
			Thread.sleep(30000);
			Reporter.log("Clicking on any order on Monitoring Screen", true);
			final List<WebElement> OrderCount =
				driver.findElements(By.xpath("//*[@id='menu']//*[contains(text(),'orders')]"));
			Reporter.log(String.format("selected %s Orders on Monitoring Screen", OrderCount.size()), true);
			if(OrderCount.size() > 0)
			{
				
				final Actions cltrend = new Actions(driver);
				cltrend.sendKeys(Keys.END).build().perform();
				
				try
				{
					Thread.sleep(2000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				
				cltrend.sendKeys(Keys.END).build().perform();
				try
				{
					Thread.sleep(2000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				Reporter.log("Scrolling till end of the Monitoring Page", true);
				final List<WebElement> rows = driver.findElements(By.xpath("//*[@id='q-render-table-order-list']//tr"));
				Thread.sleep(1000);
				int row_count = rows.size();
				Reporter.log(String.format(
					"Showing %d orders, click the link at bottom of page to download all orders if orders are more than 200",
					row_count), true);
				
				try
				{
					
					Reporter.log("------------------------------Checking for Show more link------------------------------------------------------------",
							true);
							
						
						final List<WebElement> ShowMoreElement = driver.findElements(By.xpath("//*[contains(text(),'Show more')]"));
						
						String ActualShowMore;
						if(ShowMoreElement.size() > 0)
						{
							ActualShowMore = "YES";
						}
						else
						{
							ActualShowMore = "NA";
						}
						
					
						if(ExpShowMore.equals(ActualShowMore))
						{
							Reporter.log("Test case for Show more link has Passed", true);
							
							if(ActualShowMore.equals("YES"))
							{
								Reporter.log("Expected : User should see Show more link", true);
								Reporter.log("Actual : User can see Show more link", true);
							}
							else if(ActualShowMore.equals("NA"))
							{
								Reporter.log("Expected : User should not see Show more link", true);
								Reporter.log("Actual : User can not see Show more link", true);
							}
							
						}
						else
						{
							Reporter.log("Test case for Show more link has Failed", true);
							fail14 = 0;
							
							if(ExpShowMore.equals("YES"))
							{
								Reporter.log("Expected : User should see Show more link", true);
							}
							else if(ExpShowMore.equals("NA"))
							{
								Reporter.log("Expected :User should not see Show more link", true);
							}
							
							
							if(ActualShowMore.equals("YES"))
							{
								Reporter.log("Actual :User can see Show more link ", true);
							}
							else if(ActualShowMore.equals("NA"))
							{
								Reporter.log("Actual : User can not see Show more link", true);
							}
							
						}
						
						Reporter.log("------------------------------------------------------------------------------------------",
							true);
							
						
						
					//Check for Selenium17 is implemented against SEL-35 , as 'Show more' link on monitoring screen will be seen to only this user
					if(ExpShowMore.equals("YES"))
					{
						final WebElement downloadAllOrders =
								driver.findElement(By.xpath("//*[@id='q-render-table-order-list']/tfoot/tr/td/div/a[2]"));
						downloadAllOrders.click();	
							//Download directly
							final WebElement downloadDirectly =driver.findElement(By.xpath("//*[@class='download-directly']"));
							downloadDirectly.click();
							Thread.sleep(1000);
							Reporter.log("'Download directly' button clicked", true);
							System.out.println("'Download directly' button clicked");
							//Send to my mail
							downloadAllOrders.click();	
							final WebElement sendToMyEmail=	driver.findElement(By.xpath("//*[@class='send-to-my-email']"));
							sendToMyEmail.click();
							Reporter.log("'Send to my mail' button clicked", true);
							System.out.println("'Send to my mail' button clicked");
						
					}
					else
					{
					final WebElement downloadAllOrders =
						driver.findElement(By.xpath("//*[@id='q-render-table-order-list']/tfoot/tr/td/div/a"));
					downloadAllOrders.click();
					//Download directly
					final WebElement downloadDirectly =driver.findElement(By.xpath("//*[@class='download-directly']"));
					downloadDirectly.click();
					Thread.sleep(1000);
					Reporter.log("'Download directly' button clicked", true);
					System.out.println("'Download directly' button clicked");
					//Send to my mail
					downloadAllOrders.click();	
					final WebElement sendToMyEmail=	driver.findElement(By.xpath("//*[@class='send-to-my-email']"));
					sendToMyEmail.click();
					Reporter.log("'Send to my mail' button clicked", true);
					System.out.println("'Send to my mail' button clicked");
					}
					Reporter.log("Clicked on link appears at botton of the page.", true);
					try
					{
						Reporter.log("10 seconds waiting for file to be downloaded.", true);
						Thread.sleep(10000);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
					List<String> textFiles;
					Reporter.log(String.format("Creating list of all files in %s", downloadDir), true);
					textFiles = new ArrayList<String>();
					final File dir = new File(downloadDir);
					for(final File file: dir.listFiles())
					{
						if(file.getName().startsWith(("Orders")))
						{
							Reporter.log(String.format("Adding %s file into list", file.getName()), true);
							textFiles.add(file.getName());
						}
					}
					
					String allstirng = "";
					boolean check = true;
					for(final String s: textFiles)
					{
						if(!check)
						{
							allstirng += ',';
						}
						allstirng += s;
						check = false;
					}
					
					if(textFiles.size() > 0)
					{
						final String[] array = textFiles.toArray(new String[0]);
						final File workbookFile = new File(downloadDir + array[0]);
						Reporter.log(String.format("Creating workbook of %s file", workbookFile.getName()), true);
						final Workbook wb = Workbook.getWorkbook(workbookFile);
						final Sheet sh = wb.getSheet(0);
						final int totalrowsExcel = sh.getRows();
						final int totalOrders = totalrowsExcel - 1;
						actualOrderCount = Integer.toString(totalOrders);
						final String CellGetContent = sh.getCell(1, 5).getContents();
						Reporter.log(String.format("Total %s orders are in workbook", actualOrderCount), true);
						System.out.println(CellGetContent);
						System.out.println("Total number of orders" + actualOrderCount);
					}
					else
					{
						Reporter.log(String.format("Unable fo find downloaded Excel sheet of Orders."), true);
					}
					
				}
				// Finding total number of orders when they are not exceeding the limit of 200
				catch(final NoSuchElementException ex)
				{
					System.out.println("No of orders are not more than the standard limit");
					actualOrderCount = Integer.toString(rows.size());
				}
				
				if(actualOrderCount.equals(nooforders))
				{
					
					Reporter.log("Test Case for verification of number of orders has been Passed.", true);
					Reporter.log(
						"Number of Orders are maching, Expected: " + nooforders + " Actual: " + actualOrderCount, true);
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
				}
				else
				{
					
					Reporter.log("Test Case for verification of number of orders has been Failed.", true);
					Reporter.log(
						"Number of Orders not maching, Expected: " + nooforders + " Actual: " + actualOrderCount, true);
					fail1 = 0;
				}
				
				final String[] orderids_split = orderids.split("\\|");
				String ActualOrderidFullText;
				
				try
				{
					if(ExpShowMore.equals("YES"))
					{
						final WebElement downloadAllOrders =
								driver.findElement(By.xpath("//*[@id='q-render-table-order-list']/tfoot/tr/td/div/a[2]"));
						downloadAllOrders.click();	
							//Download directly
							final WebElement downloadDirectly =driver.findElement(By.xpath("//*[@class='download-directly']"));
							downloadDirectly.click();
							Reporter.log("'Download directly' button clicked", true);
							System.out.println("'Download directly' button clicked");
							Thread.sleep(1000);
							//Send to my mail
							downloadAllOrders.click();	
							final WebElement sendToMyEmail=	driver.findElement(By.xpath("//*[@class='send-to-my-email']"));
							sendToMyEmail.click();
							Reporter.log("'Send to my mail' button clicked", true);
							System.out.println("'Send to my mail' button clicked");
						
					}
					else
					{
					final WebElement downloadAllOrders =
						driver.findElement(By.xpath("//*[@id='q-render-table-order-list']/tfoot/tr/td/div/a"));
					downloadAllOrders.click();
					//Download directly
					final WebElement downloadDirectly =driver.findElement(By.xpath("//*[@class='download-directly']"));
					downloadDirectly.click();
					Reporter.log("'Download directly' button clicked", true);
					System.out.println("'Download directly' button clicked");
					Thread.sleep(1000);
					//Send to my mail
					downloadAllOrders.click();	
					
					final WebElement sendToMyEmail=	driver.findElement(By.xpath("//*[@class='send-to-my-email']"));
					sendToMyEmail.click();
					Reporter.log("'Send to my mail' button clicked", true);
					System.out.println("'Send to my mail' button clicked");
					}
					
					
					
					List<String> textFiles;
					
					textFiles = new ArrayList<String>();
					final File dir = new File(downloadDir);
					for(final File file: dir.listFiles())
					{
						if(file.getName().startsWith(("Orders")))
						{
							textFiles.add(file.getName());
						}
					}
					
					String allstirng = "";
					boolean check = true;
					for(final String s: textFiles)
					{
						if(!check)
						{
							allstirng += ',';
						}
						allstirng += s;
						check = false;
					}
					
					final String[] array = textFiles.toArray(new String[0]);
					
					final Workbook wb = Workbook.getWorkbook(new File(downloadDir + array[0]));
					final Sheet sh = wb.getSheet(0);
					final int totalrowsExcel = sh.getRows();
					final int totalOrders = totalrowsExcel - 1;
					actualOrderCount = Integer.toString(totalOrders);
					row_count = totalOrders;
					for(int row = 1; row <= row_count; row++)
					{
						Boolean flag = false;
						String ActualOrderidFullText1 = "";
						ActualOrderidFullText1 = sh.getCell(4, row).getContents();
						
						for(int i = 0; i < orderids_split.length; i++)
						{
							if(ActualOrderidFullText1.equals(orderids_split[i]))
							{
								
								Reporter.log("ClientOrderid "
									+ ActualOrderidFullText1
									+ " is present on monitoring GUI and expected", true);
								flag = true;
								orderids_split[i] = "Found";
								break;
							}
							
						}
						if(!flag)
						{
							
							Reporter.log("ClientOrderid "
								+ ActualOrderidFullText1
								+ " is present on monitoring GUI but not expected", true);
							fail2 = 0;
						}
					}
					
					for(int i = 0; i < orderids_split.length; i++)
					{
						if(orderids_split[i] != "Found")
						{
							fail2 = 0;
							Reporter.log(
								"ClientOrderid " + orderids_split[i] + " is expected but not present on monitoring GUI",
								true);
						}
					}
					
					System.out.println(
						"when orders are exceeding standard order limit , check is done using reading the excel successfully");
					
				}
				catch(final NoSuchElementException exc)
				{
					
					System.out.println("No of orders are not more than the standard limit");
					
					// Finding total number of orders when they are not exceeding the limit of 200 ,and checking those
					// orders are as expected
					
					for(int row = 1; row <= row_count; row++)
					{
						Boolean flag = false;
						ActualOrderidFullText =
							driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[" + row + "]/td[5]"))
								.getText();
						final String[] ActualOrderidSplit = ActualOrderidFullText.split("\\s+");
						
						for(int i = 0; i < orderids_split.length; i++)
						{
							if(ActualOrderidSplit[0].equals(orderids_split[i]))
							{
								
								Reporter.log("ClientOrderid "
									+ ActualOrderidSplit[0]
									+ " is present on monitoring GUI and expected", true);
								flag = true;
								orderids_split[i] = "Found";
								break;
							}
							
						}
						if(!flag)
						{
							
							Reporter.log("ClientOrderid "
								+ ActualOrderidSplit[0]
								+ " is present on monitoring GUI but not expected", true);
							fail2 = 0;
						}
					}
					
					for(int i = 0; i < orderids_split.length; i++)
					{
						if(orderids_split[i] != "Found")
						{
							fail2 = 0;
							Reporter.log(
								"ClientOrderid " + orderids_split[i] + " is expected but not present on monitoring GUI",
								true);
						}
					}
					
				}
				
				Reporter.log(
					"------------------------------------------------------------------------------------------", true);
				
				final WebElement firstrow =
					driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
				firstrow.click();
				final Actions actionObj = new Actions(driver);
				actionObj.keyDown(Keys.CONTROL)
					.sendKeys(Keys.chord("A"))
					.keyUp(Keys.CONTROL)
					.perform();
				try
				{
					Thread.sleep(2000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				
				final WebElement firstrow1 =
					new WebDriverWait(driver, 30)
						.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]")));
				
				final Actions actionObj1 = new Actions(driver);
				actionObj1.contextClick(firstrow1).sendKeys(Keys.RETURN).build().perform();
				
				// String actualDFDtxt;
				if(noofdfd.equals(nooforders))
				{
					
					final List<WebElement> DFDs = driver
						.findElements(By.xpath("//*[contains(text(),'" + dfdtext + " (" + noofdfd + " orders)')]"));
					
					if(DFDs.size() > 0)
					{
						Reporter.log("Test case for verification of number of DFDs has been Passed.", true);
						Reporter.log("Expected: " + dfdtext + " (" + noofdfd + " orders)", true);
						final WebElement dfdtxt = driver.findElement(
							By.xpath("//*[@id='right-click-menu-on-orders']//*[contains(text(),'" + dfdtext + "')]"));
						final String actualdfdtxt = dfdtxt.getText();
						Reporter.log("Actual: " + actualdfdtxt, true);
					}
					else
					{
						Reporter.log("Test case for verification of number of DFDs has been Failed.", true);
						Reporter.log("Expected: " + dfdtext + " (" + noofdfd + " orders)", true);
						final WebElement dfdtxt = driver.findElement(
							By.xpath("//*[@id='right-click-menu-on-orders']//*[contains(text(),'" + dfdtext + "')]"));
						final String actualdfdtxt = dfdtxt.getText();
						Reporter.log("Actual: " + actualdfdtxt, true);
						fail3 = 0;
					}
				}
				else if(noofdfd.equals("0"))
				{
					final List<WebElement> DFDs = driver.findElements(
						By.xpath("//*[contains(text(),'Save all to Excel (" + nooforders + " orders)')]"));
					// System.out.println( DFDs.size());
					
					if(DFDs.size() > 0)
					{
						Reporter.log("Test case for verification of number of DFDs has been Passed.", true);
						Reporter.log("Expected: Save all to Excel (" + nooforders + " orders)", true);
						final WebElement dfdtxt = driver.findElement(
							By.xpath("//*[@id='right-click-menu-on-orders']//*[contains(text(),'Save all to Excel')]"));
						final String actualdfdtxt = dfdtxt.getText();
						Reporter.log("Actual: " + actualdfdtxt, true);
					}
					else
					{
						Reporter.log("Test case for verification of number of DFDs has been Failed.", true);
						Reporter.log("Expected: Save all to Excel (" + nooforders + " orders)", true);
						final WebElement dfdtxt = driver.findElement(
							By.xpath("//*[@id='right-click-menu-on-orders']//*[contains(text(),'Save all to Excel')]"));
						final String actualdfdtxt = dfdtxt.getText();
						Reporter.log("Actual: " + actualdfdtxt, true);
						fail3 = 0;
					}
				}
				else
				{
					final List<WebElement> DFDs = driver.findElements(By
						.xpath("//*[contains(text(),'" + dfdtext + " (" + noofdfd + "/" + nooforders + " orders)')]"));
					
					if(DFDs.size() > 0)
					{
						Reporter.log("Test case for verifiacation of number of DFDs has been Passed.", true);
						Reporter.log("Expected: " + dfdtext + " (" + noofdfd + "/" + nooforders + " orders)", true);
						final WebElement dfdtxt = driver.findElement(
							By.xpath("//*[@id='right-click-menu-on-orders']//*[contains(text(),'" + dfdtext + "')]"));
						final String actualdfdtxt = dfdtxt.getText();
						Reporter.log("Actual: " + actualdfdtxt, true);
						
					}
					else
					{
						Reporter.log("Test case for verification of number of DFDs has been Failed.", true);
						Reporter.log("Expected: " + dfdtext + " (" + noofdfd + "/" + nooforders + " orders)", true);
						final WebElement dfdtxt = driver.findElement(
							By.xpath("//*[@id='right-click-menu-on-orders']//*[contains(text(),'" + dfdtext + "')]"));
						final String actualdfdtxt = dfdtxt.getText();
						Reporter.log("Actual: " + actualdfdtxt, true);
						fail3 = 0;
						
					}
				}
				
				driver.findElement(By.cssSelector("body")).sendKeys(Keys.ESCAPE);
				
			}
			else
			{
				Reporter.log("User does not have access to the Monitoring GUI", true);
			}
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			
			String contexttext;
			final List<WebElement> EMcount =
				driver.findElements(By.xpath("//*[@id='menu']//*[contains(text(),'engines')]"));
			
			if(EMcount.size() > 0)
			{
				final WebElement EM = driver.findElement(By.xpath("//*[@id='menu']//*[contains(text(),'engines')]"));
				EM.click();
				
				@SuppressWarnings("unused") final WebElement waitForOrder =
					new WebDriverWait(driver, 30)
						.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//*[contains(text(),'Engine States')]")));
				
				final WebElement AUT = driver.findElement(By.xpath("//*[@id='AUT-1']//a"));
				final Actions rightclick = new Actions(driver);
				rightclick.contextClick(AUT).build().perform();
				
				final List<WebElement> contextmenu =
					driver.findElements(By.xpath("//*[@prepopup-callback='engineNameMenuPrepopup']/q-button"));
				if(contextmenu.size() > 0)
				{
					// Reporter.log("User has the Right click access on Order Engine.", true);
					contexttext = "YES";
				}
				else
				{
					// Reporter.log("User does not have the Right click access on Order Engine.", true);
					contexttext = "NO";
					
				}
				
			}
			else
			{
				// Reporter.log("User does not have access to the Engine GUI.", true);
				contexttext = "NA";
			}
			
			if(ExpectedEMClick.equals(contexttext))
			{
				Reporter.log("Test case for Engine Manager Right Click has Passed", true);
				
				if(contexttext.equals("YES"))
				{
					Reporter.log("Expected : User should have the Right click access on Order Engine", true);
					Reporter.log("Actual : User has the Right click access on Order Engine", true);
				}
				else if(contexttext.equals("NO"))
				{
					Reporter.log("Expected : User should not have the Right click access on Order Engine", true);
					Reporter.log("Actual : User does not have the Right click access on Order Engine", true);
				}
				else if(contexttext.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Engine GUI", true);
					Reporter.log("Actual : User does not have access to the Engine GUI", true);
				}
				
			}
			else
			{
				Reporter.log("Test case for Engine Manager Right Click has Failed", true);
				fail7 = 0;
				
				if(ExpectedEMClick.equals("YES"))
				{
					Reporter.log("Expected : User should have the Right click access on Order Engine", true);
				}
				else if(ExpectedEMClick.equals("NO"))
				{
					Reporter.log("Expected : User should not have the Right click access on Order Engine", true);
				}
				else if(ExpectedEMClick.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Engine GUI", true);
				}
				else
				{
					// throw new IllegalArgumentException("Invalid value for parameter - EMClickable ");
					Reporter.log("Invalid value for parameter - EMClickable", true);
				}
				
				if(contexttext.equals("YES"))
				{
					Reporter.log("Actual : User has the Right click access on Order Engine", true);
				}
				else if(contexttext.equals("NO"))
				{
					Reporter.log("Actual : User does not have the Right click access on Order Engine", true);
				}
				else if(contexttext.equals("NA"))
				{
					Reporter.log("Actual : User does not have access to the Engine GUI", true);
				}
				
			}
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			
			String ActualAddPosText;
			final List<WebElement> Positioncount =
				driver.findElements(By.xpath("//*[@id='menu']//*[contains(text(),'positions')]"));
			
			if(Positioncount.size() > 0)
			{
				final WebElement Position =
					driver.findElement(By.xpath("//*[@id='menu']//*[contains(text(),'positions')]"));
				Position.click();
				
				@SuppressWarnings("unused") final WebElement waitForOrder =
					new WebDriverWait(driver, 30)
						.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//span[contains(text(),'Positions')]")));
				
				final List<WebElement> AddPosition =
					driver.findElements(By.xpath("//*[contains(text(),'Add Position')]"));
				
				if(AddPosition.size() > 0)
				{
					ActualAddPosText = "YES";
				}
				else
				{
					ActualAddPosText = "NO";
				}
				
			}
			else
			{
				ActualAddPosText = "NA";
			}
			
			if(ExpectedPosAdd.equals(ActualAddPosText))
			{
				Reporter.log("Test case for Positions Add Button has Passed", true);
				
				if(ActualAddPosText.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Add Position button", true);
					Reporter.log("Actual : User has access to Add Position button", true);
				}
				else if(ActualAddPosText.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Add Position button", true);
					Reporter.log("Actual : User does not have access to Add Position button", true);
				}
				else if(ActualAddPosText.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Positions GUI", true);
					Reporter.log("Actual : User does not have access to the Positions GUI", true);
				}
				
			}
			else
			{
				Reporter.log("Test case for Positions Add Button has Failed", true);
				fail8 = 0;
				
				if(ExpectedPosAdd.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Add Position button", true);
				}
				else if(ExpectedPosAdd.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Add Position button", true);
				}
				else if(ExpectedPosAdd.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Positions GUI", true);
				}
				else
				{
					Reporter.log("Invalid value for parameter - PositionAdd", true);
				}
				
				if(ActualAddPosText.equals("YES"))
				{
					Reporter.log("Actual : User has access to Add Position button", true);
				}
				else if(ActualAddPosText.equals("NO"))
				{
					Reporter.log("Actual : User does not have access to Add Position button", true);
				}
				else if(ActualAddPosText.equals("NA"))
				{
					Reporter.log("Actual : User does not have access to the Positions GUI", true);
				}
				
			}
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			
			String ActualReloadPosText;
			
			if(Positioncount.size() > 0)
			{
				
				final List<WebElement> ReloadPosition = driver.findElements(By.xpath("//*[contains(text(),'Reload')]"));
				
				if(ReloadPosition.size() > 0)
				{
					ActualReloadPosText = "YES";
				}
				else
				{
					ActualReloadPosText = "NO";
				}
				
			}
			else
			{
				ActualReloadPosText = "NA";
			}
			
			if(ExpectedPosReload.equals(ActualReloadPosText))
			{
				Reporter.log("Test case for Positions Reload Button has Passed", true);
				
				if(ActualAddPosText.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Reload button on Positions GUI", true);
					Reporter.log("Actual : User has access to Reload button on Positions GUI", true);
				}
				else if(ActualAddPosText.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Reload button on Positions GUI", true);
					Reporter.log("Actual : User does not have access to Reload button on Positions GUI", true);
				}
				else if(ActualAddPosText.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Positions GUI", true);
					Reporter.log("Actual : User does not have access to the Positions GUI", true);
				}
				
			}
			else
			{
				Reporter.log("Test case for Positions Reload Button has Failed", true);
				fail9 = 0;
				
				if(ExpectedPosAdd.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Reload button on Positions GUI", true);
				}
				else if(ExpectedPosAdd.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Reload button on Positions GUI", true);
				}
				else if(ExpectedPosAdd.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Positions GUI", true);
				}
				else
				{
					Reporter.log("Invalid value for parameter - PositionReload", true);
				}
				
				if(ActualAddPosText.equals("YES"))
				{
					Reporter.log("Actual : User has access to Reload button on Positions GUI", true);
				}
				else if(ActualAddPosText.equals("NO"))
				{
					Reporter.log("Actual : UUser does not have access to Reload button on Positions GUI", true);
				}
				else if(ActualAddPosText.equals("NA"))
				{
					Reporter.log("Actual : User does not have access to the Positions GUI", true);
				}
				
			}
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			
			String ActualAddClient;
			final List<WebElement> Clientcount =
				driver.findElements(By.xpath("//*[@id='menu']//*[contains(text(),'clients')]"));
			
			if(Clientcount.size() > 0)
			{
				final WebElement Client =
					driver.findElement(By.xpath("//*[@id='menu']//*[contains(text(),'clients')]"));
				Client.click();
				
				Thread.sleep(10000);
				
				final List<WebElement> AddClient =
					driver.findElements(By.xpath("//*[contains(text(),'Add a Client')]"));
				
				if(AddClient.size() > 0)
				{
					ActualAddClient = "YES";
				}
				else
				{
					ActualAddClient = "NO";
				}
				
			}
			else
			{
				ActualAddClient = "NA";
			}
			
			if(ExpAddClient.equals(ActualAddClient))
			{
				Reporter.log("Test case for Add Client Button has Passed", true);
				
				if(ActualAddClient.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Add Client button on Clients GUI", true);
					Reporter.log("Actual : User has access to Add Client button on Clients GUI", true);
				}
				else if(ActualAddClient.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Add Client button on Clients GUI", true);
					Reporter.log("Actual : User does not have access to Add Client button on Clients GUI", true);
				}
				else if(ActualAddClient.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Clients GUI", true);
					Reporter.log("Actual : User does not have access to the Clients GUI", true);
				}
				
			}
			else
			{
				Reporter.log("Test case for Add Client Button has Failed", true);
				fail10 = 0;
				
				if(ExpAddClient.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Add Client button on Clients GUI", true);
				}
				else if(ExpAddClient.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Add Client button on Clients GUI", true);
				}
				else if(ExpAddClient.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Clients GUI", true);
				}
				else
				{
					// throw new IllegalArgumentException("Invalid value for parameter - EMClickable ");
					Reporter.log("Invalid value for parameter - AddClient", true);
				}
				
				if(ActualAddClient.equals("YES"))
				{
					Reporter.log("Actual : User has access to Add Client button on Clients GUI", true);
				}
				else if(ActualAddClient.equals("NO"))
				{
					Reporter.log("Actual : UUser does not have access to Add Client button on Clients GUI", true);
				}
				else if(ActualAddClient.equals("NA"))
				{
					Reporter.log("Actual : User does not have access to the Clients GUI", true);
				}
				
			}
			
			Reporter.log("--------------------------------------------------------------------------------------",
				true);
			
			String ActualInsReload="NO";
			final String[] AllExpecReloadButtonslist = ExpInsReloadButtons.split("\\|");

						final List<WebElement> Inscount =
							driver.findElements(By.xpath("//*[@id='menu']//*[contains(text(),'symbols')]"));
					
						if(Inscount.size() > 0)
						{
							final WebElement Instrument =
								driver.findElement(By.xpath("//*[@id='menu']//*[contains(text(),'symbols')]"));
							Instrument.click();
							
							@SuppressWarnings("unused") final WebElement waitForOrder =
								new WebDriverWait(driver, 30)
									.until(ExpectedConditions
										.presenceOfElementLocated(By.xpath("//span[contains(text(),'Cautions')]")));

                final List<WebElement> InsReload = driver.findElements(By.xpath("//*[@class='leftnav']//*[@id='reload']"));
							
							if(InsReload.size() > 0)
							{
							    ActualInsReload = "YES";
							}
							else
							{
								ActualInsReload = "NO";
							}
							
				
							if(ActualInsReload.equals("YES"))
					   	{
								
								
							
							for(int buttonTotal = 0; buttonTotal < AllExpecReloadButtonslist.length; buttonTotal++)
					     	{
							Boolean flag = false;
							
							System.out.println("Expected Reload button : " + AllExpecReloadButtonslist[buttonTotal]);
							for(int i = 1; i <= AllExpecReloadButtonslist.length; i++)
							{
								try
								{
									final String xpathReloadButtonLoop=AllExpecReloadButtonslist[i];
								
								final List<WebElement>  ActualButton = driver.findElements(By.xpath("//*[@class='leftnav']//*[@id='"+xpathReloadButtonLoop+"']"));
								
								if(ActualButton.size()>0)
								{
									
									Reporter.log(AllExpecReloadButtonslist[buttonTotal] + " button is accesible by user as expected", true);
									flag = true;
									
									break;
								}
								}
								
								
								catch(final Exception e)
								{
								System.out.println("Reload Button  is not present on screen ");	
								}
							}
								
							
							
							
							
							if(!flag)
							{
								if(AllExpecReloadButtonslist[buttonTotal].equals("NA"))
								{
								Reporter.log("Expected is No Reload button should be shown but actual it is showing",true);	
								}
								else
								{Reporter.log(AllExpecReloadButtonslist[buttonTotal] + " button is not accessible by user which is not expected", true);
								}
								fail12 = 0;
							}
							
					
						}
						

						final String AllButtonslist[] = {
							"reload",
							"reloadFDA",
							"reloadPAE",
							"reloadNorthAmerica"};
						
						// int l = 0;
						
						final ArrayList<String> NoAccessButtons_list = new ArrayList<String>();
						
						for(int j = 0; j < AllButtonslist.length; j++)
						{
							Boolean flag = false;
							
							for(int k = 0; k < AllExpecReloadButtonslist.length; k++)
							{
								if(AllButtonslist[j].equals(AllExpecReloadButtonslist[k]))
								{
									flag = true;
									
									break;
									
								}
								
							}
							
							if(!flag)
							{
								NoAccessButtons_list.add(AllButtonslist[j]);
								System.out.println(AllButtonslist[j]);
							}
						}
						System.out.println("Checked for the list of buttons which should not be shown");
						
						if(NoAccessButtons_list.isEmpty())
						{
							System.out.println("All buttons are shown as expected");
						}
						else
						{
							
						final String[] NoAccessButtonslist_Split = new String[NoAccessButtons_list.size()];
						for(int m = 0; m < NoAccesstabs_split.length; m++)
							
							NoAccessButtonslist_Split[m] = NoAccessButtons_list.get(m).toString();
						
						System.out.println(NoAccessButtonslist_Split.length);
						
						for(int button = 0; button < NoAccessButtonslist_Split.length; button++)
						{
							Boolean flag = true;
							
							System.out.println("Not Expected Button : " + NoAccessButtonslist_Split[button]);
							for(int i = 1; i <= tab_count; i++)
							{
								Actualtab = driver.findElement(By.xpath("//*[@id='menu']//li[" + i + "]")).getText().trim();
								// System.out.println("Actual Tab : "+ Actualtab);
								if(Actualtab.equals(NoAccessButtonslist_Split[button]))
								{
									
									Reporter.log(NoAccessButtonslist_Split[button] + " is accesible by user which is not expected", true);
									flag = false;
									fail12 = 0;
									break;
								}
								
							}
							
							if(flag)
							{
								
								Reporter.log(NoAccessButtonslist_Split[button] + " is not accessible by user as expected", true);
								
							}
						}
						
	               	}
						
					   	}
							
	}
						
						
						else
						{
							ActualInsReload = "NA";
						}
						
						Reporter.log("-------------------------------------------------------------------------------------", true);		
			if(ExpInsReload.equals(ActualInsReload))
			{
				Reporter.log("Test case for Instrument Reload Button has Passed", true);
				
				if(ActualInsReload.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Instrument Reload buttons on Symbols GUI", true);
					Reporter.log("Actual : User has access to Instrument Reload buttons on Symbols GUI", true);
				}
				else if(ActualInsReload.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Instrument Reload buttons on Symbols GUI",
						true);
					Reporter.log("Actual : User does not have access to Instrument Reload buttons on Symbols GUI", true);
				}
				else if(ActualInsReload.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Symbols GUI", true);
					Reporter.log("Actual : User does not have access to the Symbols GUI", true);
				}
				
			}
			else
			{
				Reporter.log("Test case for Instrument Reload Button has Failed", true);
				fail11 = 0;
				
				if(ExpInsReload.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Instrument Reload button on Symbols GUI", true);
				}
				else if(ExpInsReload.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Instrument Reload button on Symbols GUI",
						true);
				}
				else if(ExpInsReload.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Symbols GUI", true);
				}
				else
				{
					Reporter.log("Invalid value for parameter - IntmntReload", true);
				}
				
				if(ActualInsReload.equals("YES"))
				{
					Reporter.log("Actual : User has access to Instrument Reload button on Symbols GUI", true);
				}
				else if(ActualInsReload.equals("NO"))
				{
					Reporter.log("Actual : User does not have access to Instrument Reload button on Symbols GUI",
						true);
				}
				else if(ActualInsReload.equals("NA"))
				{
					Reporter.log("Actual : User does not have access to the Symbols GUI", true);
				}
				
			}
			
			Reporter.log("-------------------------------------------------------------------------------------", true);
			
			String ActualAddUser;
			final List<WebElement> Usercount =
				driver.findElements(By.xpath("//*[@id='menu']//*[contains(text(),'users')]"));
			
			if(Usercount.size() > 0)
			{
				final WebElement User = driver.findElement(By.xpath("//*[@id='menu']//*[contains(text(),'users')]"));
				User.click();
				
				@SuppressWarnings("unused") final WebElement waitForOrder =
					new WebDriverWait(driver, 30)
						.until(
							ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Users')]")));
				
				final List<WebElement> AddUser =
					driver.findElements(By.xpath("//a[contains(text(),'Add a new user')]"));
				
				if(AddUser.size() > 0)
				{
					ActualAddUser = "YES";
				}
				else
				{
					ActualAddUser = "NO";
				}
				
			}
			else
			{
				ActualAddUser = "NA";
			}
			
			if(ExpAddUser.equals(ActualAddUser))
			{
				Reporter.log("Test case for Add User Button has Passed", true);
				
				if(ActualAddUser.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Add User button on Users GUI", true);
					Reporter.log("Actual : User has access to Add User button on Users GUI", true);
				}
				else if(ActualAddUser.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Add User button on Users GUI", true);
					Reporter.log("Actual : User does not have access to Add User button on Users GUI", true);
				}
				else if(ActualAddUser.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Users GUI", true);
					Reporter.log("Actual : User does not have access to the Users GUI", true);
				}
				
			}
			else
			{
				Reporter.log("Test case for Add User Button has Failed", true);
				fail13 = 0;
				
				if(ExpAddUser.equals("YES"))
				{
					Reporter.log("Expected : User should have access to Add User button on Users GUI", true);
				}
				else if(ExpAddUser.equals("NO"))
				{
					Reporter.log("Expected : User should not have access to Add User button on Users GUI", true);
				}
				else if(ExpAddUser.equals("NA"))
				{
					Reporter.log("Expected : User should not have access to the Users GUI", true);
				}
				else
				{
					Reporter.log("Invalid value for parameter - AddUser", true);
				}
				
				if(ActualAddUser.equals("YES"))
				{
					Reporter.log("Actual : User has access to Add User button on Users GUI", true);
				}
				else if(ActualAddUser.equals("NO"))
				{
					Reporter.log("Actual : User does not have access to Add User button on Users GUI", true);
				}
				else if(ActualAddUser.equals("NA"))
				{
					Reporter.log("Actual : User does not have access to the Users GUI", true);
				}
				
			}
			
			Reporter.log("------------------------------------------------------------------------------------------",
				true);
			
			if(fail1 == 1
				&& fail2 == 1
				&& fail3 == 1
				&& fail4 == 1
				&& fail5 == 1
				&& fail6 == 1
				&& fail7 == 1
				&& fail8 == 1
				&& fail9 == 1
				&& fail10 == 1
				&& fail11 == 1
				&& fail12 == 1
				&& fail13 == 1
				&& fail14 == 1)
			{
				Assert.assertTrue(true);
				
			}
			else
			{
				Assert.fail("!-v!!Test Case for User Permission check has failed!!!");
			}
			
		}
		catch(final Exception e)
		{
			Assert.fail("Selenium Error : User Permission check has Failed due to an exception !!!!!!!!!!!!!!! "
				+ e.getMessage());
			System.out.println("GUI check : Failed due to an exception : " + e.getMessage());
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
			
		}
		
	}
	
	@AfterTest
	public void CloseBrowser()
	{
		driver.close();
		driver.quit();
	}
	
}
