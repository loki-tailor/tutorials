package com.mizuhosc.selenium.scripts.enginemanager;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.testng.annotations.*;

import sun.misc.BASE64Decoder;

public class PrepareSession {
	WebDriver driver = null;

	@Test
	@Parameters({ "username", "password", "quattroEnv", "browser" })
	public void prepareSessionState(String user, String pass, String monEnv, String browser) {
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try {
			// System.out.println("My username is " + user + "monitoring Env" +
			// monEnv + "browser" + browser);

			// Selects appropraite driver
			if (browser.equals("Mozilla")) {
				driver = new FirefoxDriver();
			} else if (browser.equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			} else if (browser.equals("IE")) {
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(new String(new BASE64Decoder().decodeBuffer(pass)));
			driver.findElement(By.name("username")).submit();

			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.get("http://tkqtrapq17.mizuho-sc.com:9000/enginemanager/listEnginesSupport");

			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.findElement(By.xpath("//*[@id='menu']/li[1]/p/a/span[2]")).click();

			/***
			 * TODO Q - Why does the search for below xpath i.e. RAD2 vanishes
			 * as soon as we search it, is there another way to view it?
			 */
			WebElement webElement = driver.findElement(By.xpath("//*[@id='RAD-2']/td[2]/div"));
			Actions rightClick = new Actions(driver);

			/***
			 * TODO Q - Why are we clicking "RESUME RAD-2 market session", what
			 * happens post it?
			 */
			// rightClick.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			rightClick.contextClick(webElement).moveByOffset(100, 70).click().build().perform();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.switchTo().alert().accept();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			/***
			 * TODO Q - What is it that was being tried to achieved in below
			 * code?? Getting "NoSuchElementException" !!
			 */

			driver.findElement(By.xpath("/html/body/div[3]/ul/li[2]/a/span[2]")).click();

			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			WebElement getRightClick = driver.findElement(By.xpath("//tbody/tr[1]/td[4]/div"));
			Actions rightClick2 = new Actions(driver);
			// rightClick.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			rightClick2.contextClick(getRightClick).moveByOffset(100, 70).click().build().perform();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.switchTo().alert().accept();
			// driver.close();
			// driver.quit();
		} catch (Exception e) {
			System.out.println("ERRORRRR");
			e.printStackTrace();
		}
	}

	@AfterTest
	public void CloseBrowser() {
		driver.close();
		driver.quit();
	}

}
