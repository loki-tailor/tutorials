package com.mizuhosc.selenium.scripts.allocation;

import com.mizuhosc.selenium.functionlibraries.CommonFunctions;
import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.scripts.util.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;
import com.mizuhosc.selenium.functionlibraries.*;

public class Allocation
{
	
	private static final String SeleniumAutomation_Workspace_Path = Configuration.SINGLETON.getProperty("selenium.Automation.path");
	private static final String ACTUAL_CLIENT_ALLOCATIONS = Configuration.SINGLETON.getProperty("selenium.Allocation.ActualFIXFile.path");
	private static final String EXPECTED_CLIENT_ALLOCATIONS = Configuration.SINGLETON.getProperty("selenium.Allocation.ExpectedFIXFile.path");
	private static final String DIFF_JAPAN_CSV = Configuration.SINGLETON.getProperty("selenium.Allocation.JapanCSVDifffile.path");
	private static final String DIFF_PANASIA_CSV = Configuration.SINGLETON.getProperty("selenium.Allocation.PanAsiaCSVDifffile.path");
	private static final String FIXDiffFilepath = Configuration.SINGLETON.getProperty("selenium.Allocation.FIXDifffile.path");
	private static final String AppiaIniFilePath = Configuration.SINGLETON.getProperty("selenium.Allocation.appiainifile.path");
	private static final String AutomationScriptsPath = Configuration.SINGLETON.getProperty("selenium.Automation.Scripts.path");
	private static final String AutomationLogsPath = Configuration.SINGLETON.getProperty("selenium.Automation.Logs.path");
	private static final String SELENIUM_ENVIRONMENT = "QA10";
	private static final String SeleniumAutomation_PreAllocationBat_Path = Configuration.SINGLETON.getProperty("selenium.Allocation.PreBatchfile.path");
	private static final String SeleniumAutomation_PostAllocationBat_Path = Configuration.SINGLETON.getProperty("selenium.Allocation.PostBatchfile.path");
	private int rowCount = 0;
	private static final String ExpectedMarathonString = "Passed";
	private static final String JIRA_Number = "SEL-99";
	private static String testResultString = "";
	private static String releaseVersion = "";
	private static String marathonResult = "";
	
	@Parameters({
		"File_Order1",
		"caseId"})
	@Test
	public void Allocation(
			final String order,
			final int caseId) throws IOException, InterruptedException
	
	{
	RunAllocationBatchCommand(SeleniumAutomation_PreAllocationBat_Path);
	sendAllocationAndWait(order);
	RunAllocationBatchCommand(SeleniumAutomation_PostAllocationBat_Path);
	
	generateAllocationAckDiffFile();
	
	rowCount=CommonFunctions.CountRows(DIFF_JAPAN_CSV);
	Reporter.log(String.format("[%s RowCount of %s is %s",CommonFunctions.getTimeStamp(),DIFF_JAPAN_CSV,rowCount),true);
	UpdateTestCaseResults(rowCount,"Japan Allocation CSV",0);
	
	rowCount=CommonFunctions.CountRows(DIFF_PANASIA_CSV);
	UpdateTestCaseResults(rowCount,"PanAsia Allocation CSV",0);
	Reporter.log(String.format("[%s RowCount of %s is %s",CommonFunctions.getTimeStamp(),DIFF_PANASIA_CSV,rowCount),true);
	
	rowCount=CommonFunctions.CountRows(FIXDiffFilepath);
	UpdateTestCaseResults(rowCount,"FIX Diff",1);
	Reporter.log(String.format("[%s RowCount of %s is %s",CommonFunctions.getTimeStamp(),FIXDiffFilepath,rowCount),true);

	releaseVersion=CommonFunctions.GetReleaseVersion();
	WebDriver driver = null;

	if ( testResultString.indexOf(ExpectedMarathonString) != -1 ) 	{	
		Reporter.log(String.format("[%s Found the ExpectedMarathonString - %s in testResultString - %s. Will Pass the Marathon Case",CommonFunctions.getTimeStamp(),ExpectedMarathonString, testResultString),true);
		marathonResult="Passed";
		CommonFunctions.updateResult(caseId, releaseVersion, marathonResult, testResultString, JIRA_Number, driver, "TRUE");
	}
    else {
		
		Reporter.log(String.format("[%s Not Found the ExpectedMarathonString - %s in testResultString - %s. Will fail the Marathon Case",CommonFunctions.getTimeStamp(),ExpectedMarathonString, testResultString),true);
		marathonResult="Failed";
		CommonFunctions.updateResult(caseId, releaseVersion, marathonResult, testResultString, JIRA_Number, driver, "TRUE");
		Assert.fail("testResultString");
	}

	
	
}
		
	
	private void UpdateTestCaseResults(final int ActualRowCount, final String TestCase, final int ExpectedRowCount)
	{
		if ( ActualRowCount == ExpectedRowCount )
		{
			Reporter.log(String.format("[%s ExpectedRowCount %s matches with ActualRowCount %s for %s",CommonFunctions.getTimeStamp(),ExpectedRowCount,ActualRowCount,TestCase),true);
			testResultString = testResultString + TestCase + "Passed|";
		}
		else
		{
			Reporter.log(String.format("[%s ExpectedRowCount %s does not match with ActualRowCount %s for %s",CommonFunctions.getTimeStamp(),ExpectedRowCount,ActualRowCount,TestCase),true);
			testResultString = testResultString + TestCase + "Failed|";
		}
	}
	

	private void sendAllocationAndWait(final String order)
	{
		try
		{
			Reporter.log(String.format("[%s Send Allocations] Pumping Allocations.", CommonFunctions.getTimeStamp()), true);
			Reporter.log(String.format("Pumping allocations from file %s", order),true);
			Reporter.log(String.format("Using Appia Ini File %s", AppiaIniFilePath),true);
			new ULBridgeFIXReplay2(order, ULBridgeFIXReplay2.ConnectionType.CLIENT2GOR, 1000, AppiaIniFilePath);
			Thread.sleep(90000);
			Reporter.log(String.format("[%s Send Allocations] Finished pumping Allocations.", CommonFunctions.getTimeStamp()), true);
		}
		catch(final Exception e)
		{
			Reporter.log(String.format("[%s Send Allocations] ERROR Found %s exception while pumping Allocations.", CommonFunctions.getTimeStamp(),
				e.getMessage()));
		}
		
	}
	
	private void RunAllocationBatchCommand(final String AllocationBatch) throws IOException, InterruptedException
	{
		Reporter.log(String.format("[%s Preparation Allocations Test] Running Batch %s", CommonFunctions.getTimeStamp(),AllocationBatch), true);
		CommonFunctions.RunWindowsBatchCommand(AllocationBatch,20000,AutomationScriptsPath,AutomationLogsPath);
		
	}
	
	private void generateAllocationAckDiffFile()
	{
		try
		{
			
			Reporter.log(String.format("[%s Allocation Ack Comparision] Printing Expected Allocation file (%s)", CommonFunctions.getTimeStamp(),
				EXPECTED_CLIENT_ALLOCATIONS), true);
			CommonFunctions.printFileContents(EXPECTED_CLIENT_ALLOCATIONS);
			
			Reporter.log(String.format("[%s Allocation Ack Comparision] Printing Actual Allocation file (%s)", CommonFunctions.getTimeStamp(),
				ACTUAL_CLIENT_ALLOCATIONS), true);
			CommonFunctions.printFileContents(ACTUAL_CLIENT_ALLOCATIONS);
			
			Reporter.log(String.format("[%s Allocation File Comparision] Comparing Allocation files.", CommonFunctions.getTimeStamp()), true);
			FIXDiff2.main(new String[] {EXPECTED_CLIENT_ALLOCATIONS, ACTUAL_CLIENT_ALLOCATIONS, FIXDiffFilepath });
			
			Thread.sleep(8000);
			
		}
		catch(IOException | InterruptedException e)
		{
			Reporter.log(String.format(
				"[%s Allocation File Comparision] ERROR Found %s Exception while comparing Allocation log files", CommonFunctions.getTimeStamp(),
				e.getMessage()));
			Assert.fail("ERROR Found while comparing Allocation log files.Hence failing the case");
		}
		Reporter.log(String.format("[%s Allocation File Comparision] Allocation files comparision finished.", CommonFunctions.getTimeStamp()), true);
	}
	

	}