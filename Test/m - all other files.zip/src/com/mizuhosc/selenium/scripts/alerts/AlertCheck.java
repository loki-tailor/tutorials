package com.mizuhosc.selenium.scripts.alerts;

import com.mizuhosc.selenium.functionlibraries.CommonFunctions;
import com.mizuhosc.selenium.scripts.util.*;
import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.testng.*;
import org.testng.annotations.*;
	
public class AlertCheck

{
	String testResult;
	private WebDriver driver; // Selects appropraite driver
	
	@Parameters({"username", "password", "quattroEnv", "browser" ,"File_Order1" ,"MarathonID"})
	@Test
	public void SessionAlert(final String user, final String pass, final String monEnv, final String browser, final String Order1, final int MarathonID)
	{	
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			//http://tkqtrapq12.mizuho-sc.com:9010
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
		
			// Changing URL as previous URL is changes on quattro alert server.
			driver.get("http://tkqtrapq18.mizuho-sc.com:9080/subscriptions/user/76");
			Thread.sleep(1000);
			
			//subscribe to session connect and disconnect alert
			if(!driver.findElement(By.xpath("//*[@id='subscriptions-6927']/span/label[1]")).isSelected())
				driver.findElement(By.xpath("//*[@id='subscriptions-6927']/span/label[1]")).click();
			if(!driver.findElement(By.xpath("//*[@id='subscriptions-6928']/span/label[1]")).isSelected())
				driver.findElement(By.xpath("//*[@id='subscriptions-6928']/span/label[1]")).click();
			//6711-Disconnect session
			
			System.out.println("Session connect and disconnect alerts are subscribed");
			Thread.sleep(1000);
			
			
			// navigate to alerts tab
			driver.findElement(By.xpath("/html/body/div[2]/ul/li[1]/a/span[2]/span[1]")).click();
			
			int DisconnectCountOld = Integer.parseInt(driver.findElement(By.xpath("//tr[@id='6928']/td[3]")).getText());
			
			int ConnectCountOld = Integer.parseInt(driver.findElement(By.xpath("//tr[@id='6927']/td[3]")).getText());
			
			//Connect a session and send an order
			final ULBridgeFIXReplay ulBridgeFIXReplay = new ULBridgeFIXReplay(Order1,
					ULBridgeFIXReplay.ConnectionType.CLIENT2GOR, 5000);
			
		
			Thread.sleep(45000);
					
			
			driver.findElement(By.xpath("/html/body/div[2]/ul/li[1]/a/span[2]/span[1]")).click();
			//wait for 10 seconds to refresh alerts
			Thread.sleep(10000);
			driver.get("http://tkqtrapq18.mizuho-sc.com:9080/subscriptions/user/76");
			//driver.get("http://tkqtrapq18.mizuho-sc.com:9080/subscriptions");
			Thread.sleep(1000);
			driver.findElement(By.xpath("/html/body/div[2]/ul/li[1]/a/span[2]/span[1]")).click();
			Thread.sleep(2000);
			int DisconnectCountNew = Integer.parseInt(driver.findElement(By.xpath("//tr[@id='6928']/td[3]")).getText());
			System.out.println("New alert count for session disconnect alert is: "+ DisconnectCountNew);
			System.out.println("Old alert count for session disconnect alert is: "+ DisconnectCountOld);
			int ConnectCountNew = Integer.parseInt(driver.findElement(By.xpath("//tr[@id='6927']/td[3]")).getText());
			String DisconnectMessage = driver.findElement(By.xpath("//tr[@id='6928']/td[4]")).getText();
			System.out.println(DisconnectMessage);
			String ConnectMessage = driver.findElement(By.xpath("//tr[@id='6927']/td[4]")).getText();
			System.out.println(ConnectMessage);
			System.out.println("New alert count for session connect alert is: "+ ConnectCountNew);
			System.out.println("Old alert count for session connect alert is: "+ ConnectCountOld);
			
			if (ConnectCountNew==ConnectCountOld+3)
			{
				if(ConnectMessage.equalsIgnoreCase("(RAD-2) MITGR2_C session connected") && DisconnectMessage.equalsIgnoreCase("(RAD-2) MITGR2_C session disconnected"))
				System.out.println("alert is raised for session connect and disconnect");
				UpdateResult(MarathonID,true);	
				// System.out.println("test push");
				// comment test
			}
			
			else
			{
				System.out.println("alert is not raised");
				UpdateResult(MarathonID,false);
				Assert.fail("Alert was not generated for session connecst and disconnect");
			}
			
			driver.get("http://tkqtrapq18.mizuho-sc.com:9080/subscriptions/user/76");
			Thread.sleep(1000);
						
			//if(!driver.findElement(By.xpath("//*[@id='subscriptions-6927']/span/label[1]")).isSelected())
				driver.findElement(By.xpath("//*[@id='subscriptions-6927']/span/label[1]")).click();
			//if(!driver.findElement(By.xpath("//*[@id='subscriptions-6928']/span/label[1]")).isSelected())
				driver.findElement(By.xpath("//*[@id='subscriptions-6928']/span/label[1]")).click();
			
			//tr[@id="6711"]/td[3]
			
			
			
 			
				
		
		driver.close();
		driver.quit();

//			
//			
		}
		catch(final Exception e)
		{
			Reporter.log("Test Case has Failed due to an exception");
			
			Assert.fail("Selenium Error : check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
					
			driver.close();
			 driver.quit();
		}
	}
//	
	
	
	
	public void UpdateResult(final int MarathonID, final boolean Result) throws InterruptedException
	{
		// Get release version for QA1- from release version dashboard and update Marathon case
		driver.get("http://tkqtrapq2:8000/FidessaConnectivity.html");
		String releaseVersion=CommonFunctions.GetReleaseVersion();
		
		
		//final WebElement fetchData = driver.findElement(By.xpath("//*[@id='env-status']/tbody/tr/td[1][contains(.,'QA10')]//..//td[2]"));
		//CharSequence releaseVersion = fetchData.getText();
		//releaseVersion=releaseVersion.subSequence(3,9).toString();
		
		System.out.println("Release version ruuning on QA10 is " + releaseVersion);
		
		driver.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + MarathonID);
		try {
			Thread.sleep(1000);
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//*[contains(text(),'Enter Result')]")).click();
		try {
			Thread.sleep(1000);
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//*[contains(text(),'Edit')]")).click();
		if (Result==true){
				driver.findElement(By.xpath("//*[contains(text(),'Passed')]")).click();
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input")).sendKeys("Passed on "+ releaseVersion );
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input")).sendKeys("QTR-10444");
				driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
				Thread.sleep(3000);
				System.out.println("Case Passed");
				
				
		}
		else{
			driver.findElement(By.xpath("//*[contains(text(),'Failed')]")).click();
			driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input")).sendKeys("Failed on "+ releaseVersion );
			driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input")).sendKeys("QTR-10444");
			driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
			Thread.sleep(3000);
			System.out.println("Case Failed");
		}
		
		
		
		
	}
	
}
