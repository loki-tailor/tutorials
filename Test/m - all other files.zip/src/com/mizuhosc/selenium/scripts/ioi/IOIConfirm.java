package com.mizuhosc.selenium.scripts.ioi;

import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.functionlibraries.CommonFunctions;
import com.mizuhosc.selenium.scripts.util.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class IOIConfirm
{
	private static final String SeleniumAutomation_Workspace_Path = Configuration.SINGLETON.getProperty("selenium.Automation.path");
	private static final String ACTUAL_CLIENT_IOIS =
			SeleniumAutomation_Workspace_Path +"\\IOIMessage\\ActualClientIOI.log";
	private static final String EXPECTED_CLIENT_IOIS =
			SeleniumAutomation_Workspace_Path +"\\IOIMessage\\ExpectedClientIOI.log";
	private static final String SELENIUM_ENVIRONMENT = "QA10";
	private static final String JIRA_NUMBER = "QTR-10372";
	private String testResultMessage = new String();
	private WebDriver driver; // Selects appropraite driver
	private boolean marathonResult = false;
	private int rowCount = 0;
	
	private static final String FixDiffFilePath= SeleniumAutomation_Workspace_Path +"\\diffs\\FIXDiff.csv";
	private static final String SeleniumAutomation_IOIBat_Path = Configuration.SINGLETON.getProperty("selenium.Automation.IOIbat.path");
	
	private Map<String, String> firstRowIOI = new HashMap<>();
	private Map<String, String> secondRowIOI = new HashMap<>();
	private Map<String, String> thirdRowIOI = new HashMap<>();
	
	private final HashMap<Integer, Map<String, String>> allIOIs = new HashMap<>();
	private final HashMap<Integer, Map<String, String>> allUIIOIElements = new HashMap<>();
	private final List<String> allUIIOIHeaders = new ArrayList<>();
	private final List<String> unmatchedHeaders = new ArrayList<>();
	
	@Parameters({
		"username",
		"password",
		"quattroEnv",
		"browser",
		"File_Order1",
		"IsNatural1",
		"Side1",
		"Symbol1",
		"Shares1",
		"Quality1",
		"Price1",
		"Text1",
		"CLientList1",
		"Currency1",
		"Qualifiers1",
		"TransactionType1",
		"Status1",
		"IsNatural2",
		"Side2",
		"Symbol2",
		"Shares2",
		"Quality2",
		"Price2",
		"Text2",
		"CLientList2",
		"Currency2",
		"Qualifiers2",
		"TransactionType2",
		"Status2",
		"IsNatural3",
		"Side3",
		"Symbol3",
		"Shares3",
		"Quality3",
		"Price3",
		"Text3",
		"CLientList3",
		"Currency3",
		"Qualifiers3",
		"TransactionType3",
		"Status3",
		"caseId"})
	@Test
	public void IOIConfirm(
		final String user,
		final String pass,
		final String monEnv,
		final String browser,
		final String order,
		final String IsNatural1,
		final String Side1,
		final String Symbol1,
		final String Shares1,
		final String Quality1,
		final String Price1,
		final String Text1,
		final String CLientList1,
		final String Currency1,
		final String Qualifiers1,
		final String TransactionType1,
		final String Status1,
		final String IsNatural2,
		final String Side2,
		final String Symbol2,
		final String Shares2,
		final String Quality2,
		final String Price2,
		final String Text2,
		final String CLientList2,
		final String Currency2,
		final String Qualifiers2,
		final String TransactionType2,
		final String Status2,
		final String IsNatural3,
		final String Side3,
		final String Symbol3,
		final String Shares3,
		final String Quality3,
		final String Price3,
		final String Text3,
		final String CLientList3,
		final String Currency3,
		final String Qualifiers3,
		final String TransactionType3,
		final String Status3,
		final int caseId)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		
		if(browser.equals("Mozilla"))
		{
			driver = new FirefoxDriver();
		}
		else if(browser.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
		}
		else if(browser.equals("IE"))
		{
			final File file = new File("drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
		}
		// Log into Monitoring screen
		Reporter.log("Login to Monitoring server", true);
		driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
		Reporter.log("Current time is :" + Calendar.getInstance(), true);
		driver.findElement(By.name("username")).sendKeys(user);
		driver.findElement(By.name("password")).sendKeys(pass);
		driver.findElement(By.name("username")).submit();
		
		Reporter.log("Preparing IOI expected test-data (values passed from xml) to compare IOI Screen values.", true);
		
		fetchIOIHeaders();
		
		firstRowIOI = prepareIOIList(IsNatural1, Side1, Symbol1, Shares1, Quality1, Price1,
			Text1, CLientList1, Currency1, Qualifiers1, TransactionType1, Status1);
		allIOIs.put(0, firstRowIOI);
		
		secondRowIOI = prepareIOIList(IsNatural2, Side2, Symbol2, Shares2, Quality2, Price2,
			Text2, CLientList2, Currency2, Qualifiers2, TransactionType2, Status2);
		allIOIs.put(1, secondRowIOI);
		
		thirdRowIOI = prepareIOIList(IsNatural3, Side3, Symbol3, Shares3, Quality3, Price3,
			Text3, CLientList3, Currency3, Qualifiers3, TransactionType3, Status3);
		allIOIs.put(2, thirdRowIOI);
		
		sendIOIAndWait(order);
		
		compareIOIFiles();
		
		fetchIOIDetails();
		
		uIIOIComparision();
		
		updateResult(caseId);
		
		driver.close();
		
		if(!unmatchedHeaders.isEmpty())
		{
			Reporter
				.log(String.format("Selenium Case Failed: Due to %d mismatch(s) on IOI screen.",
					unmatchedHeaders.size()), true);
			Assert.fail(testResultMessage);
		}
	}
	
	private void sendIOIAndWait(final String order)
	{
		try
		{
			Reporter.log(String.format("[%s Send IOIs] Pumping IOI orders.", getTimeStamp()), true);
			new ULBridgeFIXReplay(order, ULBridgeFIXReplay.ConnectionType.CLIENT2GOR, 1000);
			Thread.sleep(120000);
			Reporter.log(String.format("[%s Send IOIs] Finished pumping IOI orders.", getTimeStamp()), true);
		}
		catch(final Exception e)
		{
			Reporter.log(String.format("[%s Send IOIs] ERROR Found %s exception while pumping IOIs.", getTimeStamp(),
				e.getMessage()));
		}
		
	}
	
	private void compareIOIFiles()
	{
		try
		{
			Reporter.log(String.format("[%s IOI File Comparision] Comparing IOI log files.", getTimeStamp()), true);
//			Runtime.getRuntime()
//				.exec("cmd /c start I:\\IT_WSD\\FIX\\Selenium.Automation\\Scripts\\CreateActualIOILogFile.bat");
			
			System.out.println("Found path for SeleniumAutomation_IOIBat_Path : " + SeleniumAutomation_IOIBat_Path );
			Runtime.getRuntime()
        		.exec("cmd /c start "+ SeleniumAutomation_IOIBat_Path);
			
			
			Reporter.log(String.format("[%s IOI File Comparision] Waiting for 2 minutes.", getTimeStamp()), true);
			Thread.sleep(120000);// Waiting for 2 minutes to finish the script
			
			Reporter.log(String.format("[%s IOI File Comparision] Printing Expected IOI file (%s)", getTimeStamp(),
				EXPECTED_CLIENT_IOIS), true);
			_printFileContents(EXPECTED_CLIENT_IOIS);
			
			Reporter.log(String.format("[%s IOI File Comparision] Printing Actual IOI file (%s)", getTimeStamp(),
				ACTUAL_CLIENT_IOIS), true);
			_printFileContents(ACTUAL_CLIENT_IOIS);
			
			Reporter.log(String.format("[%s IOI File Comparision] Comparing IOI files.", getTimeStamp()), true);
			FIXDiff.main(new String[] {EXPECTED_CLIENT_IOIS, ACTUAL_CLIENT_IOIS});
			
			Thread.sleep(8000);
			
			CountRows(FixDiffFilePath);
			Reporter.log(
				String.format("[%s IOI File Comparision] Number of rows in CSV file : %d", getTimeStamp(), rowCount),
				true);
		}
		catch(IOException | InterruptedException e)
		{
			Reporter.log(String.format(
				"[%s IOI File Comparision] ERROR Found %s Exception while comparing IOI log files", getTimeStamp(),
				e.getMessage()));
		}
		Reporter.log(String.format("[%s IOI File Comparision] IOI files comparision finished.", getTimeStamp()), true);
	}
	
	public void CountRows(final String fileName) throws IOException
	{
		final BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
		String input;
		while((input = bufferedReader.readLine()) != null)
		{
			rowCount++;
		}
		bufferedReader.close();
	}
	
	private Map<String, String> prepareIOIList(
		final String isNatural,
		final String side,
		final String symbol,
		final String shares,
		final String quality,
		final String price,
		final String text,
		final String cLientList,
		final String currency,
		final String qualifiers,
		final String transactionType,
		final String status)
	{
		final HashMap<String, String> ioiRowElements = new HashMap<>();
		ioiRowElements.put("Natural", isNatural);
		ioiRowElements.put("Side", side);
		ioiRowElements.put("Symbol", symbol);
		ioiRowElements.put("Shares", shares);
		ioiRowElements.put("Quantity", quality);
		ioiRowElements.put("Price", price);
		ioiRowElements.put("Text", text);
		ioiRowElements.put("Client List", cLientList);
		ioiRowElements.put("Currency", currency);
		ioiRowElements.put("Qualifiers", qualifiers);
		ioiRowElements.put("TransType", transactionType);
		ioiRowElements.put("Status", status);
		return ioiRowElements;
	}
	
	private void fetchIOIHeaders()
	{
		Reporter.log(String.format("[%s Getting IOI Headers] Fetching IOI table headers.", getTimeStamp()), true);
		try
		{
			driver.get("http://tkqtrapq17.mizuho-sc.com:9030/ioi");
			final WebDriverWait thirtySecondWait = new WebDriverWait(driver, 30);
			final WebElement xpathOfTableHead = thirtySecondWait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='todays-ioi']//thead")));
			
			Reporter
				.log(String.format("[%s Getting IOI Headers] Checking IOI individual element visiable on IOI screen.",
					getTimeStamp()), true);
			final List<WebElement> headerRows = xpathOfTableHead.findElements(By.tagName("tr"));
			for(int i = 0; i < headerRows.size(); i++)
			{
				for(final WebElement webElement: headerRows.get(i).findElements(By.tagName("th")))
				{
					allUIIOIHeaders.add(webElement.getText());
				}
			}
		}
		catch(final Exception e)
		{
			Reporter
				.log(String.format("[%s Getting IOI Headers] ERROR %s when fetching IOI table headers.", getTimeStamp(),
					e.getMessage()));
		}
		
	}
	
	private void fetchIOIDetails()
	{
		Reporter.log(String.format("[%s Collecting IOI Details] Fetching IOI details from UI.", getTimeStamp()), true);
		try
		{
			driver.get("http://tkqtrapq17.mizuho-sc.com:9030/ioi");
			final WebDriverWait thirtySecondWait = new WebDriverWait(driver, 30);
			final WebElement xpathOfTableBody = thirtySecondWait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='todays-ioi']//tbody")));
			final List<WebElement> bodyRows = xpathOfTableBody.findElements(By.tagName("tr"));
			for(int i = 0; i < bodyRows.size(); i++)
			{
				final Map<String, String> bodyColumnValues = new HashMap<>();
				final List<WebElement> bodyColumns = bodyRows.get(i).findElements(By.tagName("td"));
				for(int j = 0; j < bodyColumns.size(); j++)
				{
					bodyColumnValues.put(allUIIOIHeaders.get(j), bodyColumns.get(j).getText());
				}
				allUIIOIElements.put(i, bodyColumnValues);
			}
		}
		catch(final Exception e)
		{
			Reporter.log(String.format("[%s Collecting IOI Details]  ERROR %s when  Fetching IOI details from UI",
				getTimeStamp(), e.getMessage()));
		}
	}
	
	private void uIIOIComparision()
	{
		Reporter.log(
			String.format("[%s UI IOI details check] Comparing IOI UI details with test data.", getTimeStamp()), true);
		try
		{
			if(allUIIOIElements.size() == allIOIs.size())
			{
				for(int row = 0; row < allIOIs.size(); row++)
				{
					final Map<String, String> testCaseIOIElements = allIOIs.get(row);
					final Map<String, String> screenElements = allUIIOIElements.get(row);
					final String ioiId = screenElements.get("IOI Id");
					for(final String header: allUIIOIHeaders)
					{
						if(testCaseIOIElements.containsKey(header))
						{
							final String actual = screenElements.get(header);
							final String expected = testCaseIOIElements.get(header);
							if(!expected.equals(actual))
							{
								unmatchedHeaders.add(header);
								Reporter.log(String.format(
									"[%s IOI UI Comparision] ERROR: \"%s\" IOI \"%s\" column \"%s\" "
										+ "(actual) not matched with \"%s\" (expected).",
									getTimeStamp(), ioiId, header, actual, expected), true);
							}
						}
						else
						{
							Reporter.log(String.format(
								"[%s IOI UI Comparision] WARNING: Ignoring %s header, because it is not present in xml",
								getTimeStamp(), header));
						}
						
					}
				}
			}
		}
		catch(final Exception e)
		{
			Reporter.log(
				String.format("[%s UI IOI details check]  ERROR %s when comparing IOI UI details with test data.",
					getTimeStamp(), e.getMessage()));
		}
	}
	
	private void testResult()
	{
		if(rowCount == 1)
		{
			if(unmatchedHeaders.isEmpty())
			{
				Reporter.log("Passing case as GUI and FIX message verifications are successful.", true);
				testResultMessage = "Passing case as GUI and FIX message verifications are successful.";
				marathonResult = true;
			}
			else
			{
				Reporter.log(
					"Failing case as GUI verification is mismatched and FIX message verifications are successful.",
					true);
				testResultMessage =
					"Failing case as GUI verification is mismatched and FIX message verifications are successful.";
			}
		}
		else
		{
			if(unmatchedHeaders.isEmpty())
			{
				Reporter.log("Failing the case as GUI verification is passed but Fix message verification is failed.",
					true);
				testResultMessage =
					"Failing the case as GUI verification is passed but Fix message verification is failed.";
			}
			else
			{
				Reporter.log(
					"Failing the case as GUI verification is Mismatched and Fix message verification is failed.", true);
				testResultMessage =
					"Failing the case as GUI verification is Mismatched and Fix message verification is failed.";
			}
		}
	}
	
	public void updateResult(final int caseId)
	{
		try
		{
			testResult();// setting test result message based on File and UI checks
			
			Reporter.log(String.format("[%s Marathon] Updating Marathon test result.", getTimeStamp()), true);
			// Get release version for QA10- from release version dash board and update Marathon case
			//driver.get("http://tkqtrapq2:8000/FidessaConnectivity.html");
			
			//final WebElement fetchData =
				//driver.findElement(By.xpath("//*[@id='env-status']/tbody/tr/td[1][contains(.,'QA10')]//..//td[2]"));
			//CharSequence releaseVersion = fetchData.getText();
			//releaseVersion = releaseVersion.subSequence(3, 9).toString();
			
			String releaseVersion=CommonFunctions.GetReleaseVersion();
			
			Reporter.log(String.format("Release version %s ruuning on %s.", releaseVersion, SELENIUM_ENVIRONMENT));
			
			driver.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + caseId);
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("//*[contains(text(),'Enter Result')]")).click();
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("//*[contains(text(),'Edit')]")).click();
			
			if(marathonResult)
			{
				driver.findElement(By.xpath("//*[contains(text(),'Passed')]")).click();
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input"))
					.sendKeys(String.format("%s on %s %s", testResultMessage, SELENIUM_ENVIRONMENT, releaseVersion));
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input"))
					.sendKeys(JIRA_NUMBER);
				driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
				Thread.sleep(3000);
				Reporter.log("Marathon testcase passed", true);
			}
			else
			{
				driver.findElement(By.xpath("//*[contains(text(),'Failed')]")).click();
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input"))
					.sendKeys(String.format("%s on %s %s", testResultMessage, SELENIUM_ENVIRONMENT, releaseVersion));
				driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input"))
					.sendKeys(JIRA_NUMBER);
				driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
				Thread.sleep(3000);
				Reporter.log("Marathon testcase failed", true);
			}
			Reporter.log("[Marathon] Marathon test result updated.", true);
		}
		catch(final Exception e)
		{
			Reporter.log(String.format("[%s Marathon] ERROR %s Exception found when updating Marathon test result.",
				getTimeStamp(), e.getMessage()));
		}
	}
	
	private static String getTimeStamp()
	{
		return new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	}
	
	private void _printFileContents(final String file) throws FileNotFoundException, IOException
	{
		final InputStream inputStream = "-".equals(file) ? System.in : new FileInputStream(file);
		try(final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream)))
		{
			@Nullable String line = null;
			do
			{
				line = reader.readLine();
				if(line != null && SimpleString.isNotEmpty.test(line))
				{
					Reporter.log(line, true);
				}
			}
			while(line != null);
		}
	}
	
}
