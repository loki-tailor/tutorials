package com.mizuhosc.selenium.scripts.orderengine;

import java.awt.*;
import java.awt.datatransfer.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class RecoveryUpload
{
	boolean status;
	private WebDriver driver;
	private final ChromeOptions options = new ChromeOptions();
	
	@SuppressWarnings("unused")
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void performRecovery(final String user, final String pass, final String monEnv, final String browser)
	{
		try
		{
			Thread.sleep(2000);
			options.setExperimentalOption("useAutomationExtension", false);
			// Selects appropriate browser as declared by user in global declaration
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			final Actions action = new Actions(driver);
			
			final StringSelection textToPaste =
				new StringSelection(
					"OrderID	ClOrdID	ExecID	ExecType	LastShares	LastPx	LastMkt	TransactTime	Side	Session	QuattroOrderId	ExecRefID	ExecutionVersion	FilledInDarkPool	LastCapacity"
						+ "\n"
						+ "201707280000014	LM:ATRGR2:1501218849846-SS	BTRD20170728000001-1	F	10	10	XOSE	20170728-14:30:00.000	S	BLAST_RAD-2					"
						+ "\n"
						+ "201707280000014	LM:ATRGR2:1501218849846-SS	BTRD20170728000002-1	F	10	20	XOSE	20170728-14:30:00.000	B	BLAST_RAD-2					"
						+ "\n");
			
			// Change if new case captured
			// Wait for the order
			final WebDriverWait thirtySecondWait = new WebDriverWait(driver, 30);
			final WebElement waitForStatus = thirtySecondWait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'14:14:18')]")));
			
			Reporter.log("Step 1 : Synthetic Spread Order is Active in Order Monitoring GUI", true);
			
			thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='menu']/li[1]")))
				.click();// Redirects to engine manager screen
			
			// Right click on the session : Need to change this if env / session change -
			final WebElement rad2Link =
				thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("RAD-2")));
			action.contextClick(rad2Link).build().perform();
			
			// Select appropraite option from right-click options
			action.moveToElement(thirtySecondWait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("/html/body/q-right-click-menu[4]/q-button[5]/span[2]")))).click()
				.perform();
			
			Reporter.log("Step 2 : Right Click on RAD-2 session and initiated recovery ", true);
			final Robot robot = new Robot();
			final WebElement uploadTextArea = thirtySecondWait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='recovery-messages']")));
			
			action.moveToElement(uploadTextArea);
			action.click();
			action.build().perform();
			
			Thread.sleep(500);
			// make sure you put the updated logs by copy pasting in exact format above : Add for every new captured
			// case
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(textToPaste, null);
			robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
			robot.keyPress(java.awt.event.KeyEvent.VK_V);
			robot.keyRelease(java.awt.event.KeyEvent.VK_V);
			robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
			Reporter.log("Pasted the orders in text area to Upload.", true);
			
			// Upload button is clicked
			final WebElement uploadButton = thirtySecondWait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//*[@id='upload-recovery-messages-form']/q-button[2]/span[2]")));
//			final Actions action3 = new Actions(driver);
			// Comment below line to check cancel button
			action.moveToElement(uploadButton).click().build().perform();
			Reporter.log("Clicked Upload button.", true);
			
			// Comment below line to check cancel button
			thirtySecondWait.until(ExpectedConditions.alertIsPresent()).accept();
			Reporter.log("Step 3 : Uploaded Sucessfully : passing the control to Monitoring GUI.", true);
			
			Reporter.log("Clicking on orders tab (Monitoring screen).", true);
			thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//*[@id='menu']/li[2]"))).click();// Redirects to monitoring screen
			
			Thread.sleep(3000);
			
			// Checking the State of recovery : Change with new case
			Reporter.log("Checking Synthetic Spread order's Status.", true);
			final String syntheticSpreadStatus =
				driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']//tr[1]//td[6]")).getText();
			Reporter.log("Synthetic Spread order's Status: " + syntheticSpreadStatus, true);
			
			if(syntheticSpreadStatus != null && "PARTIALLY FILLED".equals(syntheticSpreadStatus))
			{
				Reporter.log(String.format("Step 4: Synthetic Spread order's Status is %s, which is expected.",
					syntheticSpreadStatus), true);
			}
			else
			{
				Reporter.log(String.format("Step 4: Synthetic Spread order's Status is %s, which is not expected.",
					syntheticSpreadStatus), true);
			}
			
			// Change if session and env changes
			// Redirects to engine manager screen
			Reporter.log("Clicking on engines tab.", true);
			thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='menu']/li[1]")))
				.click();
			// Click on the desired session
			Reporter.log("Clicking on RAD-2 engine link.", true);
			thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("RAD-2"))).click();
			
			Reporter.log("Clicking on Session Controls button.", true);
			thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(By.id("engine-button"))).click();
			
			Reporter.log("Clicking on Recovery Tools Tab.", true);
			
			thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Recovery Tools')]")))
				.click();
			
			// Click on Upload template to download
			
			Reporter.log("Clicking on 'Upload' templet button.", true);
			thirtySecondWait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[3]/div[2]/div[3]/a")))
				.click();
			
			Reporter.log("Step 5 : Download File check in progress !!!", true);
			final String home = System.getProperty("user.home");
			final String downloadPath = home + "\\Downloads";
			final String templetFileName = "quattro-upload.xls";
			final File downloadDirectory = new File(downloadPath);
			final ArrayList<String> fileNames = new ArrayList<String>(Arrays.asList(downloadDirectory.list()));
			
			if(fileNames.size() > 0 && fileNames.contains(templetFileName))
			{
				Reporter.log(String.format("%s downloaded Successfully at %s", templetFileName, downloadPath), true);
			}
			else
			{
				Reporter.log(
					String.format("%s downloaded Failed please check %s directory", templetFileName, downloadPath),
					true);
			}
			Thread.sleep(2000);
			
			Reporter.log("Step 6 :Delete the downloaded file in progress !!!", true);
			final File file = new File(downloadPath + "\\" + templetFileName);
			if(file.delete())
			{
				Reporter.log(String.format("%s deleted Successfully from %s", templetFileName, downloadPath), true);
			}
			else
			{
				Reporter.log(
					String.format("%s deletion failed please check %s directory", templetFileName, downloadPath), true);
				Assert.fail("File deletion operation failed:");
			}
		}
		catch(final Exception e)
		{
			Reporter.log(String.format("Recovery Tool Selenium test case is failing due to: %s ", e.getMessage()));
			driver.close();
			Assert.fail(String.format("Recovery Tool Selenium test case is failing due to: %s ", e.getMessage()));
		}
		driver.close();
	}
	
}
