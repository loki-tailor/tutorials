package com.mizuhosc.selenium.scripts.util;

import com.javtech.appia.middleware.*;
import com.mizuhosc.selenium.Configuration;

import java.io.*;
import java.util.*;

/**
 * Replays streamed ULBridge FIX message on configured session.<br>
 * TargerCompID is replaced, tag 9, 34, 52 and 10 will be automatically
 * re-caculated by Appia. It's support multiple sessions.
 * 
 * @author wangjinb
 * @author kangyi
 * @author jainsank Changed by Sankalp to send the FIX message from Selenium
 *         code
 */
public class ULBridgeFIXReplay2 implements MiddlewareEventListenerIF {
	MiddlewareInterface _appia;
	private final String _fileName;
	private final Set<String> allSessionIds = new HashSet<String>();
	private final Set<String> startedSessionIds = new HashSet<String>();
	private final ConnectionType _connectionType;
	private final int _delay;
	private final String _appiafileName;

	public ULBridgeFIXReplay2(final String fileName, ConnectionType connectionType, int delay,
			final String appiafileName) throws Exception {
		_appiafileName = appiafileName;
		_appia = create("MIZUHO");
		_appia.setMiddlewareEventListener(this);
		_appia.start();
		for (String sessionId : _appia.getAllSessionIDs()) {
			allSessionIds.add(sessionId);
		}
		_fileName = fileName;
		_connectionType = connectionType;
		_delay = delay;

	}

	/**
	 * @return Newly created middleware interface based on the specified
	 *         middlewareId.
	 */
	public MiddlewareInterface create(final String middlewareId) {
		MiddlewareInterface appia;
		final String iniFilePath = _appiafileName;
		// Connect to Appia. Since this is inproc, we cannot use Java ToolKit
		// MiddlewareInterface
		print("Loading Appia ini file", iniFilePath);
		// print("Loading Appia ini file: %s", iniFilePath);
		try {
			// The Appia ini file, second parameter is used for indicating which
			// HA block to use
			final String[] iniFile = new String[] { iniFilePath,
					getHAServerBlockName(java.net.InetAddress.getLocalHost().getHostName()) };

			appia = com.javtech.appia.middleware.MiddlewareInterfaceFactory.getInProcMiddlewareInterface(iniFile,
					middlewareId, false);
			print("Appia middleware initialized successfully ", middlewareId);
		} catch (final Exception e) {
			print(e.getMessage(), "Appia Initialization Failure", "Failed to connect to Appia for middleware: %s",
					middlewareId);

			// Throw a runtime exception, this should already cause problem for
			// the application to start
			// correctly.
			throw new RuntimeException(e);
		}
		return appia;
	}

	@Override
	public void onMiddlewareEvent(final MiddlewareEvent msg) throws Exception {

		String sessionId = msg.getSessionID();
		print("Loading Appia ini file4: %s", _appiafileName);
		if (msg.getEventType() == MiddlewareEvent.SESSION_DISCONNECTED) {
			print("Session disconnected!! " + sessionId);
			startedSessionIds.remove(sessionId);
		} else if (msg.getEventType() == MiddlewareEvent.SESSION_CONNECTED) {
			print("Session Connected!! " + sessionId);
			// Replay the FIX messages
			if (!areAllSessionsConnected(sessionId))
				return;

			// If file name is not provided, read from input stream
			final BufferedReader reader = _fileName == null ? new BufferedReader(new InputStreamReader(System.in))
					: new BufferedReader(new FileReader(_fileName));
			String line = null;
			do {
				line = reader.readLine();
				if (line != null) {
					final int startOfFIX = line.indexOf("8=FIX."); // 0
					final String fixMessage = line.substring(startOfFIX); // whole
																			// fix
																			// message
					final int startOfMsgType = fixMessage.indexOf("|35="); // index
																			// of
																			// '|'
																			// viz
																			// starting
																			// at
																			// 0
					final String msgType = fixMessage.substring(startOfMsgType + "|35=".length(),
							fixMessage.indexOf("|", startOfMsgType + "|35=".length())); // returns
																						// 'D'
																						// from
																						// the
																						// msg
																						// "..|35=D|.."

					String fixConnectionName = null;
					if (ConnectionType.CLIENT2GOR == _connectionType) {
						final int indexOfSenderCompID = fixMessage.indexOf("|49="); // gives
																					// index
																					// of
																					// '|'
																					// of
																					// "...|49=..."
						// get SenderCompID
						final String senderCompID = fixMessage.substring(indexOfSenderCompID + "|49=".length(),
								fixMessage.indexOf("|", indexOfSenderCompID + "|49=".length())); // givesthe
																									// value
																									// of
																									// tag#49
						fixConnectionName = senderCompID;
						if (!startedSessionIds.contains(fixConnectionName)) {
							fixConnectionName = null;
						}
					} else if (ConnectionType.GOR2CLIENT == _connectionType) {
						final int indexOfTargetCompID = fixMessage.indexOf("|56=");
						// get TargetCompID
						final String targetCompID = fixMessage.substring(indexOfTargetCompID + "|56=".length(),
								fixMessage.indexOf("|", indexOfTargetCompID + "|56=".length()));
						fixConnectionName = targetCompID;
					}
					print("fixConnectionName is " + fixConnectionName);
					if (fixConnectionName != null) {
						// Simply replace "|" with "\u0001", not perfect. If tag
						// value has "|" in it, it will be replaced as

						// well

						final String pipeLineReplaced = fixMessage.replaceAll("\\|", "\u0001");
						print("FIX message is " + pipeLineReplaced);
						Thread.sleep(_delay);
						_appia.postRawString(UUID.randomUUID().toString(), fixConnectionName, "FIX",
								MiddlewareConfig.RAW_DATA, msgType, pipeLineReplaced);
					}
				}
			} while (line != null);

			print("Replay finished, will wait 5 seconds and then exit");
			Thread.sleep(5000);
		}

	}

	public void sendAnotherOrder(final String _fileName) throws Exception {

		// If file name is not provided, read from input stream
		final BufferedReader reader = _fileName == null ? new BufferedReader(new InputStreamReader(System.in))
				: new BufferedReader(new FileReader(_fileName));
		String line = null;
		do {
			line = reader.readLine();
			if (line != null) {
				final int startOfFIX = line.indexOf("8=FIX.");
				final String fixMessage = line.substring(startOfFIX);
				final int startOfMsgType = fixMessage.indexOf("|35=");
				final String msgType = fixMessage.substring(startOfMsgType + "|35=".length(),
						fixMessage.indexOf("|", startOfMsgType + "|35=".length()));

				String fixConnectionName = null;
				if (ConnectionType.CLIENT2GOR == _connectionType) {
					final int indexOfSenderCompID = fixMessage.indexOf("|49=");
					// get SenderCompID
					final String senderCompID = fixMessage.substring(indexOfSenderCompID + "|49=".length(),
							fixMessage.indexOf("|", indexOfSenderCompID + "|49=".length()));
					fixConnectionName = senderCompID;
					if (!startedSessionIds.contains(fixConnectionName)) {
						fixConnectionName = null;
					}
				} else if (ConnectionType.GOR2CLIENT == _connectionType) {
					final int indexOfTargetCompID = fixMessage.indexOf("|56="); // gives
																				// index
																				// of
																				// "|"
																				// in
																				// "...|56=..."
					// get TargetCompID
					final String targetCompID = fixMessage.substring(indexOfTargetCompID + "|56=".length(),
							fixMessage.indexOf("|", indexOfTargetCompID + "|56=".length())); // returns
																								// value
																								// of
																								// tag#56
					fixConnectionName = targetCompID;
				}
				print("fixConnectionName is " + fixConnectionName);
				if (fixConnectionName != null) {
					// Simply replace "|" with "\u0001", not perfect. If tag
					// value has "|" in it, it will be replaced as

					// well

					final String pipeLineReplaced = fixMessage.replaceAll("\\|", "\u0001");
					print("FIX message is " + pipeLineReplaced);
					Thread.sleep(_delay);
					_appia.postRawString(UUID.randomUUID().toString(), fixConnectionName, "FIX",
							MiddlewareConfig.RAW_DATA, msgType, pipeLineReplaced);
				}
			}
		} while (line != null);

		print("Replay finished, will wait 5 seconds and then exit");
		Thread.sleep(5000);
		// System.exit(0);
	}

	public void print(final String... args) {
		for (final String s : args) {
			System.out.print(s);
			System.out.print(" ");
		}
		System.out.println();
	}

	public static void main(final String[] args) {

		String fileName = "./conf/lokeshde/FixMessage.log";

		String ConnectionType = "CLIENT2GOR";
		// String appiafileName =
		// "I:\\IT_WSD\\FIX\\Selenium.Automation\\conf\\Connection.Server.ini";

		String appiafileName = "./conf/lokeshde/Connection.Lokeshwar.ini";
		int delayMillisecs = 10000;
		if (args.length == 4) {
			fileName = args[0];
			ConnectionType = args[1];
			if (args[2].startsWith("delay=")) {
				delayMillisecs = Integer.valueOf(args[2].substring(6));
			}
			appiafileName = args[3];
			System.out.println("file name is " + fileName + ", ConnectionType is " + ConnectionType + ", delay is "
					+ delayMillisecs + ",Appia ini file name is " + appiafileName);
		}
		if (args.length == 3) {
			fileName = args[0];
			ConnectionType = args[1];
			if (args[2].startsWith("delay=")) {
				delayMillisecs = Integer.valueOf(args[2].substring(6));
			}
			System.out.println("file name is " + fileName + ", ConnectionType is " + ConnectionType + ", delay is "
					+ delayMillisecs);
		}
		if (args.length == 2) {
			if (args[1].startsWith("delay=")) {
				ConnectionType = args[0];
				delayMillisecs = Integer.valueOf(args[1].substring(6));
				System.out.println(" ConnectionType is " + ConnectionType + ", delay is " + delayMillisecs);
			} else {
				fileName = args[0];
				ConnectionType = args[1];
				System.out.println(
						"file name is " + fileName + ", ConnectionType is " + ConnectionType + ", delay is " + 0);
			}

		} else if (args.length == 1) {
			ConnectionType = args[0];
			System.out.println(" ConnectionType is " + ConnectionType + ", delay is " + 0);
		}
		try {

			// Session Connection
			// Probable order sending as well ??
			System.out.println("############## - connecting");
			ULBridgeFIXReplay2 ulBridgeFIXReplay2 = new ULBridgeFIXReplay2(fileName, getConnectionType(ConnectionType),
					delayMillisecs, appiafileName);
			System.out.println("############## - connected");
			System.out.println();

			// Manual Order Sending
			// System.out.println("sending order");
			// ulBridgeFIXReplay2.sendAnotherOrder(fileName);
			// System.out.println("order sent");
			// System.out.println();

		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	public void start() {

	}

	/**
	 * @return The hostname as it is used as the HA server block name in Appia
	 *         ini file. If the specified hostname is null, it returns an empty
	 *         string.
	 */
	public static String getHAServerBlockName(final String hostname) {
		return hostname != null && hostname.contains(".") ? hostname.toLowerCase().substring(0, hostname.indexOf("."))
				: hostname != null ? hostname.toLowerCase() : "";
	}

	public boolean areAllSessionsConnected(String sessionId) {
		if (allSessionIds.contains(sessionId)) {
			startedSessionIds.add(sessionId);
		}
		return allSessionIds.size() == startedSessionIds.size();
	}

	public static ConnectionType getConnectionType(String ConnectionTypeString) {
		if ("CLIENT2GOR".equals(ConnectionTypeString.toUpperCase())) {
			return ConnectionType.CLIENT2GOR;

		} else if ("GOR2CLIENT".equals(ConnectionTypeString.toUpperCase())) {
			return ConnectionType.GOR2CLIENT;
		}
		return ConnectionType.INVALID;
	}

	public static enum ConnectionType {
		CLIENT2GOR, GOR2CLIENT, INVALID
	}

}
