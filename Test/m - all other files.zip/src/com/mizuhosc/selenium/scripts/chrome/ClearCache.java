package com.mizuhosc.selenium.scripts.chrome;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.testng.annotations.*;

public class ClearCache {
	WebDriver driver = null;

	@Test
	public void archiveOrder() {
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try {

			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);

			// Log into Monitoring screen
			driver.get("chrome://settings/clearBrowserData");

			Thread.sleep(5000);

			/***
			 * TODO Q - Is this class being used during actuall execution? Q - Getting "NoSuchElementException".
			 */
			driver.findElement(By.cssSelector("* /deep/ #clearBrowsingDataConfirm")).click();

			// firstrow.sendKeys(Keys.chord(Keys.CONTROL, "a"));

			Thread.sleep(20000);

			driver.close();
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

}
