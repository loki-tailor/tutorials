package com.mizuhosc.selenium.scripts.others;

import java.io.*;

import com.mizuhosc.selenium.Configuration;

public class RunGitBash
{
	public static void main(final String[] args) throws FileNotFoundException, IOException
	{
		 String SeleniumAutomation_IOIBat_Path = Configuration.SINGLETON.getProperty("selenium.Automation.IOIbat.path");
		System.out.println("Before");
		
//		Runtime.getRuntime()
//			.exec("cmd /c start I:\\IT_WSD\\FIX\\Selenium.Automation\\Scripts\\CreateActualIOILogFile.bat");
		
	
		Runtime.getRuntime()
			.exec("cmd /c start"+ SeleniumAutomation_IOIBat_Path);
		
		System.out.println("After");
	}
}
