package com.mizuhosc.selenium.scripts.others;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.testng.annotations.*;

public class GetReleaseVersion
{
	WebDriver driver = null;
	String browser = "Chrome";
	
	@Test
	public void getReleaseVersion()
	{
		try
		{
			Thread.sleep(5000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
		
		driver.get("http://tkqtrapq2:8000/Quattro_ReleaseHistory.html");
		
		WebElement fetchData = driver.findElement(By.xpath("//*[@id='env-status']/tbody/tr[12]/td[2]/font"));
		String releaseVersion = fetchData.getText();
		System.out.println("Release version ruuning on QA10 is " + releaseVersion);
		// return releaseVersion;
	}
	
	@BeforeTest
	public void runDriver()
	{
		if(browser.equals("Mozilla"))
		{
			driver = new FirefoxDriver();// Mozilla Firefox is invoked
		}
		else if(browser.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver();// Google Chrome is invoked
		}
		else if(browser.equals("IE"))
		{
			File file = new File("drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
		}
	}
	
	@AfterTest
	public void cleanUp()
	{
		driver.close();
		driver.quit();
	}
	
}
