package com.mizuhosc.selenium.scripts.marathon;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import org.testng.annotations.*;

@Test
public class ShiftMarathon {

	/**
	 * @throws IOException
	 * @throws AWTException
	 * @throws InterruptedException
	 *
	 *
	 */

	public void shift_Marathon() throws InterruptedException, AWTException
	{
		final Runtime r = Runtime.getRuntime();
		Process p;

		final String username = "ttobias2";
		final String password = "fix";
		final String serverString = "tkfixapt101";
		final String s = "I:/IT_WSD/FIX/Temp/Temp1/Vaidehi/Softwares/Putty CM/putty/PUTTY.EXE -ssh -l "+username+" -pw "+password+" "+serverString+"";
		try
		{
			//open the putty session with the above given username, password and server
			p = r.exec(s);
			Thread.sleep(3000);

		} catch (final Exception e)
		{
			System.out.println(e);
			e.printStackTrace();

		}
		
		
		Thread.sleep(2000);
		

		final Robot robot = new Robot();
		
		
		
		robot.keyPress(KeyEvent.VK_C);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_D);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_SPACE);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_SLASH);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_P);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_P);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_SLASH);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_P);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_E);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_MINUS);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_T);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_U);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_L);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_L);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_I);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_K);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_2);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_SLASH);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_J);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_I);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_S);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_K);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(150);		

        robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_G);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_E);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_E);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_T);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_E);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_M);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_T);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_H);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_O);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(150);
		
		
		robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_C);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_O);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_F);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_I);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_G);
		Thread.sleep(150);
		
		
		robot.keyPress(KeyEvent.VK_PERIOD);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_S);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_H);
		Thread.sleep(150);
		
		
		robot.keyPress(KeyEvent.VK_SPACE);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_MINUS);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_Q);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		
		
		robot.keyPress(KeyEvent.VK_SPACE);
		Thread.sleep(150);
		
			robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_Q);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
			robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_1);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_0);
		Thread.sleep(150);
		
		
		robot.keyPress(KeyEvent.VK_SPACE);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_MINUS);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_S);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_SPACE);
		Thread.sleep(150);
			robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
			robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_A);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
			robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_D);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_MINUS);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_1);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_SPACE);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_MINUS);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		
		robot.keyPress(KeyEvent.VK_SPACE);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_Y);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
			robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_E);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
			robot.keyPress(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_S);
		Thread.sleep(150);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		Thread.sleep(150);
		robot.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(20000);
		
		
		
		
		
		
		
		

	}
}
