package com.mizuhosc.selenium.scripts.marathon;

import java.io.*;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class LoadMarathonCase
{
	private WebDriver driver;
	private final ChromeOptions options = new ChromeOptions();
	
	@Test
	@Parameters({"username", "password", "browser", "marathonEnv", "caseId"})
	public void loadMarathonCase(final String user, final String pass, final String browser, final String marathonEnv, final int caseId)
	// This method helps in executing the recorded marathon case
	{
		
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// This selects appropriate browser as declared by user in global declaration
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();// Mozilla Firefox is invoked
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);// Google Chrome is invoked
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Quatro Marathon Login
			driver.get("http://" + marathonEnv + ".mizuho-sc.com:9090/quattro/login");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			driver.get("http://" + marathonEnv + ".mizuho-sc.com:9090/case/" + caseId);
			Thread.sleep(1000); // wait for 1 second before execute to load Marathon case.
			final WebElement goToButton = driver.findElement(By.id("execute-case-button"));
			// It finds the execute button
			goToButton.click();// It clicks the execute case button
			
			// Get Test case execution status
			final WebElement waitForMarathon = new WebDriverWait(driver, 220).until(
				ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='run-results']/tbody/tr/td[3]/a")));
			final String marathonCaseStatus = waitForMarathon.getText();
			Reporter.log(String.format("Marathon test Case got %s",marathonCaseStatus));
			if(marathonCaseStatus != null && "Passed".equals(marathonCaseStatus))
			{
				Reporter.log(String.format("Marathon test Case http://%s.mizuho-sc.com:9090/case/%d got Passed.",
					marathonEnv, caseId));
				Thread.sleep(5000); // This can be removed later, if works fine
			}
			else
			{
				Reporter.log(String.format("ERROR: Marathon test Case http://%s.mizuho-sc.com:9090/case/%d got Failed.",
					marathonEnv, caseId));
				driver.close();
				Assert.fail(
					String.format("ERROR: Marathon test Case http://%s.mizuho-sc.com:9090/case/%d got Failed!!!!!",
					marathonEnv, caseId));
				
			}
			driver.close();
		}
		catch(final Exception e)
		{
			Reporter.log(String.format("ERROR: Marathon test case execution got exception: %s", e.getMessage()), true);
			driver.close();
			Assert
				.fail(String.format("ERROR : Marathon test Case http://%s.mizuho-sc.com:9090/case/%d got Exception: %s",
				marathonEnv, caseId, e.getMessage()));
		}
	}
}
