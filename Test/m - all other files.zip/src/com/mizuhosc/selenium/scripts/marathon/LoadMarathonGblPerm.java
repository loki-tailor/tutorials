package com.mizuhosc.selenium.scripts.marathon;

import java.io.*;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class LoadMarathonGblPerm
{
	
	String marathonCaseStatus;
	WebDriver driver = null;
	@Test
	@Parameters({"username", "password", "browser", "marathonEnv", "caseId"})
	
	public void loadMarathonCase(String user, String pass, String browser, String marathonEnv, int caseId)
	// This method helps in executing the recorded marathon case
	{
		
		
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// This selects appropriate browser as declared by user in global declaration
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();// Mozilla Firefox is invoked
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				//System.setProperty("webdriver.chrome.driver", "I:\\Rahuljai\\Temp1\\Dev\\selenium-2.53.1\\chromedriver.exe");
				driver = new ChromeDriver(options);// Google Chrome is invoked
			}
			else if(browser.equals("IE"))
			{
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Quatro Marathon Login
			driver.get("http://" + marathonEnv + ".mizuho-sc.com:9090/quattro/login");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			driver.get("http://" + marathonEnv + ".mizuho-sc.com:9090/case/" + caseId);
			
			// Execute test case
			WebElement goToButton = driver.findElement(By.id("execute-case-button"));
			// It finds the execute button
			goToButton.click();// It clicks the execute case button
			
			// Get Test case execution status
			WebElement waitForMarathon =
				new WebDriverWait(driver, 220).until(
					ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='run-results']/tbody/tr/td[3]/a")));
			marathonCaseStatus = waitForMarathon.getText();
			System.out.println("Marathon Status check : String passed is " + marathonCaseStatus);
			if("Failed".equals(waitForMarathon.getText()) || "Passed".equals(waitForMarathon.getText()))
			{
				Reporter.log("Marathon case has Passed", true);
				//System.out.println(" Marathon case : Passed");
				Reporter.log("");
				
				
				try
				{
					Thread.sleep(5000);
				}
				catch(InterruptedException e2)
				{
					e2.printStackTrace();
				}
				
//				driver.close();
				// driver.quit();
				
			}
			else
			{
				Reporter.log("Marathon case has Failed", true);
				Assert.fail(
					"Marathon Error : Marathon check Failed!!!!!!!!!!!!!!!!!!! for http://" + marathonEnv
						+ ".mizuho-sc.com:9090/case/" + caseId);
			}
		}
		catch(Exception e)
		{
			Reporter.log(marathonCaseStatus, false);
			Assert.fail("Selenium error : Marathon check Failed!!!!!!!!!!!!!!!!!!! for http://" + marathonEnv
					+ ".mizuho-sc.com:9090/case/" + caseId);
//			driver.close();
//			driver.quit();
		}
//	
//		finally
//		{
//			driver.close();
//			driver.quit();
//		}
		
	}
	@AfterTest
	public void CloseBrowser()
	{
		driver.close();
		driver.quit();
	}
	
}
