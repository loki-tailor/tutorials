package com.mizuhosc.selenium.scripts.marathon;

import java.io.*;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

import com.mizuhosc.selenium.functionlibraries.CommonFunctions;

public class UpdateMarathonCase
{
	@Test
	public void VerifyMonitoringGUIColumn () throws InterruptedException
	{
    String browser = "Chrome";
	WebDriver driverFirstChange=CommonFunctions.DriverInvoke(browser);
	int caseId = 12402;
	String releaseVersion = "38.0";
	String orderStatusResult = "Failed";
	String JIRA_Number = "QTR-3454";
	String testResultString = "Test";
	try
	{
    	CommonFunctions.updateResult(caseId, releaseVersion, orderStatusResult, testResultString, JIRA_Number, driverFirstChange, "TRUE");
	}	
	catch(final Exception e)
	{
			Assert.fail("Exception details are  " + e.getMessage());
			driverFirstChange.quit();
			
	}
	driverFirstChange.quit();
	}
}