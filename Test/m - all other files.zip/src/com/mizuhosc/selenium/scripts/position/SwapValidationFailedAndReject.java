package com.mizuhosc.selenium.scripts.position;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class SwapValidationFailedAndReject
{
	
	private String testResult;
	private WebDriver driver; // Selects appropraite driver
	
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void processValidation(final String user, final String pass, final String monEnv, final String browser)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			Reporter.log("--Starting Test case Swap_Testing_case1--");
			System.out.println("--Starting Test case Swap_Testing_case1--");
			// Waiting for the order from Marathon
			
			new WebDriverWait(driver, 30)
				.until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'15233443343AJ')]")));// 20:21:28.
			final WebElement orderRowClick =
				driver.findElement(By.xpath(("//*[contains(text(),'15233443343AJ')]//../../td[6]")));
			
			new WebDriverWait(driver, 30)
				.until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id='q-render-table-order-list']//*[contains(text(),'Validation Failed')]")));
			final String textResult = orderRowClick.getText();
			if(orderRowClick.getText() != null && "VALIDATION FAILED".equals(orderRowClick.getText()))
			{
				Reporter.log("Test order is placed and is in " + textResult + " state.", true);
				System.out.println("VALIDATION FAILED check : Passed");
				
				orderRowClick.click();
				
				Thread.sleep(5000);
				
				driver.switchTo().frame(0);
				
				final WebDriverWait wait = new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//*[@id='position-check-and-accept-button']")));
				// if (driver.findElement(By.cssSelector("a:contains('Check & Accept')")).isDisplayed())
				// if (driver.findElement(By.xpath("//*[@id='position-validation-panel']//*[contains(text(),'Check &
				// Accept')]")).isDisplayed())
				final WebElement checkAccept =
					driver.findElement(By.xpath("//*[@id='position-check-and-accept-button']"));
				
				checkAccept.click();
				
				Thread.sleep(5000);
				driver.switchTo().defaultContent();
				
				System.out.println("Successfully clicked on 'Check & Accept'");
				
				final WebElement orderRowClick2 =
					driver.findElement(By.xpath("//*[contains(text(),'15233443343AJ')]//../../td[6]"));
				
				final String textResult2 = orderRowClick2.getText();
				
				if(orderRowClick2.getText() != null && "VALIDATION FAILED".equals(orderRowClick2.getText()))
				{
					Reporter.log("After clicking on 'Check & Accept' the Order is in " + textResult2 + " state.", true);
					System.out.println("VALIDATION FAILED check : Passed");
					
					driver.switchTo().frame(0);
					
					final WebDriverWait wait1 = new WebDriverWait(driver, 30);
					wait1.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='position-reject-button']")));
					
					final WebElement reject = driver.findElement(By.xpath("//*[@id='position-reject-button']"));
					
					reject.click();
					Thread.sleep(5000);
					
					System.out.println("Successfully clicked on 'Reject'");
					
					driver.switchTo().defaultContent();
					
					final WebElement orderRowClick3 =
						driver.findElement(By.xpath("//*[contains(text(),'15233443343AJ')]//../../td[6]"));
					
					final String textResult3 = orderRowClick3.getText();
					
					if(orderRowClick3.getText() != null && "REJECTED".equals(orderRowClick3.getText()))
					{
						Reporter.log("After clicking on 'Reject' the Order is in " + textResult3 + " state.", true);
						Reporter.log("Test Case for Swap validation has Passed", true);
						System.out.println("Validation failed check : Passed");
					}
					else
					{
						Reporter.log("After clicking on 'Reject' the Order is in " + textResult3 + " state.", true);
						Assert.fail("Validation failed check : Failed");
					}
				}
				else
				{
					Reporter.log("After clicking on 'Check & Accept' the Order is in " + textResult2 + " state.", true);
					Assert.fail("Validation failed check : Failed");
				}
				
				Reporter.log("--Finished Test case Swap_Testing_case1--");
				System.out.println("--Finished Test case Swap_Testing_case1--");
				
			}
			else
			{
				Reporter.log("Test order is placed and is in " + textResult + " state.", true);
				Assert.fail("Validation failed check : Failed");
			}
		}
		catch(final Exception e)
		{
			Reporter.log(
				"Test Case for Swap validation has Failed due to an exception : It has fetched the value : "
					+ testResult,
				false);
			Assert.fail("Selenium Error : Swap validation check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Swap validation : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
		}
	}
	
	@AfterTest
	public void CloseBrowser()
	{
		driver.close();
		driver.quit();
	}
	
}
