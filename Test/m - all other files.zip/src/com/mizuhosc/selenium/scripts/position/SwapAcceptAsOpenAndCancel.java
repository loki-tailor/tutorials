package com.mizuhosc.selenium.scripts.position;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class SwapAcceptAsOpenAndCancel
{
	private String textResult;
	private WebDriver driver; // Selects appropraite driver
	
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void processValidation(final String user, final String pass, final String monEnv, final String browser)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			Reporter.log("--Starting Test case Swap_Testing_case2--");
			System.out.println("--Starting Test case Swap_Testing_case2--");
			
			// Waiting for the order from Marathon
			@SuppressWarnings("unused") final WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(
						ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'15233445754AJ')]")));// 20:21:28.
			final WebElement orderRowClick =
				driver.findElement(By.xpath(("//*[contains(text(),'15233445754AJ')]//../../td[6]")));
			
			final WebElement waitForOrder1 =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='q-render-table-order-list']//*[contains(text(),'Validation Failed')]")));
			
			final String textResult = orderRowClick.getText();
			
			if(orderRowClick.getText() != null && "VALIDATION FAILED".equals(orderRowClick.getText()))
			{
				Reporter.log("Test order is placed and is in " + textResult + " state.", true);
				System.out.println("VALIDATION FAILED check : Passed");
				
				orderRowClick.click();
				
				Thread.sleep(5000);
				
				driver.switchTo().frame(0);
				
				final WebDriverWait wait = new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//*[@id='position-accept-as-open-button']")));
				final WebElement checkAccept =
					driver.findElement(By.xpath("//*[@id='position-accept-as-open-button']"));
				
				checkAccept.click();
				
				Thread.sleep(5000);
				
				driver.switchTo().defaultContent();
				
				System.out.println("Successfully clicked on 'Accept as Open'");
				
				// Verify that order is successfully 'Cancelled' now
				final WebElement waitForOrder2 =
					new WebDriverWait(driver, 30)
						.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[@id='q-render-table-order-list']//*[contains(text(),'Cancelled')]")));
				
				final WebElement finalOrderStatus =
					driver.findElement(By.xpath("//*[contains(text(),'15233445980')]//../../td[6]"));
				final String getStatusFinalOrder = finalOrderStatus.getText();
				
				if(finalOrderStatus.getText() != null && "CANCELLED".equals(finalOrderStatus.getText()))
				{
					System.out.println("Final order status is " + getStatusFinalOrder + " : Test case passed");
				}
				else
				{
					Assert.fail("Final status of Order is not 'Cancelled',instead it is" + getStatusFinalOrder);
					
				}
				
				Reporter.log("Test Case for Swap validation for button click 'Accept as open' has Passed", true);
				System.out.println("Validation failed check : Passed");
				
				Reporter.log("--Finished Test case Swap_Testing_case2--");
				System.out.println("--Finished Test case Swap_Testing_case2--");
				
			}
			else
			{
				Reporter.log("Test order is placed and is in " + textResult + " state.", true);
				Assert.fail("VALIDATION FAILED check : Failed");
			}
			
		}
		catch(final Exception e)
		{
			Reporter.log(
				"Test Case for Swap validation has Failed due to an exception : It has fetched the value : "
					+ textResult,
				false);
			Assert.fail("Selenium Error : Swap validation check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Swap validation : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
		}
	}
	
	@AfterTest
	public void CloseBrowser()
	{
		driver.close();
		driver.quit();
	}
	
}
