package com.mizuhosc.selenium.scripts.position;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class SwapBuySellOnPositionScreen
{
	
	String textResult;
	String buyOrder = "152327890622AJ";
	String sellOrder = "152327902023AJ";
	
	WebDriver driver = null; // Selects appropraite driver
	
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void processValidation(final String user, final String pass, final String monEnv, final String browser)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			Reporter.log("--Starting Test case Swap_Testing_case4--");
			System.out.println("--Starting Test case Swap_Testing_case4--");
			
			// Waiting for the order from Marathon
			new WebDriverWait(driver, 30)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'152327902023AJ')]")));// 20:21:28.
			
			final WebElement waitForOrder1 =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='q-render-table-order-list']//*[contains(text(),'Validation Failed')]")));
			
			final WebElement sellOrderRowClick =
				driver.findElement(By.xpath(("//*[contains(text(),'152327902023AJ')]//../../td[6]")));
			
			final String textResult = sellOrderRowClick.getText();
			if(sellOrderRowClick.getText() != null && "VALIDATION FAILED".equals(sellOrderRowClick.getText()))
			{
				Reporter.log("Sell swap order is placed and is in " + textResult + " state.", true);
				System.out.println("VALIDATION FAILED check : Passed");
				
				sellOrderRowClick.click();
				
				try
				{
					Thread.sleep(5000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				
				driver.switchTo().frame(0);
				
				final WebDriverWait wait = new WebDriverWait(driver, 30);
				
				wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//*[@id='position-check-and-accept-button']")));
				
				final WebElement checkAccept =
					driver.findElement(By.xpath("//*[@id='position-check-and-accept-button']"));
				boolean result = false;
				int attempt = 0;
				while(attempt < 2)
				{
					try
					{
						checkAccept.click();
						result = true;
						attempt++;
						System.out.println(result);
						break;
					}
					catch(final StaleElementReferenceException e)
					{
						attempt++;
						System.out.println(e);
					}
				}
				
				try
				{
					Thread.sleep(5000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				
				driver.switchTo().defaultContent();
				
				System.out.println("Successfully clicked on 'Check & Accept'");
				
				if(sellOrderRowClick.getText() != null && "VALIDATION FAILED".equals(sellOrderRowClick.getText()))
				{
					// Now navigate to position page
					final WebElement PositionTabClick = driver.findElement(By.xpath("//*[@id='menu']/li[5]"));
					PositionTabClick.click();
					System.out.println("!!!!Got the Position Page!!!!");
					
					// Click on the reload button to get the positions
					
					final WebElement ReloadButtonClick = driver.findElement(By.xpath("//*[contains(text(),'Reload')]"));
					ReloadButtonClick.click();
					System.out.println("!!!click on reload button!!!");
					driver.switchTo().alert().accept();
					System.out.println("!!page refereshed!!");
					
					try
					{
						Thread.sleep(5000);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
					// Add position for the account
					
					final WebElement addPosition = wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Add Position')]")));
					addPosition.click();
					
					try
					{
						Thread.sleep(1500);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
					final WebElement addAccount = driver.findElement(By.xpath("//*[@id='account']"));
					addAccount.sendKeys("9569600");
					
					final WebElement addInstrument = driver.findElement(By.xpath("//*[@id='instrument']"));
					addInstrument.sendKeys("6307");
					
					driver.findElement(By.xpath("//*[@id='save-position-button']")).click();
					System.out.println("save click");
					try
					{
						Thread.sleep(1500);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
					driver.findElement(By.xpath("//*[contains(text(),'back to position list')]")).click();
					System.out.println("back to position click");
					try
					{
						Thread.sleep(2500);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
					
					final WebElement accountRow = driver.findElement(
						By.xpath("//*[@id='position-list-body']//tr/td[3]//*[contains(text(),'9569600')]"));
					final String accountNumber = accountRow.getText();
					System.out.println("Found Account on Position is" + accountNumber);
					if(accountRow.getText() != null && "9569600".equals(accountRow.getText()))
					{
						
						// click on the account row to edit the position
						boolean result1 = false;
						int attempt1 = 0;
						while(attempt1 < 2)
						{
							try
							{
								accountRow.click();
								result1 = true;
								System.out.println(result1);
								attempt1++;
								break;
							}
							catch(final StaleElementReferenceException e)
							{
								attempt1++;
								System.out.println("Entered in catch block");
								System.out.println(e);
							}
						}
						
						// Click on edit button to edit the position
						
						final WebElement editPositionButton =
							driver.findElement(By.xpath("//*[@id='edit-position-edit-buttons']/span"));
						
						editPositionButton.click();
						
						// Add position in fields
						
						// 1.Add value 1000 in longposition text field.
						
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[3]/td[2]/span[1]/input"))
							.clear();
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[3]/td[2]/span[1]/input"))
							.sendKeys("1000");
						
						// 2.Add value 1000 in ShortPosition text field.
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[4]/td[2]/span[1]/input"))
							.clear();
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[4]/td[2]/span[1]/input"))
							.sendKeys("1000");
						
						// 3.Add value 1000 in Long Potential text field.
						driver.findElement(By.xpath("//*[@id='thePosition.longPotential']")).clear();
						driver.findElement(By.xpath("//*[@id='thePosition.longPotential']")).sendKeys("1000");
						
						// 4.Add value 1000 in Short Potential text field.
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[4]/td[4]/span[1]/input"))
							.clear();
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[4]/td[4]/span[1]/input"))
							.sendKeys("1000");
						
						// 5.Add value 1000 in Long Credit text field.
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[3]/td[6]/span[1]/input"))
							.clear();
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[3]/td[6]/span[1]/input"))
							.sendKeys("1000");
						
						// 6.Add value 1000 in Short Credit text field.
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[4]/td[6]/span[1]/input"))
							.clear();
						driver
							.findElement(
								By.xpath("//*[@id='position-detail-form']/table/tbody/tr[4]/td[6]/span[1]/input"))
							.sendKeys("1000");
						
						// Save all the changes
						
						final WebElement savePositionButton =
							driver.findElement(By.xpath("//*[@id='save-position-button']"));
						savePositionButton.click();
						System.out.println("save all the position");
						
						// Move back to Position screen
						
						final WebElement backToPositionList =
							driver.findElement(By.xpath("/html/body/div[3]/div[2]/a"));
						backToPositionList.click();
						
						try
						{
							Thread.sleep(2000);
						}
						catch(final InterruptedException e2)
						{
							e2.printStackTrace();
						}
						System.out.println("back to position screen after adding position");
						boolean result2 = false;
						int attempt2 = 0;
						while(attempt2 < 2)
						{
							try
							{
								// check the elements on position list
								final WebElement longPosition = driver.findElement(By
									.xpath("//*[@id='position-list-body']//*[contains(text(),'9569600')]//..//td[6]"));
								final WebElement longPotential = driver.findElement(By
									.xpath("//*[@id='position-list-body']//*[contains(text(),'9569600')]//..//td[7]"));
								final WebElement longCredit = driver.findElement(By
									.xpath("//*[@id='position-list-body']//*[contains(text(),'9569600')]//..//td[8]"));
								final WebElement shortPosition = driver.findElement(By
									.xpath("//*[@id='position-list-body']//*[contains(text(),'9569600')]//..//td[9]"));
								final WebElement shortPotential = driver.findElement(By
									.xpath("//*[@id='position-list-body']//*[contains(text(),'9569600')]//..//td[10]"));
								final WebElement shortCredit = driver.findElement(By
									.xpath("//*[@id='position-list-body']//*[contains(text(),'9569600')]//..//td[11]"));
								
								if("1,000".equals(longPosition.getText())
									&& "1,000".equals(longPotential.getText())
									&& "1,000".equals(longCredit.getText())
									&&
									"1,000".equals(shortPosition.getText())
									&& "1,000".equals(shortPotential.getText())
									&& "1,000".equals(shortCredit.getText()))
								{
									System.out.println("All the elements are saved successfully on position screen");
								}
								else
								
								{
									System.out.println("All the elements are not saved on position screen");
									driver.close();
								}
								result2 = true;
								System.out.println(result2);
								attempt2++;
								break;
							}
							catch(final StaleElementReferenceException e)
							{
								attempt2++;
								System.out.println(e);
							}
						}
						
						// Now navigate to Orders page
						final WebElement ordersTabClick = driver.findElement(By.xpath("//*[@id='menu']/li[2]"));
						ordersTabClick.click();
						System.out.println("!!!!Got the Orders Page!!!!");
						
						final WebElement sellOrderRowClick1 =
							driver.findElement(By.xpath(("//*[contains(text(),'152327902023AJ')]//../../td[6]")));
						// Click on sell order and click on 'check and accept' and check that sell order is in active
						// state
						
						sellOrderRowClick1.click();
						
						try
						{
							Thread.sleep(3000);
						}
						catch(final InterruptedException e2)
						{
							e2.printStackTrace();
						}
						
						driver.switchTo().frame(0);
						
						final WebDriverWait wait2 = new WebDriverWait(driver, 30);
						
						wait2.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//*[@id='position-check-and-accept-button']")));
						
						final WebElement checkAccept2 =
							driver.findElement(By.xpath("//*[@id='position-check-and-accept-button']"));
						
						boolean result3 = false;
						int attempt3 = 0;
						while(attempt3 < 2)
						{
							try
							{
								checkAccept2.click();
								result3 = true;
								System.out.println(result3);
								attempt3++;
								break;
							}
							catch(final StaleElementReferenceException e)
							{
								attempt3++;
								System.out.println("Entered in catch block");
								System.out.println(e);
							}
						}
						
						try
						{
							Thread.sleep(2000);
						}
						catch(final InterruptedException e2)
						{
							e2.printStackTrace();
						}
						
						driver.switchTo().defaultContent();
						
						System.out.println("Successfully clicked on 'Check & Accept'");
						
						try
						{
							Thread.sleep(2000);
						}
						catch(final InterruptedException e2)
						{
							e2.printStackTrace();
						}
						// sell order is in Active state
						System.out.println("Orders should be fully filled , checking started");
						// Verify that order is successfully 'filled' now
						final WebElement waitForOrder2 =
							new WebDriverWait(driver, 30)
								.until(ExpectedConditions.presenceOfElementLocated(
									By.xpath("//*[@id='q-render-table-order-list']//*[contains(text(),'Filled')]")));
						
						final WebElement finalOrderStatus =
							driver.findElement(By.xpath("//*[contains(text(),'152327902023AJ')]//../../td[6]"));
						final String getStatusFinalOrder = finalOrderStatus.getText();
						
						if(finalOrderStatus.getText() != null && "FILLED".equals(finalOrderStatus.getText()))
						{
							System.out.println("Final order status is " + getStatusFinalOrder + " : Test case passed");
						}
						else
						{
							Assert.fail("Final status of Order is not 'FILLED'");
							
						}
						Reporter.log("--Finished Test case Swap_Testing_case4--");
						System.out.println("--Finished Test case Swap_Testing_case4--");
						
					}
					
					else
					{
						Reporter.log("Account 9569600 not found ,instead it is " + accountNumber + " account.", true);
						driver.close();
						Assert.fail("Account 9569600 check : Failed");
						
					}
					
				}
				else
				{
					Reporter.log("State of sell swap order is " + textResult + " state.", true);
					driver.close();
					Assert.fail("State of sell swap order is VALIDATION FAILED check : Failed");
					
				}
				
				driver.close();
				// driver.quit();
				
			}
			else
			{
				Reporter.log("Test order is placed and is in " + textResult + " state.", true);
				driver.close();
				Assert.fail("VALIDATION FAILED check : Failed");
				
			}
			
		}
		
		catch(final Exception e)
		{
			Reporter.log(
				"Test Case for Swap validation has Failed due to an exception : It has fetched the value : "
					+ textResult,
				false);
			
			System.out.println("Swap validation : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
			driver.close();
			
			// driver.quit();
		}
	}
	
}
