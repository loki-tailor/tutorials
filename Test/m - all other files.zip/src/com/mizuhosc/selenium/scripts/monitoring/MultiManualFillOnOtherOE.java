package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class MultiManualFillOnOtherOE
{
	private String textResult;
	private WebDriver driver; // Selects appropraite driver
	private final String AvgPrice = "200";
	private final String ExchangeDropdown = "TSE";
	private final String LastCapacityDropdown = "Agent";
	
	// String totalFilledQuantity="900";
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void processValidation(final String user, final String pass, final String monEnv, final String browser)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			
			// Waiting for the order from Marathon
			@SuppressWarnings("unused") final WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//*[contains(text(),'15245719615TestAJ')]//../../td[6]")));// 20:21:28.
			
			final String originalWindow = driver.getWindowHandle();
			
			final WebElement Order_differentOrderengine =
				driver.findElement(By.xpath(("//*[contains(text(),'15245719615TestAJ')]//../../td[6]")));
			
			Order_differentOrderengine.click();
			
			checkDifferentExchangeOrSession_MultiFill(Order_differentOrderengine);
			driver.switchTo().window(originalWindow);
			Reporter.log(
				"Multi-manual fill option should be enabled even if client attached to two different sessions and that sessions attached to two different orderengines : Scenario passed");
			System.out.println(
				"Multi-manual fill option should be enabled even if client attached to two different sessions and that sessions attached to two different orderengines : Scenario passed");
			
		}
		catch(final Exception e)
		{
			Reporter.log(
				"Test Case for 'Multi Manual fill' has Failed due to an exception : It has fetched the value : "
					+ textResult,
				false);
			Assert.fail("Selenium Error : 'Multi Manual fill' has Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Multi Manual fill : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
			driver.close();
		}
	}
	
	public void checkDifferentExchangeOrSession_MultiFill(final WebElement orderRowClick_selected)
	{
		
		orderRowClick_selected.click();
		// ###Select three orders with same client , same symbol and same side
		action().keyDown(Keys.SHIFT).sendKeys(Keys.ARROW_DOWN).keyUp(Keys.SHIFT).perform();
		System.out.println("all two rows selected");
		
		try
		{
			Thread.sleep(2000);
			action().contextClick(orderRowClick_selected).sendKeys(Keys.RETURN).build().perform();
			Reporter.log("right click on the selected 2 orders");
			// Check whether multi fill option is present , if yes then click on the option
			final WebElement multiFilloption = driver.findElement(By.xpath("//*[@id='multiExecution']"));
			
			if(multiFilloption.getText() != null && "Multi Manual Fill (2 orders)".equals(multiFilloption.getText()))
			{
				// # Click on multi fill button
				multiFilloption.click();
				
				Reporter.log("Multi fill option is enabaled");
				// New window is openend and now switch to new window
				switchWindow();
				Thread.sleep(2000);
				
				// #####Verifying 'Multi fill execution' window elements!
				// Fill value in text field 'Average Price'
				
				driver.findElement(By.xpath("//*[@id='average-price']")).sendKeys(AvgPrice);
				
				// Fill value in Exchange dropdown
				final WebElement Exchange = driver.findElement(By.xpath("//*[@id='top-exchange-select']"));
				dropdown(Exchange).selectByVisibleText(ExchangeDropdown);
				
				// Fill value in Last Capacity dropdown
				final WebElement Capacity = driver.findElement(By.xpath("//*[@id='top-last-capacity-select']"));
				dropdown(Capacity).selectByVisibleText(LastCapacityDropdown);
				
				// Fill value in Exec time text field
				
				final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
				final LocalTime time = LocalTime.now();
				final String t = formatter.format(time);
				
				driver.findElement(By.xpath("//*[@id='top-execution-time']")).clear();
				driver.findElement(By.xpath("//*[@id='top-execution-time']")).sendKeys(t);
				driver.findElement(By.xpath("//*[@id='fully-fill-button']")).click();
				driver.findElement(By.xpath("//*[@id='send-all-button']")).click();
				
				Thread.sleep(3000);
				driver.switchTo().alert().accept();
				
				// Verification of whether added values are reflected correctly
				Thread.sleep(3000);
				
				driver.switchTo().alert().accept();
				Thread.sleep(3000);
				
				final WebElement check_Filledstatus = driver.findElement(
					By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[1]/td[10]/q-progressbar/div"));
				final String Check_filledstatusString = check_Filledstatus.getText();
				System.out
					.println(
						"Values in Filled column is same as Order Qty and equal to  : " + Check_filledstatusString);
				
				close_MultiFill_window();
			}
			else
			{
				System.out.println("Multi Manual Fill button is not present");
				Assert.fail("Multi Manual Fill button is not present");
			}
		}
		catch(final Exception e)
		{
			Reporter
				.log(String.format("Multi Manual Fill on other Order Engine is failing due to: %s", e.getMessage()));
		}
		
	}
	
	public void close_MultiFill_window()
	{
		driver.findElement(By.xpath("//*[@id='close-button']")).click();
	}
	
	private void switchWindow()
	{
		final String originalWindow = driver.getWindowHandle();
		final Set<String> allWindow = driver.getWindowHandles();
		for(final String currentWindow: allWindow)
		{
			if(!currentWindow.equals(originalWindow))
			{
				driver.switchTo().window(currentWindow);
				System.out.println("already switched");
			}
			else
			{
				System.out.println("No switching");
			}
		}
	}
	
	public Actions action()
	{
		final Actions actionObj = new Actions(driver);
		return actionObj;
	}
	
	public Select dropdown(final WebElement dropdownName)
	{
		final Select dropdownMenu = new Select(dropdownName);
		return dropdownMenu;
	}
	
}
