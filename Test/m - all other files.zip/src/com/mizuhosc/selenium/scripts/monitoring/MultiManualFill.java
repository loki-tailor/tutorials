package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class MultiManualFill
{
	String textResult;
	WebDriver driver = null; // Selects appropraite driver
	String AvgPrice = "200";
	String ExchangeDropdown = "TSE";
	String LastCapacityDropdown = "Agent";
	String totalFilledQuantity = "900";
	String match = "200";
	
	@Parameters({
		"username",
		"password",
		"quattroEnv",
		"browser",
		"Case1_Order1_xpath",
		"Case1_Order2_xpath",
		"Case1_Order3_xpath",
		"Case2_Order1_xpath"})
	@Test
	public void processValidation(
		final String user,
		final String pass,
		final String monEnv,
		final String browser,
		final String Case1_Order1,
		final String Case1_Order2,
		final String Case1_Order3,
		final String Case2_Order1)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			
			// Waiting for the order from Marathon
			
			@SuppressWarnings("unused") final WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//*[contains(text(),'15238748000')]//../../td[6]")));// 20:21:28.
			
			final String originalWindow = driver.getWindowHandle();
			
			// ## Step 1: Multi-manual fill option should be enabled from right click menu if you select same client,
			// same symbol and same side.
			
			final WebElement orderRowClick_SameSide_SameClient = driver.findElement(By.xpath((Case1_Order1)));
			
			check_SameSideSameClient_DifferentAccount_MultiFill(orderRowClick_SameSide_SameClient);
			
			Reporter.log(
				"Multi-manual fill option should be enabled from right click menu if you select same client, same symbol and same side--> Scenario is working correctly");
			System.out.println(
				"Multi-manual fill option should be enabled from right click menu if you select same client, same symbol and same side--> Scenario is working correctly");
			driver.switchTo().window(originalWindow);
			System.out.println("in original window");
			// Check the status of handled 3 orders , it should be 'PARTIALLY FILLED'
			
			///// Order 1 status//
			driver.findElement(By.xpath(Case1_Order1)).click();
			final String verifyOrderstate1 = driver.findElement(By.xpath(Case1_Order1)).getText();
			if(verifyOrderstate1 != null && "PARTIALLY FILLED".equals(verifyOrderstate1))
			
			{
				System.out.println("Order1 is being filled partially");
				
			}
			else
			{
				System.out.println("Order1 is being not filled partially");
			}
			
			///// Order 2 status//
			driver.findElement(By.xpath(Case1_Order2)).click();
			final String verifyOrderstate2 = driver.findElement(By.xpath(Case1_Order2)).getText();
			if(verifyOrderstate2 != null && "PARTIALLY FILLED".equals(verifyOrderstate2))
			
			{
				System.out.println("Order2 is being filled partially");
				
			}
			else
			{
				System.out.println("Order2 is being not filled partially");
			}
			
			//// Order 3 status///
			driver.findElement(By.xpath(Case1_Order3)).click();
			final String verifyOrderstate3 = driver.findElement(By.xpath(Case1_Order3)).getText();
			
			if(verifyOrderstate3 != null && "PARTIALLY FILLED".equals(verifyOrderstate3))
			
			{
				System.out.println("Order3 is being filled partially");
				
			}
			else
			{
				System.out.println("Order3 is being not filled partially");
			}
			
			// ## Step 2: Multi-manual fill option should be enabled if you select only Japan DISC CASH orders else menu
			// should be disabled
			/// No multifill option for DMA order
			checkDMAorder_MultiFill(Case2_Order1);
			Reporter.log(
				"Multi-manual fill option should be enabled if you select only Japan DISC CASH orders else menu should be disabled : Scenario passed");
			System.out.println(
				"Multi-manual fill option should be enabled if you select only Japan DISC CASH orders else menu should be disabled : Scenario passed");
			
			// ## step 3: Multi-manual fill option should be enabled even if client sent same instrument for various
			// exchanges like TSE, NSE, FSE, MIX or CHJ.
			//// Check the orders for different exchanges can be multifill and also check fully fill button on multi
			// fill execution window
			
			final WebElement orderRowClick_differentExchange =
				driver.findElement(By.xpath(("//*[contains(text(),'152387455217TestAJ')]//../../td[6]")));
			
			checkDifferentExchangeOrSession_MultiFill(orderRowClick_differentExchange);
			
			driver.switchTo().window(originalWindow);
			// Check the status of orders with different exchange after multi fill is done
			
			//// Order 1 Status///
			final WebElement Order_differentExchange1 =
				driver.findElement(By.xpath(("//*[contains(text(),'152387455217TestAJ')]//../../td[6]")));
			
			Order_differentExchange1.click();
			final String Order_differentExchange1String = Order_differentExchange1.getText();
			if(Order_differentExchange1String != null && "FILLED".equals(Order_differentExchange1String))
			
			{
				System.out.println("Order_DifferentExchange_1 is fully filled ");
				
			}
			else
			{
				System.out.println("Order_DifferentExchange_1 is NOT fully filled");
			}
			
			//// order 2 status//
			final WebElement Order_differentExchange2 =
				driver.findElement(By.xpath(("//*[contains(text(),'152387452516TestAJ')]//../../td[6]")));
			
			Order_differentExchange2.click();
			final String Order_differentExchange2String = Order_differentExchange2.getText();
			if(Order_differentExchange2String != null && "FILLED".equals(Order_differentExchange2String))
			
			{
				System.out.println("Order_DifferentExchange_2 is fully filled ");
				
			}
			else
			{
				System.out.println("Order_DifferentExchange_2 is NOT fully filled");
			}
			
			Reporter.log(
				"Multi-manual fill option should be enabled even if client sent same instrument for various exchanges like TSE, NSE, FSE, MIX or CHJ : Scenario passed");
			System.out.println(
				"Multi-manual fill option should be enabled even if client sent same instrument for various exchanges like TSE, NSE, FSE, MIX or CHJ. : Scenario passed");
			
			// ## Step 4: Multi-manual fill option should be enabled even if client attached to two different sessions.
			
			/// ### Check orders with different sessions but same client
			final WebElement orderRowClick_differentSession =
				driver.findElement(By.xpath(("//*[contains(text(),'15238746620TestAJ')]//../../td[6]")));
			
			checkDifferentExchangeOrSession_MultiFill(orderRowClick_differentSession);
			
			driver.switchTo().window(originalWindow);
			// Check the status of orders with different exchange after multi fill is done
			
			//// order 1 status///
			final WebElement Order_differentSession1 =
				driver.findElement(By.xpath(("//*[contains(text(),'15238746620TestAJ')]//../../td[6]")));
			
			Order_differentSession1.click();
			final String Order_differentSession1String = Order_differentSession1.getText();
			if(Order_differentExchange1String != null && "FILLED".equals(Order_differentSession1String))
			
			{
				System.out.println("Order_differentSession_1 is fully filled ");
				
			}
			else
			{
				System.out.println("Order_differentSession_1 is NOT fully filled");
			}
			
			// //order 2 status//
			final WebElement Order_differentSession2 =
				driver.findElement(By.xpath(("//*[contains(text(),'152387459118TestAJ')]//../../td[6]")));
			
			Order_differentSession2.click();
			final String Order_differentSession2String = Order_differentSession2.getText();
			if(Order_differentSession2String != null && "FILLED".equals(Order_differentSession2String))
			
			{
				System.out.println("Order_differentSession_2 is fully filled ");
				
			}
			else
			{
				System.out.println("Order_differentSession_2 is NOT fully filled");
			}
			
			Reporter.log(
				"Multi-manual fill option should be enabled even if client attached to two different sessions. : Scenario passed");
			System.out.println(
				"Multi-manual fill option should be enabled even if client attached to two different sessions. : Scenario passed");
			
			// ## Step 6: Multi-manual fill option should be enabled even if client user various OmsAccounts which
			// includes both Parent and Sub-Accounts.
			
			final WebElement orderRowClick_DifferentAccount =
				driver.findElement(By.xpath(("//*[contains(text(),'15238747482TestAJ')]//../../td[6]")));
			
			check_SameSideSameClient_DifferentAccount_MultiFill(orderRowClick_DifferentAccount);
			
			driver.switchTo().window(originalWindow);
			System.out.println("in original window");
			
			// ///order 1 status//
			driver.findElement(By.xpath("//*[contains(text(),'15238747482TestAJ')]//../../../td[6]")).click();
			final String verifyOrderstate1_DifferentAccount =
				driver.findElement(By.xpath("//*[contains(text(),'15238747482TestAJ')]//../../../td[6]")).getText();
			if(verifyOrderstate1_DifferentAccount != null
				&& "PARTIALLY FILLED".equals(verifyOrderstate1_DifferentAccount))
			
			{
				System.out.println("Order1 is being filled partially");
				
			}
			else
			{
				System.out.println("Order1 is not being filled partially");
			}
			
			// ///order 2 status//
			driver.findElement(By.xpath("//*[contains(text(),'15238747421TestAJ')]//../../../td[6]")).click();
			final String verifyOrderstate2_DifferentAccount =
				driver.findElement(By.xpath("//*[contains(text(),'15238747421TestAJ')]//../../../td[6]")).getText();
			if(verifyOrderstate2_DifferentAccount != null
				&& "PARTIALLY FILLED".equals(verifyOrderstate2_DifferentAccount))
			
			{
				System.out.println("Order2 is being filled partially");
				
			}
			else
			{
				System.out.println("Order2 is not being  filled partially");
			}
			
			// //order 3 status///
			driver.findElement(By.xpath("//*[contains(text(),'15238747300TestAJ')]//../../../td[6]")).click();
			final String verifyOrderstate3_DifferentAccount =
				driver.findElement(By.xpath("//*[contains(text(),'15238747300TestAJ')]//../../../td[6]")).getText();
			
			if(verifyOrderstate3_DifferentAccount != null
				&& "PARTIALLY FILLED".equals(verifyOrderstate3_DifferentAccount))
			
			{
				System.out.println("Order3 is being filled partially");
				
			}
			else
			{
				System.out.println("Order3 is not being filled partially");
			}
			
			Reporter.log(
				"Multi-manual fill option should be enabled even if client user various OmsAccounts which includes both Parent and Sub-Accounts : Scenario passed");
			System.out.println(
				"Multi-manual fill option should be enabled even if client user various OmsAccounts which includes both Parent and Sub-Accounts : Scenario passed");
			
			Check_differentState_Multifill();
			driver.switchTo().window(originalWindow);
			// ///order 1 status//
			driver.findElement(By.xpath("//*[contains(text(),'15238748000')]//../../../td[6]")).click();
			final String verifyOrderstate1_DifferentState =
				driver.findElement(By.xpath("//*[contains(text(),'15238748000')]//../../../td[6]")).getText();
			if(verifyOrderstate1_DifferentState != null && "FILLED".equals(verifyOrderstate1_DifferentState))
			
			{
				System.out.println("Order1 is being fully filled");
				
			}
			else
			{
				System.out.println("Order1 is not being fully filled");
			}
			
			///// order 2 status//
			driver.findElement(By.xpath("//*[contains(text(),'15238747760')]//../../../td[6]")).click();
			final String verifyOrderstate2_DifferentState =
				driver.findElement(By.xpath("//*[contains(text(),'15238747760')]//../../../td[6]")).getText();
			if(verifyOrderstate2_DifferentState != null && "CANCELLED".equals(verifyOrderstate2_DifferentState))
			{
				System.out.println("Order2 is being Cancelled");
				
			}
			else
			{
				System.out.println("Order2 is not being Cancelled");
			}
			Reporter.log(
				"Multi-manual fill option should be enabled even if clients orders in various states like cancelled, Amend : Scenario passed");
			System.out.println(
				"Multi-manual fill option should be enabled even if clients orders in various states like cancelled, Amend  : Scenario passed");
			// Sub part : step 8th ## Checking copy - paste functionality in step 8th
			final WebElement Order_forCopyCheck =
				driver.findElement(By.xpath("//*[contains(text(),'15238747482TestAJ')]//../../../td[6]"));
			
			Order_forCopyCheck.click();
			
			System.out.println(" row selected");
			
			try
			{
				Thread.sleep(2000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			action().contextClick(Order_forCopyCheck).sendKeys(Keys.RETURN).build().perform();
			System.out.println("right click on the selected  order");
			
			// Check whether multi fill option is present , if yes then click on the option
			final WebElement multiFilloption = driver.findElement(By.xpath("//*[@id='multiExecution']"));
			
			if(multiFilloption.getText() != null && "Multi Manual Fill (1 order)".equals(multiFilloption.getText()))
			{
				// # Click on multi fill button
				
				multiFilloption.click();
				Reporter.log("Multi fill option is enabaled");
				
				// New window is openend and now switch to new window
				switchWindow();
				try
				{
					Thread.sleep(2000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				// Fill value in text field 'Average Price'
				
				driver.findElement(By.xpath("//*[@id='average-price']")).sendKeys(AvgPrice);
				
				// Fill value in Exchange dropdown
				final WebElement Exchange = driver.findElement(By.xpath("//*[@id='top-exchange-select']"));
				dropdown(Exchange).selectByVisibleText(ExchangeDropdown);
				
				// Fill value in Last Capacity dropdown
				final WebElement Capacity = driver.findElement(By.xpath("//*[@id='top-last-capacity-select']"));
				dropdown(Capacity).selectByVisibleText(LastCapacityDropdown);
				
				// Fill value in Exec time text field
				
				final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
				
				final LocalTime time = LocalTime.now();
				final String t = formatter.format(time);
				
				driver.findElement(By.xpath("//*[@id='top-execution-time']")).clear();
				driver.findElement(By.xpath("//*[@id='top-execution-time']")).sendKeys(t);
				System.out.println("Value put in text feild");
				
				try
				{
					Thread.sleep(3000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				
				driver.findElement(By.xpath("//*[@id='fidessa-filled-quantity']")).sendKeys(totalFilledQuantity);
				driver.findElement(By.xpath("//*[@id='pro-rata-button']")).click();
				try
				{
					Thread.sleep(3000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
					
				}
				
				driver.findElement(By.xpath("//*[@id='copy-button']")).click();
				try
				{
					Thread.sleep(3000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				close_MultiFill_window();
				
				driver.switchTo().window(originalWindow);
				final WebElement Order_forCopyCheck1 =
					driver.findElement(By.xpath("//*[contains(text(),'15238747482TestAJ')]//../../../td[6]"));
				
				Order_forCopyCheck1.click();
				
				System.out.println(" row selected");
				
				try
				{
					Thread.sleep(2000);
				}
				catch(final InterruptedException e2)
				{
					e2.printStackTrace();
				}
				
				action().contextClick(Order_forCopyCheck1).sendKeys(Keys.RETURN).build().perform();
				System.out.println("right click on the selected  order");
				
				// Check whether multi fill option is present , if yes then click on the option
				final WebElement multiFilloption1 = driver.findElement(By.xpath("//*[@id='multiExecution']"));
				
				if(multiFilloption1.getText() != null
					&& "Multi Manual Fill (1 order)".equals(multiFilloption1.getText()))
				{
					// # Click on multi fill button
					
					multiFilloption.click();
					Reporter.log("Multi fill option is enabaled");
					
					// New window is openend and now switch to new window
					switchWindow();
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
					action().keyDown(Keys.CONTROL).sendKeys(Keys.chord("V")).keyUp(Keys.CONTROL).perform();
					
					// Verification of whether added values are reflected correctly
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e2)
					{
						e2.printStackTrace();
					}
					
					final WebElement Order_ExecQTY = driver.findElement(
						By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[1]/td[10]/q-progressbar/div"));
					final String Order_ExecQTYString = Order_ExecQTY.getText();
					System.out.println("Values in Filled column is  : " + Order_ExecQTYString);
					System.out.println("Functionality for copy-paste tested correctly!");
					close_MultiFill_window();
				}
			}
			else
			{
				System.out.println("Multi Manual Fill button is not present");
				Assert.fail("Multi Manual Fill button is not present");
				
			}
		}
		catch(final Exception e)
		{
			Reporter.log(
				"Test Case for 'Multi Manual fill' has Failed due to an exception : It has fetched the value : "
					+ textResult,
				false);
			Assert.fail("Selenium Error : 'Multi Manual fill' has Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Multi Manual fill : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
			driver.close();
		}
		
	}
	
	private void switchWindow()
	{
		// TODO Auto-generated method stub
		
		final String originalWindow = driver.getWindowHandle();
		// System.out.println(originalWindow);
		final Set<String> allWindow = driver.getWindowHandles();
		// System.out.println(allWindow);
		for(final String currentWindow: allWindow)
		{
			
			if(!currentWindow.equals(originalWindow))
			{
				driver.switchTo().window(currentWindow);
				// System.out.println(currentWindow);
				
				System.out.println("already switched");
			}
			else
			{
				System.out.println("No switching");
				
			}
			
		}
	}
	
	public Actions action()
	{
		final Actions actionObj = new Actions(driver);
		return actionObj;
	}
	
	public Select dropdown(final WebElement dropdownName)
	
	{
		final Select dropdownMenu = new Select(dropdownName);
		
		return dropdownMenu;
	}
	
	public void checkDMAorder_MultiFill(final String Case2_Order1)
	{
		final WebElement orderDMA_Rowclick = driver.findElement(By.xpath(Case2_Order1));
		orderDMA_Rowclick.click();
		System.out.println("DMA order selected");
		try
		{
			Thread.sleep(2000);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
		
		action().contextClick(orderDMA_Rowclick).sendKeys(Keys.RETURN).build().perform();
		System.out.println("right click on DMA order");
		
		// Check whether multi fill option is present , if yes then click on the option
		final WebElement multiFilloption_DMA = driver.findElement(By.xpath("//*[@id='multiExecution']"));
		
		if(multiFilloption_DMA.getText() != null
			&& "Multi Manual Fill (3 orders)".equals(multiFilloption_DMA.getText()))
		{
			// # Click on multi fill button
			multiFilloption_DMA.click();
			System.out.println("Multi fill option is enabaled ,instead for DMA order it should be disabled");
			Reporter.log("Multi fill option is enabaled");
			Assert.fail("Multi fill option is enabaled ,instead for DMA order it should be disabled");
		}
		else
		{
			System.out.println("Multi fill option is disabled: expected behaviour for DMA order");
			Reporter.log("Multi fill option is disabled: expected behaviour for DMA order");
			
		}
		
	}
	
	public void checkDifferentExchangeOrSession_MultiFill(final WebElement orderRowClick_selected)
	{
		
		orderRowClick_selected.click();
		
		// ###Select three orders with same client , same symbol and same side
		action().keyDown(Keys.SHIFT).sendKeys(Keys.ARROW_DOWN).keyUp(Keys.SHIFT).perform();
		
		System.out.println("all two rows selected");
		
		try
		{
			Thread.sleep(2000);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
		
		action().contextClick(orderRowClick_selected).sendKeys(Keys.RETURN).build().perform();
		System.out.println("right click on the selected 2 orders");
		
		// Check whether multi fill option is present , if yes then click on the option
		final WebElement multiFilloption = driver.findElement(By.xpath("//*[@id='multiExecution']"));
		
		if(multiFilloption.getText() != null && "Multi Manual Fill (2 orders)".equals(multiFilloption.getText()))
		{
			// # Click on multi fill button
			
			multiFilloption.click();
			
			Reporter.log("Multi fill option is enabaled");
			
			// New window is openend and now switch to new window
			switchWindow();
			try
			{
				Thread.sleep(2000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
				
			}
			// #####Verifying 'Multi fill execution' window elements!
			// Fill value in text field 'Average Price'
			
			driver.findElement(By.xpath("//*[@id='average-price']")).sendKeys(AvgPrice);
			
			// Fill value in Exchange dropdown
			final WebElement Exchange = driver.findElement(By.xpath("//*[@id='top-exchange-select']"));
			dropdown(Exchange).selectByVisibleText(ExchangeDropdown);
			
			// Fill value in Last Capacity dropdown
			final WebElement Capacity = driver.findElement(By.xpath("//*[@id='top-last-capacity-select']"));
			dropdown(Capacity).selectByVisibleText(LastCapacityDropdown);
			
			// Fill value in Exec time text field
			
			final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
			
			final LocalTime time = LocalTime.now();
			final String t = formatter.format(time);
			
			driver.findElement(By.xpath("//*[@id='top-execution-time']")).clear();
			
			driver.findElement(By.xpath("//*[@id='top-execution-time']")).sendKeys(t);
			
			driver.findElement(By.xpath("//*[@id='fully-fill-button']")).click();
			driver.findElement(By.xpath("//*[@id='send-all-button']")).click();
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.switchTo().alert().accept();
			
			// Verification of whether added values are reflected correctly
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.switchTo().alert().accept();
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			// *[@id="q-render-table-multiple-executions"]/tbody/tr[1]/td[4]/span/input
			
			final WebElement check_Filledstatus = driver.findElement(
				By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[1]/td[10]/q-progressbar/div"));
			final String Check_filledstatusString = check_Filledstatus.getText();
			System.out
				.println("Values in Filled column is same as Order Qty and equal to  : " + Check_filledstatusString);
			
			close_MultiFill_window();
			
		}
		else
		
		{
			System.out.println("Multi Manual Fill button is not present");
			Assert.fail("Multi Manual Fill button is not present");
		}
		
	}
	
	public void check_SameSideSameClient_DifferentAccount_MultiFill(final WebElement orderRowClick)
	{
		
		orderRowClick.click();
		
		// ###Select three orders with same client , same symbol and same side
		action().keyDown(Keys.SHIFT).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).keyUp(Keys.SHIFT).perform();
		
		System.out.println("all three rows selected");
		
		try
		{
			Thread.sleep(2000);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
		
		action().contextClick(orderRowClick).sendKeys(Keys.RETURN).build().perform();
		System.out.println("right click on the selected 3 orders");
		
		// Check whether multi fill option is present , if yes then click on the option
		final WebElement multiFilloption = driver.findElement(By.xpath("//*[@id='multiExecution']"));
		
		if(multiFilloption.getText() != null && "Multi Manual Fill (3 orders)".equals(multiFilloption.getText()))
		{
			// # Click on multi fill button
			
			multiFilloption.click();
			
			Reporter.log("Multi fill option is enabaled");
			
			// New window is openend and now switch to new window
			switchWindow();
			try
			{
				Thread.sleep(2000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
				
			}
			
			// #####Verifying 'Multi fill execution' window elements!
			
			// Fill value in text field 'Average Price'
			
			driver.findElement(By.xpath("//*[@id='average-price']")).sendKeys(AvgPrice);
			
			// Fill value in Exchange dropdown
			final WebElement Exchange = driver.findElement(By.xpath("//*[@id='top-exchange-select']"));
			dropdown(Exchange).selectByVisibleText(ExchangeDropdown);
			
			// Fill value in Last Capacity dropdown
			final WebElement Capacity = driver.findElement(By.xpath("//*[@id='top-last-capacity-select']"));
			dropdown(Capacity).selectByVisibleText(LastCapacityDropdown);
			
			// Fill value in Exec time text field
			
			final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
			
			final LocalTime time = LocalTime.now();
			final String t = formatter.format(time);
			
			driver.findElement(By.xpath("//*[@id='top-execution-time']")).clear();
			
			driver.findElement(By.xpath("//*[@id='top-execution-time']")).sendKeys(t);
			
			System.out.println("Value put in text feild");
			
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.findElement(By.xpath("//*[@id='fidessa-filled-quantity']")).sendKeys(totalFilledQuantity);
			
			driver.findElement(By.xpath("//*[@id='pro-rata-button']")).click();
			driver.findElement(By.xpath("//*[@id='send-all-button']")).click();
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.switchTo().alert().accept();
			
			// Verification of whether added values are reflected correctly
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.switchTo().alert().accept();
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			final WebElement ExecPrice_Order = driver.findElement(By.xpath("//*[@id='json-executions-holder']"));
			final String ExecPrice_Order_string = ExecPrice_Order.getAttribute("value");
			
			int numberOfoccurrence_ExecPrice = 0;
			System.out.println(ExecPrice_Order_string);
			
			for(int positionOf_ExecPrice = -1; (positionOf_ExecPrice =
				ExecPrice_Order_string.indexOf(match, positionOf_ExecPrice + 1)) != -1; positionOf_ExecPrice++)
			{
				System.out.println("positionOf_ExecPrice" + numberOfoccurrence_ExecPrice + " :" + positionOf_ExecPrice);
				numberOfoccurrence_ExecPrice++;
			}
			
			if(numberOfoccurrence_ExecPrice != 3)
			{
				System.out.println("Exec price is NOT present for all orders");
				Assert.fail("Exec price is NOT present for all orders");
			}
			else
			{
				System.out.println("Exec price is same as Avg Price and present for all orders");
				
			}
			
//###Check for the exchange drop down ,whether all the options are selected correctly in execution tab for all orders
			final WebElement exchangeOrder1 =
				driver.findElement(By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[1]/td[7]/select"));
			final WebElement exchangeOrder2 =
				driver.findElement(By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[2]/td[7]/select"));
			final WebElement exchangeOrder3 =
				driver.findElement(By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[3]/td[7]/select"));
			
			final String exchangeOrder1_selection = dropdown(exchangeOrder1).getFirstSelectedOption().getText();
			final String exchangeOrder2_selection = dropdown(exchangeOrder2).getFirstSelectedOption().getText();
			final String exchangeOrder3_selection = dropdown(exchangeOrder3).getFirstSelectedOption().getText();
			
			System.out
				.println(exchangeOrder1_selection + "  " + exchangeOrder2_selection + "  " + exchangeOrder3_selection);
			
			if(exchangeOrder1_selection != null
				&& ExchangeDropdown.equals(exchangeOrder1_selection)
				&& exchangeOrder2_selection != null
				&&
				ExchangeDropdown.equals(exchangeOrder2_selection)
				&& exchangeOrder3_selection != null
				&& ExchangeDropdown.equals(exchangeOrder3_selection))
			{
				System.out.println(
					"Exchange drop down value selected for all orders is same as the one selected in Main exchange dropdown  ");
				
			}
			else
			{
				System.out.println(
					"Exchange drop down value selected for all orders is NOT same as the one selected in Main exchange dropdown  ");
				Assert.fail(
					"Exchange drop down value selected for all orders is NOT same as the one selected in Main exchange dropdown  ");
			}
			
//###Check for the Last Capacity drop down ,whether all the options are selected correctly in execution tab for all orders
			final WebElement lastCapacity1 =
				driver.findElement(By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[1]/td[8]/select"));
			final WebElement lastCapacity2 =
				driver.findElement(By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[2]/td[8]/select"));
			final WebElement lastCapacity3 =
				driver.findElement(By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[3]/td[8]/select"));
			
			final String lastCapacityOrder1_selection = dropdown(lastCapacity1).getFirstSelectedOption().getText();
			final String lastCapacityOrder2_selection = dropdown(lastCapacity2).getFirstSelectedOption().getText();
			final String lastCapacityOrder3_selection = dropdown(lastCapacity3).getFirstSelectedOption().getText();
			
			System.out.println(lastCapacityOrder1_selection
				+ "  "
				+ lastCapacityOrder2_selection
				+ "  "
				+ lastCapacityOrder3_selection);
			
			if(lastCapacityOrder1_selection != null
				&& LastCapacityDropdown.equals(lastCapacityOrder1_selection)
				&& lastCapacityOrder2_selection != null
				&&
				LastCapacityDropdown.equals(lastCapacityOrder2_selection)
				&& lastCapacityOrder3_selection != null
				&& LastCapacityDropdown.equals(lastCapacityOrder3_selection))
			{
				System.out.println(
					"Last capacity drop down value selected for all orders is same as the one selected in Main LastCapacity dropdown  ");
				
			}
			else
			{
				System.out.println(
					"Last capacity drop down value selected for all orders is NOT same as the one selected in Main LastCapacity dropdown ");
				Assert.fail(
					"Last capacity drop down value selected for all orders is NOT same as the one selected in Main LastCapacity dropdown ");
			}
			
			final WebElement ExecTime_Order = driver.findElement(By.xpath("//*[@id='json-executions-holder']"));
			final String ExecTime_Order_string = ExecTime_Order.getAttribute("value");
			
			int numberOfoccurrence_ExecTime = 0;
			System.out.println(ExecTime_Order_string);
			
			for(int positionOf_ExecTime = -1; (positionOf_ExecTime =
				ExecTime_Order_string.indexOf(t, positionOf_ExecTime + 1)) != -1; positionOf_ExecTime++)
			{
				System.out.println("positionOf_ExecTime" + numberOfoccurrence_ExecTime + " :" + positionOf_ExecTime);
				numberOfoccurrence_ExecTime++;
			}
			
			if(numberOfoccurrence_ExecTime != 3)
			{
				System.out.println("Exec time is NOT present for all orders");
				Assert.fail("Exec time is NOT present for all orders");
			}
			else
			{
				System.out.println("Exec time is same as Exec time in main block and present for all orders");
			}
			close_MultiFill_window();
			
		}
		
		else
		{
			System.out.println("Multi Manual Fill button is not present");
			Assert.fail("Multi Manual Fill button is not present");
		}
		
	}
	
	public void close_MultiFill_window()
	{
		driver.findElement(By.xpath("//*[@id='close-button']")).click();
	}
	
	public void Check_differentState_Multifill()
	{
		
		final WebElement orderRowClick_differentState =
			driver.findElement(By.xpath(("//*[contains(text(),'15238748000')]//../../td[6]")));
		
		orderRowClick_differentState.click();
		
		action().keyDown(Keys.SHIFT).sendKeys(Keys.ARROW_DOWN).keyUp(Keys.SHIFT).perform();
		
		System.out.println("all two rows selected");
		
		try
		{
			Thread.sleep(2000);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
		
		action().contextClick(orderRowClick_differentState).sendKeys(Keys.RETURN).build().perform();
		System.out.println("right click on the selected 2 orders");
		
		// Check whether multi fill option is present , if yes then click on the option
		final WebElement multiFilloption = driver.findElement(By.xpath("//*[@id='multiExecution']"));
		
		if(multiFilloption.getText() != null && "Multi Manual Fill (2 orders)".equals(multiFilloption.getText()))
		{
			// # Click on multi fill button
			
			multiFilloption.click();
			
			Reporter.log("Multi fill option is enabaled");
			
			// New window is openend and now switch to new window
			switchWindow();
			try
			{
				Thread.sleep(2000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
				
			}
			// #####Verifying 'Multi fill execution' window elements!
			// Fill value in text field 'Average Price'
			
			driver.findElement(By.xpath("//*[@id='average-price']")).sendKeys(AvgPrice);
			
			// Fill value in Exchange dropdown
			final WebElement Exchange = driver.findElement(By.xpath("//*[@id='top-exchange-select']"));
			dropdown(Exchange).selectByVisibleText(ExchangeDropdown);
			
			// Fill value in Last Capacity dropdown
			final WebElement Capacity = driver.findElement(By.xpath("//*[@id='top-last-capacity-select']"));
			dropdown(Capacity).selectByVisibleText(LastCapacityDropdown);
			
			// Fill value in Exec time text field
			
			final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
			
			final LocalTime time = LocalTime.now();
			final String t = formatter.format(time);
			
			driver.findElement(By.xpath("//*[@id='top-execution-time']")).clear();
			
			driver.findElement(By.xpath("//*[@id='top-execution-time']")).sendKeys(t);
			
			driver.findElement(By.xpath("//*[@id='fully-fill-button']")).click();
			driver.findElement(By.xpath("//*[@id='send-all-button']")).click();
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.switchTo().alert().accept();
			
			// Verification of whether added values are reflected correctly
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.switchTo().alert().accept();
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			final WebElement AmendedOrder_ExecQTY = driver.findElement(
				By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[1]/td[10]/q-progressbar/div"));
			final String AmendedOrder_ExecQTYString = AmendedOrder_ExecQTY.getText();
			System.out.println("Values in Filled column is  : " + AmendedOrder_ExecQTYString);
			
			final WebElement cancelledOrder_ExecQTY =
				driver.findElement(By.xpath("//*[@id='q-render-table-multiple-executions']/tbody/tr[2]/td[4]"));
			final String cancelledOrder_ExecQTYString = cancelledOrder_ExecQTY.getText();
			System.out.println("Values in Exec QTY column is  : " + cancelledOrder_ExecQTYString);
			
			if("0 (order cancelled)".equals(cancelledOrder_ExecQTYString))
			{
				System.out
					.println("Cancelled order is correctly shown with the status and no action was performed over it");
				
			}
			else
			{
				System.out.println("Cancelled order is not shown with the status");
				
			}
			close_MultiFill_window();
			
		}
		else
		
		{
			System.out.println("Multi Manual Fill button is not present");
			Assert.fail("Multi Manual Fill button is not present");
		}
		
	}
	
}
