// Author: Sankalp Jain
// Creation Date : 2019-01-21
// JIRA : SEL-95

package com.mizuhosc.selenium.scripts.monitoring;

import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.NoSuchElementException;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;
import com.mizuhosc.selenium.functionlibraries.*;

public class AddOrderNotes
{
	
	WebDriver driver = null;
	
	private static String getTimeStamp()
	{
		return new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	}
	
	@Parameters({"username", "password", "quattroEnv", "browser", "ClOrderID"})
	@Test
	public void addOrderNotes(final String user, final String pass, final String monEnv, final String browser, final String ClOrderID)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// Selects appropriate browser as declared by user in global declaration
			
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))// Internet Explorer Driver
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.id("signin")).submit();

			
			
			Reporter.log(String.format("[%s Right Click] Waiting for ClOrderId to appear in Monitoring GUI",getTimeStamp()), true);
			
			@SuppressWarnings("unused")
						
			WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'" + ClOrderID + "')]")));// 20:21:28.
			  
			WebElement webElement = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));

			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI ",getTimeStamp()), true);
			
			// Do the first right-click on the the first order 
			Actions addOrderNotesAction = new Actions(driver);
			addOrderNotesAction.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			WebElement addOrderNotes = driver.findElement(By.xpath("//*[@id='addOrderNotes']")); // Find out Id of Add OrderNotes right
			// Click on Add order Notes menu item
			addOrderNotes.click();
			
			System.out.println("Waiting for Right Click Add Order Notes to be clicked");
			//Reporter.log(String.format("[%s Right Click] Waiting for Right Click Add Order Notes to be clicked", getTimeStamp(),e.getMessage());
			Reporter.log(String.format("[%s Right Click] Waiting for Right Click Add Order Notes to be clicked",getTimeStamp()), true);
			
			System.out.println("Sleeping for 2 secs");
			Reporter.log(String.format("[%s Right Click] Sleeping for 2 secs",getTimeStamp()), true);
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
		
			System.out.println("Right Click Add Order Notes Completed");
			Reporter.log(String.format("[%s Right Click] Right Click Add Order Notes Completed",getTimeStamp()), true);
			
			// Pass the Text to the Add OrderNotes Dialogue Box
			WebElement addOrderNotesTextBox = driver.findElement(By.xpath("//*[@id='dialog-container']/div/div[2]/input")); // Find out Id of Add OrderNotes right
			addOrderNotesTextBox.click();
			driver.findElement(By.xpath("//*[@id='dialog-container']/div/div[2]/input")).sendKeys("Adding order notes for test1");
		
			
			System.out.println("Waiting for Text to be passed to Add OrderNotes Dialogue Box");
			Reporter.log(String.format("[%s AddOrderNotes Dialogue Box] Waiting for Text to be passed to Add OrderNotes Dialogue Box",getTimeStamp()), true);
			
			System.out.println("Sleeping for 2 secs");
			Reporter.log("[%s AddOrderNotes Dialogue Box] Sleeping for 2 secs");
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
		
			System.out.println("Text is passed to Add OrderNotes Dialogue Box");
			Reporter.log(String.format("[%s AddOrderNotes Dialogue Box] Text is passed to Add OrderNotes Dialogue Box",getTimeStamp()), true);
			// Click on OK button
			WebElement OKBox = driver.findElement(By.xpath("//*[@id='dialog-container']/div/div[3]/q-button[2]"));
			OKBox.click();
			
			System.out.println("Sleeping for 2 secs to click on OK Box");
			Reporter.log(String.format("[%s OK Button] Sleeping for 2 secs to click on OK Box",getTimeStamp()), true);
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
				
			}
			
			System.out.println("OK Box Clicked");
			Reporter.log(String.format("[%s OK Button] OK Box Clicked",getTimeStamp()), true);
			
			// Do the 2nd right-click on the the first order 
			Actions forceDequeueAction = new Actions(driver);
			forceDequeueAction.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			WebElement forceDequeue = driver.findElement(By.xpath("//*[@id='forceDequeue']")); // This will select menu after right click
			// Click on Force Dequeue menu item
			forceDequeue.click();
						
			System.out.println("Waiting for force dequeue to finish");
			Reporter.log(String.format("[%s Right Click] Waiting for force dequeue to finish",getTimeStamp()), true);
			System.out.println("Sleeping for 2 secs");
			Reporter.log(String.format("[%s Right Click] Sleeping for 2 secs",getTimeStamp()), true);
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.switchTo().alert().accept();
			Thread.sleep(3000);
			System.out.println("ForceDequeue Successful");
			Reporter.log(String.format("[%s Right Click] ForceDequeue Successful",getTimeStamp()), true);
			
			
			//Checking Order status is Active or not
			
         	Boolean orderStatusResult=CommonFunctions.CheckOrderStatus(ClOrderID,"ACTIVE",driver);
			
         	if(orderStatusResult == true)
			{
				System.out.println("State of order is Active");
				assertTrue(true);
				Reporter.log(String.format("[%s Order status] Order status is Active ",getTimeStamp()), true);
						
			}
			else
			{
				System.out.println("State of order is not Active");
				Assert.fail("Order status is not Active. So failing the Selenium case");
				Reporter.log(String.format("[%s Order status] Order status is not Active ",getTimeStamp()), true);
			}
			//Checking if the Add Order Notes should not be available when the order is not queue or its active
			
			addOrderNotesAction = new Actions(driver);
			addOrderNotesAction.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			try{
				addOrderNotes.click();
				Assert.fail("Add Order Notes Right Click Menu option available on the Active Order. So failing the Selenium case");
				Reporter.log(String.format("[%s Right Click] Add Order Notes Right Click Menu option available on the Active Order.So failing the Selenium case ",getTimeStamp()), true);
			}
			catch (Exception e)
			{
				assertTrue(true);
				Reporter.log(String.format("[%s Right Click] Add Order Notes Right Click Menu option NOT available on the Active Order.So Passing the Selenium case ",getTimeStamp()), true);
								
			}
					
			driver.quit();
									
		}
		catch(final Exception e)
		{
		    Reporter.log(String.format("[%s Exception] Case could not be checked properly due to an exception thrown by Browser i.e. ",getTimeStamp()),true);
			Assert.fail("Exception details are  " + e.getMessage());
			driver.quit();
			
		}
	}

	
}
