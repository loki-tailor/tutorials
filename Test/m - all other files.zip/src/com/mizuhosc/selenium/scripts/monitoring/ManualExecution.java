package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class ManualExecution
{
	
	int orderEngine = 9;
	WebDriver driver = null;
	
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void manualExecution(final String user, final String pass, final String monEnv, final String browser)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// Selects appropriate browser as declared by user in global declaration
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))// Internet Explorer Driver
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.id("signin")).submit();
			
			@SuppressWarnings("unused") final WebElement waitForStatus =
				new WebDriverWait(driver, 90)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'16:19:38')]")));
			final String homePage = driver.getWindowHandle();
			System.out.println(homePage);
			final Actions action1 = new Actions(driver);
			
			// #### Click on the top most order and open pop-up window to Match Spread
			action1
				// .moveToElement(driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]")))
				.moveToElement(driver.findElement(By.xpath("//*[contains(text(),'16:19:38')]")))
				.doubleClick()
				.build()
				.perform();
			
			System.out.print("New window of Latest Order opens");
			// Checking no. of windows openned by web driver
			final Set<String> allWindows = driver.getWindowHandles();
			System.out.println("Number of Windows active = ");
			System.out.println(allWindows.size());
			final Iterator<String> iterator = allWindows.iterator();
			String currentWindows = driver.getWindowHandle();
			while(iterator.hasNext())// Working with another tab
			{
				currentWindows = iterator.next().toString();
				System.out.println(currentWindows);
				if(!currentWindows.equals(homePage))
				{
					driver.switchTo().window(currentWindows);
					
					// STEP 1 : New order new tab
					System.out.println(" We are in new Tab : for Manual Execution");
					
					// driver.findElement(By.xpath("/html/body/div[5]/ul/li[3]/a/span")).click();// Syn Spread Tab
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					// STEP 2 : 200 : Ignore the step : Alert is popped up
					
					// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					/*
					 * click on allow overfill checkbox
					 * driver.findElement(By.xpath("//*[@id='allow-execution-overfill']")).click();
					 * driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					 */
					driver
						.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input"))
						.sendKeys("200");
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).sendKeys(
						"19000");
					
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					try
					{
						Thread.sleep(1200);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(1800);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					
					try
					{
						Thread.sleep(1800);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(1500);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					/*
					 * accepting the warning for overfill alert
					 * driver.switchTo().alert().dismiss();
					 * try
					 * {
					 * Thread.sleep(1500);
					 * }
					 * catch(InterruptedException e1)
					 * {
					 * e1.printStackTrace();
					 * }
					 */
					
					// cancel
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[1]/a")).click();
					
					// String noFill1 =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// if(noFill1 != null && "no fills".equals(noFill1))
					// {
					// Reporter.log("All executions are busted Successful for this order", true);
					//
					// try
					// {
					// Thread.sleep(1000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					//
					// }
					// else
					// {
					// Reporter.log("Bust all was unable to process : Different value fetched", true);
					// Assert.fail("Negative Case check failed : It should give a warning!!!!!!!!!!!!!!!!!!!");
					//
					// }
					
					// STEP 3 : 50 : no alert manual partial fill sent
					
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input")).clear();
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver
						.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input"))
						.sendKeys("50");
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).clear();
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).sendKeys(
						"19000.2525");
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(4000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					// String partialFillCheck =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					// // Additonal check
					// if(partialFillCheck != null && "partially filled to 50".equals(partialFillCheck))
					// {
					// Reporter.log("Partial Fill for 50 Successful", true);
					//
					// try
					// {
					// Thread.sleep(5000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					// }
					// else
					// {
					// Reporter.log("Partial Fill for 50 failed ", true);
					// Assert.fail("Partial fill for 50 failed!!!!!!!!!!!!!!!!!!!");
					//
					// }
					
					// STEP 4 : 100 : Ignore the step : Alert is popped up
					
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver
						.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input"))
						.sendKeys("100");
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).sendKeys(
						"19000");
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					
					// cancel
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[1]/a")).click();
					
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
					// String noFill2 =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// if(noFill2 != null && "partially filled to 50".equals(noFill2))
					// {
					// Reporter.log(
					// "Ignored the step as Quantity is higher and no overfill is not enabled : Last Value is intact ",
					// true);
					//
					// try
					// {
					// Thread.sleep(5000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					//
					// }
					// else
					// {
					// Reporter.log("Overfill check box issue: Not checked still it behaved errorneously", true);
					// Assert.fail("Expected : Should ignore the step with an alert!!!!!!!!!!!!!!!!!!!");
					//
					// }
					
					// STEP 5 : 50 : no alert manual partial fill sent
					
					driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver
						.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input"))
						.sendKeys("50");
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).sendKeys(
						"19000");
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					// String fullFillCheck2 =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// if(fullFillCheck2 != null && "fully filled to 100".equals(fullFillCheck2))
					// {
					// Reporter.log("fully filled to 100 Successful", true);
					//
					// try
					// {
					// Thread.sleep(5000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					// }
					// else
					// {
					// Reporter.log("fully filled to 100 was unable to process : Different value fetched", true);
					// Assert.fail("fully filled to 100 failed!!!!!!!!!!!!!!!!!!!");
					//
					// }
					
					// STEP 6 : Trade correct : 40 for the above manual fill : Alert pops up
					// Waiting for the order from Marathon
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					// driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					// find the element to be right clicked
					final WebElement webElement =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[2]/td[5]"));
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					final Actions action = new Actions(driver);
					
					action.contextClick(webElement).moveByOffset(50, 10).click().build().perform();
					
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					// Put code to clear
					driver
						.findElement(By.xpath("//*[@id='q-render-table-executions']//tr[2]/td[5]/input"))
						.clear();
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver
						.findElement(By.xpath("//*[@id='q-render-table-executions']//tr[2]/td[5]/input"))
						.sendKeys("40");
					// xpath=//div[@class='search-container']/descendant::input[position()=2]
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
					final WebElement webElement2 =
						driver.findElement(
							By.xpath(
								"//*[@class='Added_Manually q-table-row expandable']/../tr[2]/td[11]/q-button[1]"));
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					final Actions action2 = new Actions(driver);
					
					action2.contextClick(webElement2).moveByOffset(10, 9).click().build().perform();
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(5000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					// partially filled to 90
					// String pf2 =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// if(pf2 != null && "partially filled to 90".equals(pf2))
					// {
					// Reporter.log("partially filled to 90 Successful", true);
					//
					// try
					// {
					// Thread.sleep(3000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					//
					// }
					// else
					// {
					// Reporter.log("partially filled to 90 was unable to process : Different value fetched", true);
					// Assert.fail("partially filled to 90 failed!!!!!!!!!!!!!!!!!!!");
					//
					// }
					
					// STEP 7 : Bust the corrected manual
					
					final WebElement webElement3 =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[3]/td[4]"));
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					final Actions action3 = new Actions(driver);
					
					action3.contextClick(webElement3).moveByOffset(100, 30).click().build().perform();
					
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					
					try
					{
						Thread.sleep(4000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					// String pf3 =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// if(pf3 != null && "partially filled to 50".equals(pf3))
					// {
					// Reporter.log("partially filled to 50 Successful", true);
					//
					// try
					// {
					// Thread.sleep(5000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					//
					// }
					// else
					// {
					// Reporter.log(
					// "partially filled to 50 was unable to process : Different value fetched : " + pf3,
					// true);
					// Assert.fail("partially filled to 50 failed!!!!!!!!!!!!!!!!!!!");
					//
					// }
					// STEP 8 : Fill 50 : No Alert
					
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver
						.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input"))
						.sendKeys("50");
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).sendKeys(
						"19000");
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					// String pf4 =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// if(pf4 != null && "fully filled to 100".equals(pf4))
					// {
					// Reporter.log("fully filled to 100 Successful", true);
					//
					// try
					// {
					// Thread.sleep(5000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					//
					// }
					// else
					// {
					// Reporter.log("fully filled to 100 was unable to process : Different value fetched", true);
					// Assert.fail("fully filled to 100 failed!!!!!!!!!!!!!!!!!!!");
					//
					// }
					// STEP 9 : overfill 150 : ALERTS
					
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='allow-execution-overfill']")).click();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver
						.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input"))
						.sendKeys("150");
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).sendKeys(
						"19000");
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					driver.switchTo().alert().accept();
					
					try
					{
						Thread.sleep(5000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					final String overfill =
						driver
							.findElement(By.xpath("//*[@id='order-details']/table/tbody/tr[5]/td[4]/span"))
							.getText();
					
					if(overfill != null && "overfilled to 250".equals(overfill))
					{
						Reporter.log("overfilled to 250 Successful", true);
						
						try
						{
							Thread.sleep(5000);
						}
						catch(final InterruptedException e2)
						{
							e2.printStackTrace();
						}
						
					}
					else
					{
						Reporter.log("overfilled to 250 was unable to process : Different value fetched", true);
						Assert.fail("overfilled to 250 was failed!!!!!!!!!!!!!!!!!!!");
						
					}
					// STEP 10 : Bust all
					
					// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					
					// driver.findElement(By.xpath("//tbody")).sendKeys(Keys.chord(Keys.CONTROL, "a"));
					try
					{
						Thread.sleep(5000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
//					WebElement webElement5 =
//						driver.findElement(
//							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[3]/td[4]"));
//					Actions action11 = new Actions(driver);
//					action11
//						//.contextClick(webElement5)
//						.click(webElement5)
//						.keyDown(Keys.CONTROL)
//						.sendKeys(String.valueOf('\u0061'))
//						.build()
//						.perform();
//					
//					WebElement webElement4 =
//						driver.findElement(
//							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[3]/td[4]"));
//					
//					try
//					{
//						Thread.sleep(2000);
//					}
//					catch(InterruptedException e)
//					{
//						e.printStackTrace();
//					}
//					Actions action4 = new Actions(driver);
//					action4.contextClick(webElement4).moveByOffset(5, 5).click().build().perform();
//					// action4.click();
					
					// Bust fill one by one
					// -----------------------------------------1.Bust fill of 50 qty with price 1900.2525
					
					final WebElement webElement5 =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[2]/td[5]"));
					
					final Actions actionObj3 = new Actions(driver);
					actionObj3.contextClick(webElement5).sendKeys(Keys.RETURN).build().perform();
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					final WebElement BustExecution = driver.findElement(By.xpath("//*[@id='bust-execution']"));
					BustExecution.click();
					
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					// ---------------------------2.Bust fill of 50 qty with price 1900
					final WebElement webElement6 =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[4]/td[4]"));
					
					final Actions actionObj4 = new Actions(driver);
					actionObj3.contextClick(webElement6).sendKeys(Keys.RETURN).build().perform();
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					BustExecution.click();
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					// ---------------------------3.Bust fill of 150 qty with price 1900
					
					final WebElement webElement7 =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[1]/td[5]"));
					
					final Actions actionObj5 = new Actions(driver);
					actionObj3.contextClick(webElement7).sendKeys(Keys.RETURN).build().perform();
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					BustExecution.click();
					
					// ---------------------------------
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					Reporter.log("Manual execution bust, after Overfill to 250", true);
					// String noFill =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// if(noFill != null && "no fills".equals(noFill))
					// {
					// Reporter.log("All executions are busted Successful for this order", true);
					//
					// try
					// {
					// Thread.sleep(5000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					//
					// }
					// else
					// {
					// Reporter.log("Bust all was unable to process : Different value fetched", true);
					// Assert.fail("overfilled to 250 was failed!!!!!!!!!!!!!!!!!!!");
					//
					// }
					// STEP 11 : Fill 50 : No Alert
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					driver.findElement(By.xpath("//*[@id='add-execution-row']//td[5]/input")).clear();
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='add-execution-row']//td[5]/input")).sendKeys("50");
					
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).clear();
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).sendKeys(
						"19000");
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
//					driver.findElement(By.xpath("//*[@id='add-execution-row']//td[4]/input")).sendKeys("50");
//					try
//					{
//						Thread.sleep(1000);
//					}
//					catch(InterruptedException e)
//					{
//						e.printStackTrace();
//					}
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					Reporter.log("PF of 50, after Manual execution bust", true);
					// String partialFillCheck2 =
					// driver
					// .findElement(By.xpath("//*[@id='orderInformation']//div/div/table/tbody/tr[5]/td[4]"))
					// .getText();
					//
					// // Additonal check
					// if(partialFillCheck2 != null && "partially filled to 50".equals(partialFillCheck2))
					// {
					// Reporter.log("Partial Fill for 50 Successful", true);
					//
					// try
					// {
					// Thread.sleep(5000);
					// }
					// catch(InterruptedException e2)
					// {
					// e2.printStackTrace();
					// }
					// }
					// else
					// {
					// Reporter.log("Partial Fill for 50 failed ", true);
					// Assert.fail("Partial fill for 50 failed!!!!!!!!!!!!!!!!!!!");
					//
					// }
					// STEP 12 : Fill 50 : No Alert
					
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					// driver.findElement(By.xpath("//ul[@class='tabs']/li[2]/a/span")).click();
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='executions-list-edit-button']/span[2]/a")).click();
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input")).clear();
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver
						.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[5]/input"))
						.sendKeys("50");
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					Reporter.log("FF, after Manual execution bust", true);
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6]/input")).clear();
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					driver.findElement(By.xpath("//*[@class='execution-table']/tbody/tr[1]/td[6"
							+ ""
							+ "]/input")).sendKeys(
						"19000");
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					try
					{
						Thread.sleep(1000);
					}
					catch(final InterruptedException e)
					{
						e.printStackTrace();
					}
					
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					// added extra alert accept for JIRA 8823
					try
					{
						Thread.sleep(2000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					driver.switchTo().alert().accept();
					try
					{
						Thread.sleep(3000);
					}
					catch(final InterruptedException e1)
					{
						e1.printStackTrace();
					}
					
					final WebElement webElementHK =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[3]/td[4]"));
					final Actions actionall = new Actions(driver);
					actionall
						// .contextClick(webElement5)
						.click(webElementHK)
						.keyDown(Keys.CONTROL)
						.sendKeys(String.valueOf('\u0061'))
						.build()
						.perform();
					Thread.sleep(2000);
					
					final WebElement webElementHK1 =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-executions']/tbody/tr[3]/td[4]"));
					
					final Actions actionRightCLick = new Actions(driver);
					
					actionRightCLick.contextClick(webElementHK1).sendKeys(Keys.RETURN).build().perform();
					Thread.sleep(1000);
					final Actions actionFight = new Actions(driver);
					actionFight.click(driver.findElement(By.xpath("//*[contains(text(),'Save all to Excel (7')]")))
						.build().perform();
					// driver.findElement(By.xpath("//*[contains(text(),'Save all to Excel (7')]")).click();
					Thread.sleep(1000);
					System.out.println("downloaded executions");
					
				}
			}
			driver.quit();
			
		}
		catch(final Exception e)
		{
			Reporter.log("Case could not be checked properly due to an exception thrown by Browser i.e. " + e, true);
			driver.quit();
			Assert.fail("Exception details are " + e);
		}
	}
	
}
