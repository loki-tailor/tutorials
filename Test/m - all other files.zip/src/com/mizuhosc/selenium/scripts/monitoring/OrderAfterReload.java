package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class OrderAfterReload
{
	private String testResult;
	private WebDriver driver; // Selects appropraite driver
	
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickDfd(final String user, final String pass, final String monEnv, final String browser)
	{
		
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			new WebDriverWait(driver, 30)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'18:52:44')]")));// 20:21:28.
			
			Thread.sleep(3000);
			
			driver.switchTo().alert().accept();
			System.out.println("DFD Successful");
			Thread.sleep(5000);
			// Verify the order status turns to "Done for Day" on monitoring screen
			final WebElement RejectedOrder =
				driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']/tbody/tr/td[6]"));
			System.out.println("Value fetched : DFD: " + RejectedOrder.getText());
			testResult = RejectedOrder.getText();
			if(RejectedOrder.getText() != null && "REJECTED".equals(RejectedOrder.getText()))
			{
				Reporter.log("Test Case for OrderAfterReolad has passed : It has fetched the value : " + testResult,
					true);
				System.out.println("OrderAfterReolad Functionality check : Passed");
				
				Thread.sleep(5000);
				driver.close();
			}
			else
			{
				Reporter.log("Test Case for OrderAfterReolad has Failed : It has fetched the value : " + testResult,
					true);
				Assert.fail("Case functionality Error : Expected : \"REJECTED\" !!!!!!!!!!!!!!!!!!!");
				driver.close();
			}
		}
		catch(final Exception e)
		{
			Reporter.log(
				"Test Case for OrderAfterReolad has Failed due to an exception : It has fetched the value : "
					+ testResult,
				false);
			Assert.fail("Selenium Error : OrderAfterReolad check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Dfd check : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
			driver.close();
			
		}
	}
	
}
