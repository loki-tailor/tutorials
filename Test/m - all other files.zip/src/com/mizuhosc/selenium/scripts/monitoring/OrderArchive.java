package com.mizuhosc.selenium.scripts.monitoring;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import sun.misc.BASE64Decoder;

public class OrderArchive {
	WebDriver driver = null;

	@Test
	@Parameters({ "username", "password", "quattroEnv", "browser" })
	public void archiveOrder(String user, String pass, String monEnv, String browser) {
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try {
			// System.out.println("My username is " + user + "monitoring Env" +
			// monEnv + "browser" + browser);

			// Selects appropraite driver
			if (browser.equals("Mozilla")) {
				driver = new FirefoxDriver();
			} else if (browser.equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			} else if (browser.equals("IE")) {
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen

			/***
			 * TODO QA10 - http://tkqtrapq18.mizuho-sc.com:9010/quattro/login
			 */

			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(new String(new BASE64Decoder().decodeBuffer(pass)));
			driver.findElement(By.name("username")).submit();

			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			/***
			 * TODO Q - When is it navigating to Orders page ? Locate 1st order
			 * from the list and then click on it's ClOrdId
			 */
			WebElement firstrow2 = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			firstrow2.click();
			// firstrow.sendKeys(Keys.chord(Keys.CONTROL, "a"));

			/***
			 * TODO Q - Why is "CTRL + A" action performed here?
			 */
			Actions actionObj2 = new Actions(driver);
			actionObj2.keyDown(Keys.CONTROL).sendKeys(Keys.chord("A")).keyUp(Keys.CONTROL).perform();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e2) {
				e2.printStackTrace();
			}

			WebElement firstrow3 = new WebDriverWait(driver, 30).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]")));

			Actions actionObj3 = new Actions(driver);
			actionObj3.contextClick(firstrow3).sendKeys(Keys.RETURN).build().perform();

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			WebElement forceCancel = driver.findElement(By.xpath("//*[@id='forceCancel']"));
			forceCancel.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			driver.switchTo().alert().accept();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			WebElement firstrow4 = new WebDriverWait(driver, 30).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]")));

			Actions actionObj4 = new Actions(driver);
			actionObj4.contextClick(firstrow4).sendKeys(Keys.RETURN).build().perform();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			WebElement archive = driver.findElement(By.xpath("//*[@id='archive']"));
			archive.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			driver.switchTo().alert().accept();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			Reporter.log("Orders are archieved", true);
			// driver.close();
		} catch (Exception e) {

			System.out.println("Order Archive Failed due to an unknown exception : " + e);
			System.out.println("!!!!!!!!!!Unknown exception Page!!!!!!!!!!");
			// driver.close();
		}
	}

	@AfterTest
	public void CloseBrowser() {
		driver.close();
		driver.quit();
	}

//	public static void main(String[] args) throws IOException {
//		BASE64Encoder base64Encoder = new BASE64Encoder();
//		String encode = base64Encoder.encode("".getBytes());
//		System.out.println(encode);
//
//		String decode = new String(new BASE64Decoder().decodeBuffer("TXVtYmFpTWF5QDIx"));
//		System.out.println(decode);
//
//	}

}
