package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.testng.*;
import org.testng.annotations.*;

public class KillOrderCase
{
	WebDriver driver = null; // Selects appropraite driver
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickKill(String user, String pass, String monEnv, String browser)
	{
		
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			
			// System.out.println(
			// "My username is " + user + "My password is " + pass + "monitoring Env" + monEnv + "browser" + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			
			// kill
			Actions action1 = new Actions(driver);
			WebElement webElement6 = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			action1.contextClick(webElement6).sendKeys(Keys.RETURN).build().perform();
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			WebElement archieve = driver.findElement(By.xpath("//*[@id='archive']"));
			archieve.click();
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			driver.switchTo().alert().accept();
			System.out.println("killed Successful : Passed");
			
 		driver.close();
			// driver.quit();
		}
		catch(Exception e)
		{
			Reporter.log("Test Case for Right click > Archieve has failed due to an exception ", true);
			driver.close();
			Assert.fail("Selenium Error : Archieve check Failed!!!!!!!!!!!!!!!!!!!");
			System.out.println("Archeive check : Failed due to an unknown exception : " + e);
			System.out.println("!!!!!!!!!!Unknown exception Page!!!!!!!!");
//			driver.close();
		}
	}

}
