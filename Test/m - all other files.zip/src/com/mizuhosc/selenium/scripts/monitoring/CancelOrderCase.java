package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class CancelOrderCase
{
	String clickCancelStatus;
	
	WebDriver driver = null; // Selects appropraite driver
	
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickCancel(String user, String pass, String monEnv, String browser)
	{
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + "monitoring Env" + monEnv + "browser" + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			@SuppressWarnings("unused")
			WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(), '20:36:56')]")));
			WebElement webElement4 = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			Actions action1 = new Actions(driver);
			action1.contextClick(webElement4).sendKeys(Keys.RETURN).build().perform();
			WebElement cancel = driver.findElement(By.xpath("//*[@id='cancel']"));
			cancel.click();
			driver.switchTo().alert().accept();
			System.out.println("cancel Successful");
			try
			{
				Thread.sleep(6000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			clickCancelStatus = driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']//tr[1]//td[6]")).getText();
			System.out.println("Value fetched Cancel: " + clickCancelStatus);
			
			if(clickCancelStatus != null && "CANCELLED".equals(clickCancelStatus))
			{
				System.out.println("Cancelled check : Passed");
				// Reporter.log("Order is successfully " + clickCancelStatus, true);
				Reporter
					.log("Test Case for cancelled has Passed : It has fetched the value : " + clickCancelStatus, true);
				// Assert.fail("Case functionality Error : Expected : \"CANCELLED\" !!!!!!!!!!!!!!!!!!!");
 			driver.close();
				
			}
			else
			{
				// Reporter.log("Order is successfully " + clickCancelStatus, false);
				// Assert.fail("Selenium Error : Cancel Order Case Fail!!!!");
				Reporter.log(
					"Test Case for Right click > Cancel has Failed : It has fetched the value : " + clickCancelStatus,
					true);
				driver.close();
				Assert.fail("Case functionality Error : Expected : \"CANCELLED\" !!!!!!!!!!!!!!!!!!!");
				System.out.println("Cancelled functionality check : Failed");
			
				
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			Reporter.log(
				"Test Case for Right click > Cancel has failed due to an exception : It has fetched the value : "
					+ clickCancelStatus,
				true);
			driver.close();
			Assert.fail("Selenium Error : Cancel check Failed due to an unknown exception!!!!!!!!!!!!!!!!!!!" + e);
			System.out.println("Cancel check : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!");
 			
		}
	}
	
}
