package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class ResumeDFD
{
	String clickResumeDfdStatus;
	WebDriver driver = null; // Selects appropraite driver
	
	@SuppressWarnings({"unused"})
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickResumeDfd(String user, String pass, String monEnv, String browser)
	{
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + "monitoring Env" + monEnv + "browser" + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			WebElement waitForStatus =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'20:35:18')]")));
			// Resume DFD
			WebElement webElement3 = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			Actions action1 = new Actions(driver);
			action1.contextClick(webElement3).sendKeys(Keys.RETURN).build().perform();
			WebElement resumeDFD = driver.findElement(By.xpath("//*[@id='resumeDFD']"));
			resumeDFD.click();
			driver.switchTo().alert().accept();
			System.out.println("resumeDFD Successful");
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			clickResumeDfdStatus = driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']//tr[1]//td[6]")).getText();
			System.out.println("Value fetched Resume DFD: " + clickResumeDfdStatus);
			if(clickResumeDfdStatus != null && "DFD RESUMED".equals(clickResumeDfdStatus))
			{
				Reporter.log(
					"Test Case for Right click > Resume DFD has Passed : It has fetched the value : \""
						+ clickResumeDfdStatus + "\"",
					true);
				System.out.println("DFD Resumed check : Passed");
 			driver.close();
				// driver.quit();
				
			}
			else
			{
				Reporter.log(
					"Test Case for Right click > Resume DFD has Failed : It has fetched the value : \""
						+ clickResumeDfdStatus + "\"",
					true);
				driver.close();
				Assert.fail("Case functionality Error : Expected : \"DFD RESUMED\" !!!!!!!!!!!!!!!!!!!");
				System.out.println("DFD Resumed : Failed");
//				driver.close();
				// driver.quit();
			}
		}
		catch(Exception e)
		{
			Reporter.log(
				"Test Case for Right click > Resume DFD has failed due to an exception : It has fetched the value : \""
					+ clickResumeDfdStatus + "\"",
				true);
			driver.close();
			Assert.fail("Selenium Error : Resume DFD check Failed!!!!!!!!!!!!!!!!!!!");
			System.out.println("Resume DFD check : Failed due to an unknown exception : " + e);
			System.out.println("!!!!!!!!!!Unknown exception Page!!!!!!!!");
//			driver.close();
			
		}
	}
	
}
