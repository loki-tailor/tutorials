package com.mizuhosc.selenium.scripts.monitoring;

import java.awt.*;
import java.awt.datatransfer.*;
import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class CreateSyntheticSpread
{
	private WebDriver driver;
	private final ChromeOptions options = new ChromeOptions();
	
	@SuppressWarnings("unused")
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void performSynSpread(final String user, final String pass, final String monEnv, final String browser)
		throws AWTException
	{
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			Thread.sleep(2000);// adding wait of 2 Seconds for Marathon to start playback.
			// Selects appropriate browser as declared by user in global declaration
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))// Internet Explorer Driver
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			final Actions seleniumAction = new Actions(driver);
			
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.id("signin")).submit();
			
			final WebDriverWait thirtySecondWait = new WebDriverWait(driver, 30);
			final WebElement waitForStatus = thirtySecondWait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'GS_14967264230')]")));
			Reporter.log("User can see Monitoring Screen", true);
			final String monitoringScreen = driver.getWindowHandle();
			
			// Click on the top most order and open pop-up window to Match Spread
			seleniumAction.moveToElement(driver.findElement(By.xpath("//*[contains(text(),'GS_14967264230')]")))
				.doubleClick()
				.build().perform();
			
			Reporter.log("Double clicked to open Order Executions screen", true);
			for(final String currentWindow: driver.getWindowHandles())
			{
				if(!monitoringScreen.equals(currentWindow))
				{
					Reporter.log(String.format("Performing Operation on Execution Screen"), true);
					driver.switchTo().window(currentWindow);
					Reporter.log("Opened new Tab for Leg Orders", true);
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='q-render-table-potential-spread-matches-table']/tbody/tr/td[11]/q-button")))
						.click();
					thirtySecondWait.until(ExpectedConditions.alertIsPresent()).accept();
					Reporter.log("Step 1 : Synthetic Spread created successfully", true);
					driver.close();// closing execution window
				}
			}
			
			Reporter.log("Switched to Monitoring GUI.", true);
			driver.switchTo().window(monitoringScreen);
			
			// Double click on Synthetic Spread order to Match Amend
			final WebElement syntheticOrder = thirtySecondWait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'14:22:33')]")));
			final Actions action = new Actions(driver);
			action.doubleClick(syntheticOrder).perform();
			
			Reporter.log("Double clicked to open Executions screen", true);
			
			for(final String currentWindow: driver.getWindowHandles())
			{
				if(!currentWindow.equals(monitoringScreen))
				{
					driver.switchTo().window(currentWindow);
					Reporter.log("Opened new tab of Synthetic Spread Order", true);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='tabs-bar']/ul/li[2]/a/span"))).click();
					
					driver.findElement(By.xpath("//*[@id='edit-executions-list']/span")).click();
					Reporter.log("Adding Manual fill for Synthetic Spread Order", true);
					
				
					// Partially Fill from Quattro
					final WebElement webElement =
						thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[@id='spread-near-leg']/tbody/tr[2]/td[2]/input")));
					webElement.clear();
					webElement.click();
					webElement.sendKeys("1");
					Thread.sleep(500);
					webElement.click();
					webElement.sendKeys(Keys.TAB);

					final WebElement webElement1 =
						thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[@id='spread-near-leg']/tbody/tr[2]/td[3]/input")));
					webElement1.clear();
					webElement1.click();
					webElement1.sendKeys("1");
					Thread.sleep(1000);
					webElement1.click();
					webElement1.sendKeys(Keys.TAB);
					
					final WebElement webElement2 =
						thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[@id='spread-far-leg']/tbody/tr[2]/td[2]/input")));
					webElement2.clear();
					webElement2.click();
					webElement2.sendKeys("1");
					Thread.sleep(500);
					webElement2.click();
					webElement2.sendKeys(Keys.TAB);
					
					final WebElement webElement3 =
						thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[@id='spread-far-leg']/tbody/tr[2]/td[3]/input")));
					webElement3.clear();
					webElement3.click();
					webElement3.sendKeys("1");
					Thread.sleep(1000);
					webElement3.click();
//        			webElement3.sendKeys(Keys.TAB);
					
//					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
//						By.xpath("//*[@id='save-execution']"))).click();// Save button is clicked
					driver.manage().window().maximize();
					Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@id='save-execution']")).click();
					Reporter.log("Clicked on save button for Manual Fill.", true);
					thirtySecondWait.until(ExpectedConditions.alertIsPresent()).accept();
					Reporter.log("Step 2 : Partial Fill values sent manually, "
						+ "now checking execution status after manual fill.", true);
					Thread.sleep(3000);
					// Order Screen
					final String firstExecutionStatus =
						thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[@id='order-details']/table/tbody/tr[5]/td[4]")))
							.getText();
					
					Reporter.log(String.format("Execution Status: %s", firstExecutionStatus), true);
					
					if(firstExecutionStatus != null && !"partially filled to 2".equals(firstExecutionStatus))
					{
						Reporter.log(String.format("Execution Status is %s, which is unexpected", firstExecutionStatus),
							true);
						Assert.fail("Execution Status not matched with \"partially filled to 2\" failed!!!");
					}
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='edit-executions-list']/span"))).click();
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='uploadExecution']"))).click();
					Reporter.log("Clicked on uplodad Executions radio button", true);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='upload-execution-form']/div[2]/textarea"))).click();
					Reporter.log("Selected text area to paste executions", true);
					
					final Robot robotFirst = new Robot();
					final StringSelection firstUploadExecutions =
						new StringSelection(
							"203701	1	1.0	2.0	OSE"
								+ "\n"
								+ "203702	1	1.0	2.0	OSE"
								+ "\n"
								+ "203703	1	1.0	2.0	OSE"
								+ "\n"
								+ "203704	1	1.0	2.0	OSE"
								+ "\n"
								+ "203704	1	1.0	2.0	OSE"
								+ "\n");
					Toolkit.getDefaultToolkit().getSystemClipboard().setContents(firstUploadExecutions, null);
					robotFirst.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
					robotFirst.keyPress(java.awt.event.KeyEvent.VK_V);
					robotFirst.keyRelease(java.awt.event.KeyEvent.VK_V);
					robotFirst.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
					Reporter.log("Pasted Executions in text area.", true);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='upload-execution-button']"))).click();
					Reporter.log("Clicked on Preview Executions to check Uploaded executions.", true);
					
					// added this for workaround to trigger change event					
					Thread.sleep(500);
															
					final WebElement saveAllButton = thirtySecondWait
						.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='save-execution']")));
					saveAllButton.click();
					
					thirtySecondWait.until(ExpectedConditions.alertIsPresent()).accept();
					Reporter.log("Selenium user clicked on Save All button", true);
					Reporter.log("Step 3 : Multiple executions sent, now checking execution"
						+ " status after manual fill.", true);
					Thread.sleep(3000);
					
					final String secondExecutionStatus =
						thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
								By.xpath("//*[@id='order-details']/table/tbody/tr[5]/td[4]"))).getText();
					
					Reporter.log(String.format("Execution Status: %s", secondExecutionStatus), true);
					if(secondExecutionStatus != null && !"partially filled to 7".equals(secondExecutionStatus))
					{
						Reporter.log(
							String.format("Execution Status is '%s', which is unexpected", secondExecutionStatus),
							true);
					}
					Thread.sleep(1000);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//ul[@class='tabs']/li[1]/a/span"))).click();
					Reporter.log("Clicked on Event & Messages Tab", true);
					Thread.sleep(3000);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='match-amend-button']"))).click();
					Thread.sleep(1000);
					
					thirtySecondWait.until(ExpectedConditions.alertIsPresent()).accept();
					Reporter.log("Step 4-a : Matched Amend for Synthetic Spread Order.", true);
					Thread.sleep(3000);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='reject-amend-button']"))).click();
					Reporter.log("Step 4-b : Rejected Amend for Synthetic Spread Order.", true);
					Thread.sleep(3000);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='tabs-bar']/ul/li[2]/a/span"))).click();
					Reporter.log("Clicked on Executions Tab", true);
					Thread.sleep(2000);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@class='view']/a"))).click();
					Reporter.log("Clicked on Add button", true);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='uploadExecution']"))).click();
					Reporter.log("Clicked on Multiple Executions radio button.", true);
					Thread.sleep(2000);
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='upload-execution-form']/div[2]/textarea"))).click();
					Reporter.log("Clicked on text area to paste the executions.", true);
					final Robot robotSecond = new Robot();
										
					final StringSelection secondUploadExecutions =
						new StringSelection(
							"203701	1	1.0	2.0	OSE"
								+ "\n"
								+ "203702	1	1.0	2.0	OSE"
								+ "\n"
								+ "203703	1	1.0	2.0	OSE"
								+ "\n"
								+ "203704	1	1.0	2.0	OSE"
								+ "\n"
								+ "203704	1	1.0	2.0	OSE"
								+ "\n");
					
					Toolkit.getDefaultToolkit().getSystemClipboard().setContents(secondUploadExecutions, null);
					
					robotSecond.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
					robotSecond.keyPress(java.awt.event.KeyEvent.VK_V);
					robotSecond.keyRelease(java.awt.event.KeyEvent.VK_V);
					robotSecond.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
					Reporter.log("Pasted executions to upload.", true); // button
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='upload-execution-button']"))).click();
					Reporter.log("Clicked on Preview Executions to check Uploaded executions.", true); // button
					
					// added this for workaround to trigger change event
					Thread.sleep(500);
					
					thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//*[@id='save-execution']"))).click();
					
					thirtySecondWait.until(ExpectedConditions.alertIsPresent()).accept();
					Reporter.log("Clicked on Send All button.", true);
					Reporter.log("Step 5 : Multiple executions sent,and checking Execution Status.", true);
					Thread.sleep(3000);
					final String thirdExecutionStatus =
						thirtySecondWait.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath("//*[@id='order-details']/table/tbody/tr[5]/td[4]"))).getText();
					
					Reporter.log(String.format("Execution Status: %s", thirdExecutionStatus), true);
					
					if(thirdExecutionStatus != null && !"partially filled to 12".equals(thirdExecutionStatus))
					{
						Reporter.log(
							String.format("Execution Status is '%s', which is unexpected", thirdExecutionStatus), true);
					}
					driver.close();// closing execution window
					break;
				}
			}
			Reporter.log("Switched to Monitoring GUI.", true);
			driver.switchTo().window(monitoringScreen);
				Reporter.log("Waiting 30 seconds for Marathon test case to be finished.", true);
				Thread.sleep(30000);
		}
		catch(final Exception e)
		{
			Reporter.log(
				String.format("Test Case for Synthetic Spread has failed due to an exception: %s", e.getMessage()),
				true);
			closeAllBrowser();
			Assert.fail(
				String.format("Test Case for Synthetic Spread has failed due to an exception: %s", e.getMessage()));
			
		}
		closeAllBrowser();// closing monitoring window
	}
	
	private void closeAllBrowser()
	{
		for(final String currentWindow: driver.getWindowHandles())
		{
			driver.switchTo().window(currentWindow);
			driver.close();
		}
	}
}
