package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import java.util.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class ForceDequeueCheck
{
	String testResult;
	WebDriver driver = null; // Selects appropraite driver
	
	@SuppressWarnings("unused")
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickDequeue(String user, String pass, String monEnv, String browser)
	{
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			
			WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'19:33:26')]")));// 20:21:28
			// ForceDequeue
			WebElement webElement = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			String fetchID = webElement.getText();
			Actions dequeueAction = new Actions(driver);
			dequeueAction.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			WebElement dequeue = driver.findElement(By.xpath("//*[@id='forceDequeue']")); // This will select menu after
																						// right
																						// click
			dequeue.click();
			
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
			driver.switchTo().alert().accept();
			System.out.println("Dequeued Successful");
			
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			String homePage = driver.getWindowHandle();
			System.out.println(homePage);
			Actions action1 = new Actions(driver);
			
			// #### Click on the top most order and open pop-up window to Match Spread
			action1
				.moveToElement(driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]")))
				.doubleClick()
				.build()
				.perform();
			
			System.out.print("New window of Latest Order opens");
			// Checking no. of windows openned by web driver
			Set<String> allWindows = driver.getWindowHandles();
			System.out.println("Number of Windows active = ");
			System.out.println(allWindows.size());
			Iterator<String> iterator = allWindows.iterator();
			String currentWindows = driver.getWindowHandle();
			while(iterator.hasNext())// Working with another tab
			{
				currentWindows = iterator.next().toString();
				System.out.println(currentWindows);
				if(!currentWindows.equals(homePage))
				{
					driver.switchTo().window(currentWindows);
					
					// STEP 1 : New order new tab
					System.out.println(" We are in new Tab : for Force Dequeue CASE");
					
					// driver.findElement(By.xpath("/html/body/div[5]/ul/li[3]/a/span")).click();// Syn Spread Tab
					try
					{
						Thread.sleep(3000);
					}
					catch(InterruptedException e)
					{
						e.printStackTrace();
					}
					
					// Verify the order status turns to "Done for Day" on monitoring screen
					WebElement clickDequeueStatus =
						driver.findElement(
							By.xpath("//*[@id='q-render-table-events-and-messages-table']/tbody/tr[3]/td[4]/span"));
					System.out.println("Value fetched post Dequeue: " + clickDequeueStatus.getText());
					testResult = clickDequeueStatus.getText();
					
					if(clickDequeueStatus.getText() != null && "DEQUEUING".equals(clickDequeueStatus.getText()))
					{
						Reporter.log(
							"Test Case for force Dequeuing has passed : It has fetched the value : " + testResult,
							true);
						System.out.println("Force Dequeue Functionality check : Passed");
						try
						{
							Thread.sleep(5000);
						}
						catch(InterruptedException e2)
						{
							e2.printStackTrace();
						}
 						driver.quit();
						
					}
					else
					{
						Reporter.log(
							"Test Case for Force Dequeue has Failed : It has fetched the value : " + testResult,
							true);
						driver.close();
						Assert.fail("Case functionality Error : Expected : \"DEQUEUING\" !!!!!!!!!!!!!!!!!!!");
//						driver.close();
					}
				}
			}
			
		}
		catch(Exception e)
		{
			Reporter.log(
				"Test Case for Force Dequeue has Failed due to an exception : It has fetched the value : " + testResult,
				false);
			driver.close();
			Assert.fail("Selenium Error : Force Dequeue check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Force Dequeue check : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
//			driver.close();
			
		}
	}
	 
}
