package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class UndfdCase
{
	WebDriver driver = null; // Selects appropraite driver
	String clickUndfdStatus;
	
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickUndfd(String user, String pass, String monEnv, String browser)
	{
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + "monitoring Env" + monEnv + "browser" + browser);
			
			// WebDriver driver = null; // Selects appropraite driver
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			@SuppressWarnings("unused")
			WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'20:25:06')]")));
			// dfd
			WebElement webElement1 = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			Actions action1 = new Actions(driver);
			action1.contextClick(webElement1).sendKeys(Keys.RETURN).build().perform();
			WebElement unDfd = driver.findElement(By.xpath("//*[@id='unDfd']"));
			unDfd.click();
			driver.switchTo().alert().accept();
			System.out.println("unDFD Sucessful");
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			clickUndfdStatus = driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']//tr[1]//td[6]")).getText();
			System.out.println("Value fetched unDFD: " + clickUndfdStatus);
			if(clickUndfdStatus != null && "UN DONE FOR DAY".equals(clickUndfdStatus))
			{
				Reporter.log("Test Case for unDFD has passed : It has fetched the value : " + clickUndfdStatus, true);
				System.out.println("Undfd check functionality : Passed");
 			driver.close();
				
			}
			else
			{
				Reporter.log("Test Case for unDFD has Failed : It has fetched the value : " + clickUndfdStatus, true);
				driver.close();
				Assert.fail("Case functionality Error : Expected : \"UN DONE FOR DAY\" !!!!!!!!!!!!!!!!!!!");
				System.out.println("Undfd check : Functionality Failed");
 			
				
			}
			
		}
		catch(Exception e)
		{
			Reporter.log(
				"Test Case for unDFD has Failed due to an exception : It has fetched the value : " + clickUndfdStatus,
				true);
			driver.close();
			Assert.fail("Selenium Error : unDFD check Failed!!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("UnDfd check : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!");
//			driver.close();
		}
		
	}
	 
	
}
