package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class DfdCase
{
	String testResult;
	
	WebDriver driver = null; // Selects appropraite driver
	
	String drivername="";
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickDfd(String user, String pass, String monEnv, String browser)
	{
		
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		
		try
		{
			// System.out.println("My username is " + user + ", monitoring Env " + monEnv + ", browser " + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			 
			
			@SuppressWarnings("unused")
			WebElement waitForOrder =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'20:21:28')]")));// 20:21:28.
			// dfd
			WebElement webElement = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			Actions dfdAction = new Actions(driver);
			dfdAction.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			WebElement dfd = driver.findElement(By.xpath("//*[@id='dfd']")); // This will select menu after right click
			// check for wait in above line
			dfd.click();// uncomment to pass
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
			driver.switchTo().alert().accept();
			System.out.println("DFD Successful");
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
			// Verify the order status turns to "Done for Day" on monitoring screen
			WebElement clickDfdStatus = driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']/tbody/tr/td[6]"));
			System.out.println("Value fetched : DFD: " + clickDfdStatus.getText());
			testResult = clickDfdStatus.getText();
			if(clickDfdStatus.getText() != null && "DONE FOR DAY".equals(clickDfdStatus.getText()))
			{
				Reporter.log("Test Case for DFD has passed : It has fetched the value : " + testResult, true);
				System.out.println("Dfd Functionality check : Passed");
				try
				{
					Thread.sleep(5000);
				}
				catch(InterruptedException e2)
				{
					e2.printStackTrace();
				}
    		driver.close();
				// driver.quit();
				
			}
			else
			{
				Reporter.log("Test Case for DFD has Failed : It has fetched the value : " + testResult, true);
        		driver.close();
				 driver.getTitle();
				Assert.fail("Case functionality Error : Expected : \"DONE FOR DAY\" !!!!!!!!!!!!!!!!!!!");
				String abc=driver.getTitle();
				System.out.println(abc+"title2");	
			}
			
		}
		catch(Exception e)
		{
			Reporter.log(
				"Test Case for DFD has Failed due to an exception : It has fetched the value : " + testResult,
				false);
			 driver.getTitle();
     		 driver.close();
			Assert.fail("Selenium Error : DFD check Failed due to an exception !!!!!!!!!!!!!!!!!!! " + e);
			System.out.println("Dfd check : Failed due to an exception : " + e);
			System.out.println("!!!!!!!!!!!Unknown exception Page!!!!!!!!!!!");
 	       
			
			// driver.quit();
		}
		
	}


}
	
	
 
