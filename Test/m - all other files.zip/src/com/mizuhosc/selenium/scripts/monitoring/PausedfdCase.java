package com.mizuhosc.selenium.scripts.monitoring;

import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class PausedfdCase
{
	String clickPauseDfdStatus;
	WebDriver driver = null; // Selects appropraite driver
	
	@SuppressWarnings({"unused"})
	@Parameters({"username", "password", "quattroEnv", "browser"})
	@Test
	public void clickPausedDFD(final String user, final String pass, final String monEnv, final String browser)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			// System.out.println("My username is " + user + "monitoring Env" + monEnv + "browser" + browser);
			
			if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			// Log into Monitoring screen
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			// Waiting for the order from Marathon
			final WebElement waitForStatus =
				new WebDriverWait(driver, 30)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'20:32:53')]")));
			final WebElement webElement2 = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
			final Actions action1 = new Actions(driver);
			action1.contextClick(webElement2).sendKeys(Keys.RETURN).build().perform();
			final WebElement pauseDFD = driver.findElement(By.xpath("//*[@id='pauseDFD']"));
			pauseDFD.click();
			try
			{
				Thread.sleep(3000);
			}
			catch(final InterruptedException e1)
			{
				e1.printStackTrace();
			}
			driver.switchTo().alert().accept();
			System.out.println("pauseDFD Sucessful");
			try
			{
				Thread.sleep(5000);
			}
			catch(final InterruptedException e1)
			{
				e1.printStackTrace();
			}
			clickPauseDfdStatus =
				driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']//tr[1]//td[6]")).getText();
			System.out.println("Value fetched Pause DFD: " + clickPauseDfdStatus);
			if(clickPauseDfdStatus != null && "DFD PAUSED".equals(clickPauseDfdStatus))
			{
				Reporter.log(
					"Test Case for Right click > Pause DFD has Passed : It has fetched the value : \""
						+ clickPauseDfdStatus
						+ "\"",
					true);
				System.out.println("DFD Paused check : Passed");
				driver.close();
				// driver.quit();
			}
			else
			{
				Reporter.log(
					"Test Case for Right click > Pause DFD has Failed : It has fetched the value : \""
						+ clickPauseDfdStatus
						+ "\"",
					true);
				driver.close();
				Assert.fail("Case functionality Error : Expected : \"DFD PAUSED\" !!!!!!!!!!!!!!!!!!!");
				System.out.println("DFD Paused check : Failed");
				
				// driver.quit();
			}
		}
		catch(final Exception e)
		{
			Reporter.log(
				"Test Case for Right click > Pause DFD has failed due to an exception : It has fetched the value : \""
					+ clickPauseDfdStatus
					+ "\"",
				true);
			driver.close();
			Assert.fail("Selenium Error : Pause DFD check Failed!!!!!!!!!!!!!!!!!!!");
			System.out.println("Pause DFD check : Failed due to an unknown exception : " + e);
			System.out.println("!!!!!!!!!!Unknown exception Page!!!!!!!!");
//			driver.close();
		}
	}
	
}
