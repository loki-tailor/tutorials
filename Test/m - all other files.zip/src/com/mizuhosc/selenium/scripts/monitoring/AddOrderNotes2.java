// Author: Sankalp Jain
// Creation Date : 2019-01-21
// JIRA : SEL-95

package com.mizuhosc.selenium.scripts.monitoring;

import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.NoSuchElementException;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;
import com.mizuhosc.selenium.functionlibraries.*;

public class AddOrderNotes2
{
	
	WebDriver driver = null;
	private static String ActionResult ="";
	
	@Parameters({"username", "password", "quattroEnv", "browser", "ClOrderID", "ViewName"})
	@Test
	public void addOrderNotes(final String user, final String pass, final String monEnv, final String browser, final String ClOrderID, final String ViewName)
	{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		
		try
		{
			// Selects appropriate browser as declared by user in global declaration
			
			
if(browser.equals("Mozilla"))
			{
				driver = new FirefoxDriver();
			}
			else if(browser.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			else if(browser.equals("IE"))// Internet Explorer Driver
			{
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.id("signin")).submit();
		
			//Thread.sleep(2000);
			// Checking if addOrderNotes in rightclick menu is available
			ActionResult=CommonFunctions.RighClickActionMonitoringGUI(user, pass, monEnv,ClOrderID,"addOrderNotes", driver, "FALSE");
			// Assert fail if RightClick Menu addOrderNotes is not available
			CommonFunctions.ReportPositiveResult("RightClick on addOrderNotes available",ActionResult);
		    // addOrderNotes text Box if RighClick is successful
			//ActionResult=CommonFunctions.RighClickActionMonitoringGUI(user, pass, monEnv,ClOrderID, "addOrderNotes", driver, "FALSE");
			CommonFunctions.addOrderNotes("Adding order notes for test1", monEnv, driver, "FALSE");
			//driver.quit();
			// Right Click order and forceDequeue
		    ActionResult=CommonFunctions.RighClickActionMonitoringGUI(user, pass, monEnv,ClOrderID, "forceDequeue", driver, "FALSE");
			// Assert fail if RightClick Menu forceDequeue not available
			//Accept the popup if you would like to dequeue the orders
		    driver.switchTo().alert().accept();
		   // CommonFunctions.ReportPositiveResult ("RightClick on forceDequeue available",ActionResult);
		    //Check if the OrderStatus is Active or not
		    ActionResult=CommonFunctions.CheckViewFirstColumnByClOrderId(user,pass,monEnv,ViewName,ClOrderID,"ACTIVE", driver, "FALSE");
			CommonFunctions.ReportPositiveResult ("Check Order Status after Dequeue",ActionResult);
			// Checking if addOrderNotes in rightclick menu is available
			ActionResult=CommonFunctions.RighClickActionMonitoringGUI(user, pass, monEnv,ClOrderID, "addOrderNotes", driver, "FALSE");
			CommonFunctions.ReportNegativeResult ("RightClick on addOrderNotes Not Available",ActionResult);
		    //Boolean orderStatusResult=CommonFunctions.CheckOrderStatus(ClOrderID,"ACTIVE",driver);
			Thread.sleep(1000);
					
			driver.quit();
									
		}
		catch(final Exception e)
		{
		    Reporter.log(String.format("[%s Exception] Case could not be checked properly due to an exception thrown by Browser i.e. ",CommonFunctions.getTimeStamp()),true);
			Assert.fail("Exception details are  " + e.getMessage());
			driver.quit();
			
		}
	}

	
}
