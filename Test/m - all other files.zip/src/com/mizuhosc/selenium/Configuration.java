package com.mizuhosc.selenium;

import com.mizuhosc.selenium.log.*;
import java.io.*;
import java.sql.*;
import java.util.*;


public class Configuration {
	public static Configuration SINGLETON = new Configuration();

	private final Properties _properties;

	private Configuration() {
		_properties = new Properties();

		final String filePath = new ConfigFile("qbot.properties").getPath().toString();
		try (final FileInputStream fis = new FileInputStream(filePath)) {
			_properties.load(fis);
		} catch (final Exception e) {
			Log.error(e, "Failed to load property file qbot.properties");
		}
	}

	public String getProperty(final String key) {
		return _properties.getProperty(key);
	}

	public List<String> getValues(final String key) {
		final String configValue = getProperty(key);
		final List<String> result = new LinkedList<>();
		if (configValue == null) {
			return result;
		}
		for (final String s : configValue.split(",")) {
			final String trimmed = s.trim();
			if (!trimmed.isEmpty()) {
				result.add(trimmed);
			}
		}
		return result;
	}

	public Connection createConnection(final String db) throws SQLException {
		final Properties p = new Properties();
		p.put("user", Configuration.SINGLETON.getProperty(String.format("db.%s.username", db)));
		p.put("password", Configuration.SINGLETON.getProperty(String.format("db.%s.password", db)));
		final String url = String.format("db.%s.url", db);
		return DriverManager.getConnection(Configuration.SINGLETON.getProperty(url), p);
	}

	// public static void main(String[] args) {
	// System.out.println(Configuration.SINGLETON.getProperty("db.OSPREY_DB.url"));
	// }

}
