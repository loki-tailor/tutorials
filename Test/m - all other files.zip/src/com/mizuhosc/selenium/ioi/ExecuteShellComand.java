package com.mizuhosc.selenium.ioi;

import java.io.*;

public class ExecuteShellComand
{
	public static void main(final String[] args)
	{
		final ExecuteShellComand obj = new ExecuteShellComand();

		//in windows
		final String command = "ping -n 3 localhost";

		final String output = obj.executeCommand(command);

		System.out.println(output);
	}

	public String executeCommand(final String command)
	{
		final StringBuffer output = new StringBuffer();

		Process p;
		try
		{
			p = Runtime.getRuntime().exec(command);
			p.waitFor();
			final BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));

			String line = "";
			while((line = reader.readLine()) != null)
			{
				output.append(line + "\n");
			}

		} catch (final Exception e) {
			e.printStackTrace();
		}

		return output.toString();
	}

}