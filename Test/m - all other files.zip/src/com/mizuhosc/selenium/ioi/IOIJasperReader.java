package com.mizuhosc.selenium.ioi;

import com.mizuhosc.quattro.util.*;
import com.mizuhosc.selenium.log.*;
import java.io.*;
import java.util.*;
import javax.annotation.*;

public class IOIJasperReader
{
	public Map<IOIIDWithVersion, List<String>> read(final String fileName)
		throws FileNotFoundException,
		IOException,
		MessagingException
	{
		Log.info("Reading file %s ...", fileName);
		
		final Map<IOIIDWithVersion, List<String>> ioiMessages = new LinkedHashMap<>();
		try(final BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName))))
		{
			while(true)
			{
				final String line = reader.readLine();
				if(line == null)
				{
					break;
				}
				
				final Map<IOIIDWithVersion, List<String>> oneLineMessage = parse(line);
				oneLineMessage.forEach((key, value) -> ioiMessages.merge(key, value, (v1, v2) ->
				{
					v1.addAll(v2);
					return v1;
				}));
			}
		}
		
		Log.info("Finished reading file %s with %d records", fileName, ioiMessages.size());
		
		return ioiMessages;
	}
	
	static Map<IOIIDWithVersion, List<String>> parse(final String line) throws MessagingException
	{
		final MessageMap message = MessageMap.parseString(line);
		final MessageMap ioiStatusMap = message.getMap("IOIStatus");
		
		final String ioiID = ioiStatusMap.getString("IOI_ID");
		final int ioiVersion = ioiStatusMap.getInt("IOI_VERSION");
		
		final List<String> clientIOIIDs = new ArrayList<>();
		final @Nullable MessageMap clientIOIDetailsMap = ioiStatusMap.getMap("CLIENT_IOI_DETAILS");
		
		for(int i = 0; clientIOIDetailsMap != null && i < clientIOIDetailsMap.size(); i++)
		{
			final MessageMap map = clientIOIDetailsMap.getMap(String.valueOf(i));
			final String clientIOIID = map.getString("CLIENT_IOI_ID");
			clientIOIIDs.add(clientIOIID);
		}
		
		final Map<IOIIDWithVersion, List<String>> result = new LinkedHashMap<>();
		result.put(new IOIIDWithVersion(ioiID, ioiVersion), clientIOIIDs);
		
		return result;
	}
	
	public static void main(final String[] args) throws FileNotFoundException, IOException, MessagingException
	{
		final Map<IOIIDWithVersion, List<String>> map =
			new IOIJasperReader().read("ioi.IOIService.adoa65550e.topflagship.mizuho-sc.com.2018-02-20.jasper");
		System.out.println(map);
	}
}
