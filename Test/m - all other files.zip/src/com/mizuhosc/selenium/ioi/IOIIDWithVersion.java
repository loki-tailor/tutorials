package com.mizuhosc.selenium.ioi;

import com.willhains.equality.*;
import javax.annotation.*;

public class IOIIDWithVersion
{
	public final String ioiID;
	public final int ioiVersion;
	
	private static final Equality<IOIIDWithVersion> _EQ = Equality.ofProperties($ -> $.ioiID, $ -> $.ioiVersion);
	
	public IOIIDWithVersion(final String ioiID, final int ioiVersion)
	{
		this.ioiID = ioiID;
		this.ioiVersion = ioiVersion;
	}
	
	public IOIIDWithVersion previousVersion()
	{
		return new IOIIDWithVersion(ioiID, ioiVersion - 1);
	}
	
	@Override
	public boolean equals(final @Nullable Object other)
	{
		return _EQ.compare(this, other);
	}
	
	@Override
	public int hashCode()
	{
		return _EQ.hash(this);
	}
	
	@Override
	public String toString()
	{
		return _EQ.format(this);
	}
}
