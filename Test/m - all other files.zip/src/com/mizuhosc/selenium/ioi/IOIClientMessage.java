package com.mizuhosc.selenium.ioi;

public class IOIClientMessage
{
	public final String ioiID;
	public final String ioiRefID;
	public final String clientIOIID;
	public final String ioiType;
	
	public IOIClientMessage(final String ioiID, final String ioiRefID, final String clientIOIID, final String ioiType)
	{
		this.ioiID = ioiID;
		this.ioiRefID = ioiRefID;
		this.clientIOIID = clientIOIID;
		this.ioiType = ioiType;
	}
}
