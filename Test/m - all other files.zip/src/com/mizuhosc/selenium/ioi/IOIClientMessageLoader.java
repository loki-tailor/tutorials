package com.mizuhosc.selenium.ioi;

import com.mizuhosc.quattro.util.*;
import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.*;
import java.sql.*;

public class IOIClientMessageLoader
{
	public FixedMap<String, IOIIDWithVersion> loadIOIIDs() throws SQLException
	{
		final String sql = SQLBuilder
			.empty()
			.append("select distinct Id, IoiId, IoiVersion from IoiSession")
			.getSQL();
		
		return FixedMap.build(map ->
		{
			try(final Connection gorConnection = Configuration.SINGLETON.createConnection("OSPREY_DB");
				final PreparedStatement query = gorConnection.prepareStatement(sql);)
			{
				try(final ResultSet rs = query.executeQuery();)
				{
					while(rs.next())
					{
						final String clientIOIID = rs.getString("Id");
						final String ioiID = rs.getString("IoiId");
						// IoiVersion starts from 1 in GOR, while it start from 0 in Quattro, so keep in line with
						// Quattro.
						final int ioiVersion = rs.getInt("IoiVersion") - 1;
						map.put(clientIOIID, new IOIIDWithVersion(ioiID, ioiVersion));
					}
				}
			}
		});
	}
	
	/**
	 * @return Client IOI ID list of the messages come from Osprey GUI.
	 */
	public FixedSet<String> loadIOIsFromOspreyGUI() throws SQLException
	{
		final String sql = SQLBuilder
			.empty()
			.append("select distinct s.Id, d1.UpdatedBy as thisSource, d2.UpdatedBy as originalSource")
			.append("from IoiSession s")
			.append("join IoiDetails d1 on s.IoiId=d1.Id and d1.Version=s.IoiVersion")
			// The original New message
			.append("join IoiDetails d2 on s.IoiId=d2.Id and d2.Version=1")
			.getSQL();
		
		return FixedSet.build(list ->
		{
			try(final Connection gorConnection = Configuration.SINGLETON.createConnection("OSPREY_DB");
				final PreparedStatement query = gorConnection.prepareStatement(sql);)
			{
				try(final ResultSet rs = query.executeQuery();)
				{
					while(rs.next())
					{
						if(!_NON_OSPREY_IOI_SOURCES.contains(rs.getString("thisSource")) ||
							!_NON_OSPREY_IOI_SOURCES.contains(rs.getString("originalSource")))
						{
							list.add(rs.getString("Id"));
						}
					}
				}
			}
		});
	}
	
	private static final FixedList<String> _NON_OSPREY_IOI_SOURCES = FixedList.of(
		"Neptune",
		// Cancel timer UpdatedBy is "system"
		"system");
}
