package com.mizuhosc.selenium.ioi;

import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.log.*;
import java.net.*;
import java.util.*;
import org.joda.time.*;
import org.joda.time.format.*;

public class IOIJournalPopulator
{
	private final static String _OS = System.getProperty("os.name").toLowerCase();
	private final static String _FILE_NAME_FORMAT = "ioi.IOIService.%s.mizuho-sc.com.%s.jasper";
	private final static String _TODAY = DateTimeFormat.forPattern("yyyy-MM-dd").print(new DateTime());
	
	private final Optional<String> _ioiHost;
	
	public IOIJournalPopulator()
	{
		_ioiHost = Optional.ofNullable(Configuration.SINGLETON.getProperty("IOI.host"));
	}
	
	public String scp() throws UnknownHostException
	{
		final String fromDir = Configuration.SINGLETON.getProperty("IOI.journal.from");
		final String toDir = Configuration.SINGLETON.getProperty("IOI.journal.to");
		
		Log.info("scp file from %s to %s", fromDir, toDir);
		
		String result = "";
		String jaserFileName = "";
		if(_isWindows())
		{
			final String localHostName = InetAddress.getLocalHost().getHostName().toLowerCase();
			jaserFileName = String.format(_FILE_NAME_FORMAT, localHostName + ".topflagship", _TODAY);
			result = new ExecuteShellComand()
				.executeCommand(String.format("cp %s/%s %s", fromDir, jaserFileName, toDir));
		}
		else if(_ioiHost.isPresent())
		{
			jaserFileName = String.format(_FILE_NAME_FORMAT, _ioiHost.get(), _TODAY);
			result = new ExecuteShellComand().executeCommand(
				String.format(
					"scp quattro@%s:%s/%s %s",
					_ioiHost.get(),
					fromDir,
					jaserFileName,
					toDir));
		}
		
		System.out.println(result);
		
		final String fullFileName = toDir + "/" + jaserFileName;
		
		Log.info("File has been saved as %s", fullFileName);
		
		return fullFileName;
	}
	
	private static boolean _isWindows()
	{
		return _OS.indexOf("win") >= 0;
	}
	
	public static void main(final String[] args) throws UnknownHostException
	{
		new IOIJournalPopulator().scp();
	}
}

