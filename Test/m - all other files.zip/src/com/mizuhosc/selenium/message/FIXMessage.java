package com.mizuhosc.selenium.message;

import com.mizuhosc.selenium.verification.*;
import java.util.*;
import java.util.stream.*;

public class FIXMessage
{
	public final Map<String, String> fixTags;
	public final String raw;
	
	public FIXMessage(final String raw)
	{
		this.raw = raw;
		fixTags = ParseUlBridgeLog(raw);
	}
	
	public String get(final String tag)
	{
		return fixTags.get(tag);
	}
	
	// Below is copied from OspreyUtility used in GOR to parse ULBridge FIX logs.
	private static final String _UL_MSG_LOG_TAG_SEPARATOR = "\\|";
	private static final String _NORMALIZED_PIPELINE = "\u0004\u0003";
	
	// Parses ULBridge FIX log and ULMessage log to a tag value pair map.
	public static Map<String, String> ParseUlBridgeLog(final String bridgeLog)
	{
		return ExtractFIXTags(bridgeLog).stream().collect(Collectors.toMap($ -> $.getNumber(), $ -> $.getValue()));
	}
	
	public static List<FIXTagValue> ExtractFIXTags(final String bridgeLog)
	{
		if(bridgeLog == null || bridgeLog.trim().isEmpty())
		{
			return new LinkedList<>();
		}
		// As per FIX protocol, the first three fields in the standard header are BeginString (tag #8) followed by
		// BodyLength (tag #9) followed by MsgType (tag #35), while ULMessages all start with a message tag name, so
		// using "8=FIX" should be enough to tell a log is a fix log
		final String trimmed = bridgeLog.trim();
		if(trimmed.startsWith("8=FIX"))
		{
			return _parseNormalizedLog(normalizeFIXLog(trimmed));
		}
		return _parseNormalizedLog(trimmed);
	}
	
	private static List<FIXTagValue> _parseNormalizedLog(final String bridgeLog)
	{
		final List<FIXTagValue> list = new LinkedList<>();
		final String[] split = bridgeLog.split(_UL_MSG_LOG_TAG_SEPARATOR);
		for(String s: split)
		{
			if(!s.trim().isEmpty())
			{
				final int equalsPosition = s.indexOf("=");
				s = _Sanitize(s);
				
				if(equalsPosition < 0)
				{
					// append to previous, if it exists
					if(list.size() > 0)
					{
						final FIXTagValue previous = list.get(list.size() - 1);
						list.set(list.size() - 1, new FIXTagValue(previous.getNumber(), previous.getValue() + "|" + s));
					}
				}
				else
				{
					final String tag = s.substring(0, equalsPosition);
					// new key/value
					if(equalsPosition < s.length() - 1)
					{
						list.add(new FIXTagValue(tag, s.substring(equalsPosition + 1)));
					}
					else
					{
						list.add(new FIXTagValue(tag, ""));
					}
				}
			}
		}
		return list;
	}
	
	private static String _Sanitize(final String str)
	{
		return str.replaceAll(_NORMALIZED_PIPELINE, "|");
	}
	
	static String normalizeFIXLog(final String fixLog)
	{
		final StringBuilder result = new StringBuilder();
		final String[] splited = fixLog.split(_UL_MSG_LOG_TAG_SEPARATOR);
		for(final String s: splited)
		{
			final int indexOfEquals = s.indexOf("=");
			if(indexOfEquals < 0)
			{
				result.append(_NORMALIZED_PIPELINE).append(s.replaceAll("\\|", _NORMALIZED_PIPELINE));
			}
			else
			{
				final String tagNumberString = s.substring(0, indexOfEquals);
				try
				{
					Integer.parseInt(tagNumberString);
					// Valid tag value pair
					result.append("|").append(s);
				}
				catch(final NumberFormatException e)
				{
					// Tag number is not an integer, not a tag number actually, merge this one to previous
					result.append(_NORMALIZED_PIPELINE).append(s.replaceAll("\\|", _NORMALIZED_PIPELINE));
				}
			}
		}
		
		return result.toString();
	}
}
