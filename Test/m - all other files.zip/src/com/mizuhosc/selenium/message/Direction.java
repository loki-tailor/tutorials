package com.mizuhosc.selenium.message;

/**
 * Direction of the message. From the perspective of QBot.
 */
public enum Direction
{
	IN, // Need to keep the message for later verification
	OUT //Need to send the message out to QuattroOrderEngine
}
