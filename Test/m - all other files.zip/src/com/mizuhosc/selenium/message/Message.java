package com.mizuhosc.selenium.message;

import java.util.*;
import java.util.stream.*;

public class Message
{
	private final Direction _direction;
	private final MessageType _type;
	private final List<String> _raw;

	public Message(final Direction direction, final MessageType type, final List<String> raw)
	{
		_direction = direction;
		_type = type;
		_raw = raw;
	}

	public Direction getDirection()
	{
		return _direction;
	}

	public MessageType getType()
	{
		return _type;
	}

	public List<String> getRaw()
	{
		return _raw;
	}

	@Override
	public String toString()
	{
		return String.format("Direction: %s, type: %s, msg: %s", _direction, _type, _raw);
	}
	
	public String toCsvCell()
	{
		if(MessageType.FIX == _type)
		{
			return _raw.get(0);
		}
		return _raw.stream().collect(Collectors.joining("  "));
	}

	public FIXMessage toFIXMessage()
	{
		return new FIXMessage(_raw.get(0));
	}
}
