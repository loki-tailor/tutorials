package com.mizuhosc.selenium.message;

import com.mizuhosc.quattro.jasper.message.Request.*;

public enum MessageType implements RequestType
{
	FIX,
	FIDESSA,
	COMMAND,
	ADD_EXECUTION,
	CORRECT_EXECUTION,
	BUST_EXECUTION
}
