package com.mizuhosc.selenium.message;

/**
 * The target of the message from Quattro point of view.
 */
public enum MessageTarget
{
	CLIENT, // The message will be sent to client.
	MARKET// The messsage will be sent to market.
}
