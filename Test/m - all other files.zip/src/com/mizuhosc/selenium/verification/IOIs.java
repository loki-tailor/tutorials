package com.mizuhosc.selenium.verification;

import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.ioi.*;
import com.mizuhosc.selenium.log.*;
import com.mizuhosc.selenium.message.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;
import java.util.stream.*;
import javax.annotation.*;

/**
 * Holds both expected and actual IOIs.
 */
public class IOIs
{
	static final Set<String> _MATCH_TAGS =
		Configuration.SINGLETON.getValues("FIX.IOI.match.tags").stream().collect(Collectors.toSet());
	
	private final List<IOI> _expectedIOIs;
	private final List<IOI> _actualIOIs;
	private final FixedMap<String, IOIIDWithVersion> _expectedIOIMappings;
	private final FixedSet<String> _ioisFromOspreyGUI;
	
	public IOIs() throws SQLException
	{
		_expectedIOIs = new LinkedList<>();
		_actualIOIs = new LinkedList<>();
		_expectedIOIMappings = new IOIClientMessageLoader().loadIOIIDs();
		_ioisFromOspreyGUI = new IOIClientMessageLoader().loadIOIsFromOspreyGUI();
	}
	
	public void addExpected(final Message message)
	{
		final String rawMessage = message.getRaw().get(0);
		_expectedIOIs.add(new IOI(rawMessage));
	}
	
	public void addActual(final Message message)
	{
		final String rawMessage = message.getRaw().get(0);
		_actualIOIs.add(new IOI(rawMessage));
	}
	
	public void reportDiff() throws Exception
	{
		Log.info("Starts to report diff for IOI");
		
		final String jasperFileFullPath = new IOIJournalPopulator().scp();
		
		final Map<IOIIDWithVersion, List<String>> actualIOIMappings = new IOIJasperReader().read(jasperFileFullPath);
		
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		final File diffDirectory = new File("diffs");
		if(!diffDirectory.exists())
		{
			diffDirectory.mkdir();
		}
		final String reportFileName = "diffs/ReplayDiff_IOI" + "_" + sdf.format(new Date()) + ".csv";
		try(final BufferedWriter writer =
			new BufferedWriter(new OutputStreamWriter(new FileOutputStream(reportFileName))))
		{
			writer.write(IOIDiff.IOI_CSV_HEADER);
			writer.newLine();
			
			for(final IOI expectedIOI: _expectedIOIs)
			{
				final String ioiClientIDWithDate = expectedIOI.getIOIClientIDWithDate();
				
				// Skip the messages came from Osprey GUI.
				if(_ioisFromOspreyGUI.contains(ioiClientIDWithDate))
				{
					Log.info("Skipping message with ioi client ID %s comes from Osprey GUI.", ioiClientIDWithDate);
					continue;
				}
				
				final IOIIDWithVersion expectedIOIIDWithVersion = _expectedIOIMappings.get(ioiClientIDWithDate);
				
				final Optional<IOI> actualIOI =
					_actualIOIs
						.stream()
						.filter($ -> $.matches(expectedIOI, expectedIOIIDWithVersion, actualIOIMappings))
						.findFirst();
				if(actualIOI.isPresent())
				{
					final IOI currentActualIOI = actualIOI.get();
					
					Log.info(
						"IOI ID & Version: %s, Expected IOI: %s, Actual matched IOI: %s",
						expectedIOIIDWithVersion,
						expectedIOI.getKey(),
						currentActualIOI.getKey());
					
					for(final IOIDiff diff: expectedIOI.diff(expectedIOIIDWithVersion, currentActualIOI))
					{
						writer.write(diff.toCsvLine());
						writer.newLine();
					}
					
					_actualIOIs.remove(currentActualIOI);
				}
				else
				{
					writer.write(IOIDiff.missingIOI(expectedIOIIDWithVersion, expectedIOI).toCsvLine());
					writer.newLine();
				}
			}
			
			for(final IOI unexpectedIOI: _actualIOIs)
			{
				final @Nullable IOIIDWithVersion unexpectedIOIIDWithVersion =
					actualIOIMappings
						.entrySet()
						.stream()
						.filter($ -> $.getValue().contains(unexpectedIOI.get("23")))
						.findFirst()
						.map($ -> $.getKey())
						.orElseGet(() -> actualIOIMappings
							.entrySet()
							.stream()
							.filter($ -> $.getValue().contains(unexpectedIOI.get("26")))
							.findFirst()
							.map($ -> $.getKey())
							.orElse(null));
				
				writer.write(IOIDiff.unexpectedIOI(unexpectedIOIIDWithVersion, unexpectedIOI).toCsvLine());
				writer.newLine();
			}
		}
		
		Log.info("Finished reporting diff for file %s", reportFileName);
	}
	
}
