package com.mizuhosc.selenium.verification;

import java.util.*;

public class FidessaDSATagComparator implements ComplexComparator
{
	private static final String _MSG_TYPE = "MESSAGE_TYPE.s";
	private static final String _AMEND_MSG_TYPE = "\"TXN_CLIENT_ORDER_REPLACE\"";
	private final int _tag;
	private final String _xpTagName;
	
	public FidessaDSATagComparator(final int tag)
	{
		_tag = tag;
		_xpTagName = "CUSTOM.XP_DATA_" + _tag + ".s";
	}
	
	@Override
	public ComparisonResult compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, final String clientId)
	{
		final String expected = expectedMap.get(_xpTagName);
		final String actual = actualMap.get(_xpTagName);
		
		// Quattro doesn't send tags that is not defined in the xml but GOR does. Confirmed with ALGO team that this
		// is ok.
		if("\"\"".equals(expected) && actual == null) return ComparisonResult.matched();
		
		// DO NOT compare the value in the case of "TXN_CLIENT_ORDER_REPLACE". GOR does copy back from last non
		// execution event, but Quattro does copy back from last event including execution. Confirm with ALGO team
		// that this is OK.
		final String msgType = actualMap.get(_MSG_TYPE);
		if(_AMEND_MSG_TYPE.equals(msgType)) return ComparisonResult.matched();
		
		// From 22.1, quattro will have 40 tags, but GOR has up to 36. Ignore diff of 37 to 40
		if(_tag > 36 && _tag <= 40)
		{
			return ComparisonResult.matched();
		}
		
		// XP_3 in GOR may have ".0"s removed but Quattro will not.
		if(_tag == 3)
		{
			return new NumberComparator().compare(expected, actual);
		}
		
		return new StringEqualsComparator().compare(expected, actual);
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return _xpTagName;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(getTagsForDiffReport());
	}
	
}
