package com.mizuhosc.selenium.verification;

import java.util.*;

public class LastLiquidityIndicateComparator implements ComplexComparator
{
	private static final String _LAST_LIQUIDITY_INDICATOR_TAG = "851";
	
	private final Set<String> _clientsToBlock851;
	
	public LastLiquidityIndicateComparator(final Set<String> clientsToBlock851)
	{
		_clientsToBlock851 = clientsToBlock851;
	}
	
	@Override
	public ComparisonResult compare(
		final Map<String, String> expectedMap,
		final Map<String, String> actualMap,
		final String gorClientId)
	{
		final String actual = actualMap.get(_LAST_LIQUIDITY_INDICATOR_TAG);
		
		// Give priority to block 851 check
		if(_clientsToBlock851.contains(gorClientId))
		{
			if(actual != null) return ComparisonResult.unmatch("851 should be blocked");
			return ComparisonResult.matched();
		}
		
		// Below are for clients that we should 851
		final String expected = expectedMap.get(_LAST_LIQUIDITY_INDICATOR_TAG);
		
		// StringEquals compare matches, return true.
		if(new StringEqualsComparator().compare(expected, actual).matches()) return ComparisonResult.matched();
		
		// Accept the case where expected is null and actual is not null. This is just because historical orders won't
		// have 851 in GOR.
		if(expected == null && actual != null) return ComparisonResult.matched();
		
		// This is for following cases:
		// expected !=null but actual ==null
		// expected !=null && actual !=null and !expected.equals(actual).
		return ComparisonResult.unmatch(null);
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return _LAST_LIQUIDITY_INDICATOR_TAG;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(_LAST_LIQUIDITY_INDICATOR_TAG);
	}
	
}
