package com.mizuhosc.selenium.verification;

import static com.mizuhosc.selenium.verification.FIXMessageComparator.*;
import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.message.*;
import java.util.*;
import java.util.stream.*;
import javax.annotation.*;

public class FidessaMessageComparator
{
	private final static Map<String, FieldComparator> _simpleComparators = new HashMap<>();
	private final static List<ComplexComparator> _complexComparators = new LinkedList<>();
	
	static
	{
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIDESSA.tags.existenceCompare"))
			.forEach($ -> _simpleComparators.put($, new ExistenceComparator()));
		_getTagsConfigured(Configuration.SINGLETON.getProperty("Fidessa.tags.numberCompare"))
			.forEach($ -> _simpleComparators.put($, new NumberComparator()));
		
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIDESSA.tags.ignore"))
			.forEach($ -> _simpleComparators.put($, new IgnoreComparator()));
		
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIDESSA.tags.orderIdCompare"))
			.forEach($ -> _simpleComparators.put($, new OrderIdComparator()));
		
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIDESSA.tags.dateCompare"))
			.forEach($ -> _simpleComparators.put($, new DateComparator()));
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIDESSA.tags.datetimeCompare"))
			.forEach($ -> _simpleComparators.put($, new FidessaDateTimeComparator()));
		
		// Add SOURCE_REF check
		_simpleComparators.put("SOURCE_REF.s", new SourceRefComparator());
		
		// Add ORDER_FLAGS comparator
		_simpleComparators.put("DETAILS.ORDER_FLAGS.s", new FidessaOrderFlagsComparator());
		_simpleComparators.put("XP_DATA.DETAILS.ORDER_FLAGS.s", new FidessaOrderFlagsComparator());
		
		// Add SessionId comparator
		_simpleComparators.put("CUSTOM.FIX_SESSION_ID.s", new FidessaSessionIdComparator());// For OMAR
		_simpleComparators.put("XP_DATA.CUSTOM.FIX_SESSION_ID.s", new FidessaSessionIdComparator());// For OMAR
		
		// Add up to 40. In 21.1, we will add XP tag to 40.
		for(int i = 1; i <= 40; i++)
		{
			_complexComparators.add(new FidessaDSATagComparator(i));
		}
		
	}
	
	public List<Diff> compare(final Message expected, final Message actual)
	{
		final List<Diff> result = new LinkedList<>();
		if(expected == null && actual != null)
		{
			result.add(new Diff(
				null,
				MessageType.FIDESSA.name(),
				"WholeMsg",
				"",
				"",
				"unexpected message",
				_getInstrument(actual),
				"",
				actual.toCsvCell()));
		}
		else if(expected != null && actual == null)
		{
			result.add(new Diff(
				null,
				MessageType.FIDESSA.name(),
				"WholeMsg",
				"",
				"",
				"missing message",
				_getInstrument(expected),
				expected.toCsvCell(),
				""));
		}
		else if(expected != null && actual != null)
		{
			final Map<String, String> expectedMap = convertToMap(expected.getRaw());
			final Map<String, String> actualMap = convertToMap(actual.getRaw());
			final Set<String> keys = new TreeSet<>();
			keys.addAll(expectedMap.keySet());
			keys.addAll(actualMap.keySet());
			for(final String key: keys)
			{
				final String expectedTagValue = expectedMap.get(key);
				final String actualTagValue = actualMap.get(key);
				final FieldComparator comparator = _simpleComparators.computeIfAbsent(key, $ -> _getComparator($));
				final ComparisonResult cr = comparator.compare(expectedTagValue, actualTagValue);
				if(!cr.matches())
				{
					final Diff diff = new Diff(
						null,
						MessageType.FIDESSA.name(),
						key,
						expectedTagValue,
						actualTagValue,
						cr.getReason().orElse(""),
						_getInstrument(expected),
						expected.toCsvCell(),
						actual.toCsvCell());
					result.add(diff);
				}
			}
			
			for(final ComplexComparator cc: _complexComparators)
			{
				// No plan to do client specific FIDESSA message compare as of now.
				final ComparisonResult cr = cc.compare(expectedMap, actualMap, null);
				if(!cr.matches())
				{
					final Diff diff = new Diff(
						null,
						MessageType.FIDESSA.name(),
						cc.getTagsForDiffReport(),
						cc.getValueForDiffReport(expectedMap),
						cc.getValueForDiffReport(actualMap),
						cr.getReason().orElse(""),
						_getInstrument(expected),
						expected.toCsvCell(),
						actual.toCsvCell());
					result.add(diff);
				}
			}
		}
		return result;
	}
	
	FieldComparator _getComparator(final String key)
	{
		if(isDSAParameterTag(key))
		{
			// Ignore compare of XP_DATA_ fileds
			return new IgnoreComparator();
		}
		return new StringEqualsComparator();
	}
	
	static boolean isDSAParameterTag(final String key)
	{
		return key.contains("XP_DATA_") && !key.contains("XP_DATA_0");
	}
	
	public static Map<String, String> convertToMap(final List<String> lines)
	{
		final Map<String, String> pairs = new HashMap<>();
		for(final String s: lines)
		{
			final int indexOfEquals = s.indexOf("=");
			final String key = s.substring(0, indexOfEquals).trim();
			final String value = s.substring(Math.min(indexOfEquals + 1, s.length())).trim();
			pairs.put(key, value);
		}
		return pairs;
	}
	
	static String _getInstrument(final @Nonnull Message message)
	{
		final Map<String, String> map = convertToMap(message.getRaw());
		return Stream
			.of("XP_DATA.DETAILS.INSTRUMENT_CODE.s", "DETAILS.INSTRUMENT_ID.s", "DETAILS.INSTRUMENT_CODE.s")
			.map(map::get)
			.filter($ -> $ != null)
			.findFirst()
			.orElse(null);
	}
}
