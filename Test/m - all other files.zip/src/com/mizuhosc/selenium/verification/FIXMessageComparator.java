package com.mizuhosc.selenium.verification;

import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.message.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;
import javax.annotation.*;

public class FIXMessageComparator
{
	private final static Map<String, FieldComparator> _staticSimpleComparators = new HashMap<>();
	private final static List<ComplexComparator> _staticComplexComparators = new LinkedList<>();
	
	static
	{
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.existenceCompare"))
			.forEach($ -> _staticSimpleComparators.put($, new ExistenceComparator()));
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.numberCompare"))
			.forEach($ -> _staticSimpleComparators.put($, new NumberComparator()));
		
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.looseTimeCompare"))
			.forEach($ -> _staticSimpleComparators.put($, new FIXLooseTimestampFieldComparator()));
		
		_staticSimpleComparators.put("37", new OrderIdComparator());
		_staticSimpleComparators.put("8053", new OrderIdComparator());
		_staticSimpleComparators.put("64", new DateComparator());
		_staticSimpleComparators.put("75", new DateComparator());
		
		final @Nullable String ignoreConditions = Configuration.SINGLETON.getProperty("FIX.tags.ignore.conditions");
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.ignore.conditionally")).forEach(tag ->
		{
			_staticSimpleComparators.put(tag, new IgnoreComparator());
			_staticComplexComparators.add(new ConditionallyIgnoreComparator(ignoreConditions, tag));
		});
		
		_ignoreCompareTags();
		
		_staticComplexComparators.add(new ExecIDComparator());
		_staticComplexComparators.add(new AccountComparator());
		_staticComplexComparators.add(new TransactTimeComparator());
		_staticComplexComparators.add(new LastPxComparator());
		_staticComplexComparators.add(new SecurityTypeComparator());
		_staticComplexComparators.add(new FixTagPriceComparator());
		_staticComplexComparators.add(new LastCapacityComparator());
		_staticComplexComparators.add(new LastMarketComparator(LastMarketComparator.gorClientsWithSendMicInLastMkt()));
		_staticComplexComparators.add(
			new LastLiquidityIndicateComparator(
				Configuration.SINGLETON
					.getValues("FIX.MiFID2.clients.block.851")
					.stream()
					.collect(Collectors.toSet())));
	}

	private static void _ignoreCompareTags()
	{
		final Set<String> tagsToIgnore = new HashSet<>();
		tagsToIgnore.add("17");
		tagsToIgnore.add("19");
		tagsToIgnore.add("44");
		tagsToIgnore.add("29");// LastCapacity(29) will be compared by LastCapacityComparator
		tagsToIgnore.add("30");// LastMkt(30) will be compared by LastMarketComparator
		tagsToIgnore.add("1");// Account(1) will be compared by AccountComparator
		tagsToIgnore.add("60");// TransactTime(60) will be compared by TransactTimeComparator
		tagsToIgnore.add("31");// LastPx(31) will be compared by LastPxComparator
		tagsToIgnore.add("167");// SecurityType(167) will be compared by SecurityTypeComparator
		tagsToIgnore.add("851");// LastLiquidityInd(851) will be compared by LastLiquidityIndicateComparator
		tagsToIgnore.addAll(_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.ignore")));
		tagsToIgnore.forEach($ -> _staticSimpleComparators.put($, new IgnoreComparator()));
	}
	
	private final Map<String, FieldComparator> _simpleComparators = new ConcurrentHashMap<>();
	
	public FIXMessageComparator(final ClOrdIDToATP clOrdIDToATP)
	{
		_simpleComparators.putAll(_staticSimpleComparators);
		_simpleComparators.put("11", new ClOrdIDComparator(clOrdIDToATP));
		_simpleComparators.put("41", new ClOrdIDComparator(clOrdIDToATP));
	}
	
	public List<Diff> compare(final Message expected, final Message actual, final String clientId)
	{
		final List<Diff> result = new LinkedList<>();
		if(expected == null && actual != null)
		{
			result.add(new Diff(
				null,
				MessageType.FIX.name(),
				"WholeMsg",
				"",
				"",
				"unexpected message",
				_getInstrument(actual),
				"",
				actual.toCsvCell()));
		}
		else if(expected != null && actual == null)
		{
			result.add(new Diff(
				null,
				MessageType.FIX.name(),
				"WholeMsg",
				"",
				"",
				"missing message",
				_getInstrument(expected),
				expected.toCsvCell(),
				""));
		}
		else if(expected != null && actual != null)
		{
			final String expectedString = expected.getRaw().get(0);
			final String actualString = actual.getRaw().get(0);
			final Map<String, String> expectedMap = FIXMessage.ParseUlBridgeLog(expectedString);
			final Map<String, String> actualMap = FIXMessage.ParseUlBridgeLog(actualString.replaceAll("\u0001", "\\|"));
			final Set<String> keys = new TreeSet<>();
			keys.addAll(expectedMap.keySet());
			keys.addAll(actualMap.keySet());
			for(final String key: keys)
			{
				final String expectedTagValue = expectedMap.get(key);
				final String actualTagValue = actualMap.get(key);
				final FieldComparator comparator = _simpleComparators.computeIfAbsent(
					key,
					$ -> new StringEqualsComparator());
				final ComparisonResult cr = comparator.compare(expectedTagValue, actualTagValue);
				if(!cr.matches())
				{
					final Diff diff = new Diff(
						null,
						MessageType.FIX.name(),
						key,
						expectedTagValue,
						actualTagValue,
						cr.getReason().orElse(""),
						_getInstrument(expected),
						expected.toCsvCell(),
						actual.toCsvCell());
					result.add(diff);
				}
				
			}
			
			for(final ComplexComparator cc: _staticComplexComparators)
			{
				final ComparisonResult cr = cc.compare(expectedMap, actualMap, clientId);
				if(!cr.matches())
				{
					final Diff diff = new Diff(
						null,
						MessageType.FIX.name(),
						cc.getTagsForDiffReport(),
						cc.getValueForDiffReport(expectedMap),
						cc.getValueForDiffReport(actualMap),
						cr.getReason().orElse(""),
						_getInstrument(expected),
						expected.toCsvCell(),
						actual.toCsvCell());
					result.add(diff);
				}
			}
			
		}
		return result;
	}
	
	static String _getInstrument(final @Nonnull Message message)
	{
		final String fixString = message.getRaw().get(0);
		final Map<String, String> map = FIXMessage.ParseUlBridgeLog(fixString.replaceAll("\u0001", "\\|"));
		return Stream.of("55", "48").map(map::get).filter($ -> $ != null).findFirst().orElse(null);
	}
	
	static Set<String> _getTagsConfigured(final String configValue)
	{
		final Set<String> result = new HashSet<>();
		if(configValue == null)
		{
			return result;
		}
		for(final String s: configValue.split(","))
		{
			final String trimmed = s.trim();
			if(!trimmed.isEmpty())
			{
				result.add(trimmed);
			}
		}
		return result;
	}
}
