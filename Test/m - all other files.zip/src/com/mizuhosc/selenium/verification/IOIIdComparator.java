package com.mizuhosc.selenium.verification;

import java.util.*;

public class IOIIdComparator implements ComplexComparator
{
	private static final String _IOI_ID_TAG = "23";
	private static final String _IOI_REF_ID_TAG = "26";
	private final IOIIdCache _cache;
	
	public IOIIdComparator(final IOIIdCache cache)
	{
		_cache = cache;
	}
	
	@Override
	public ComparisonResult compare(
		final Map<String, String> expectedMap,
		final Map<String, String> actualMap,
		final String clientId)
	{
		final String expectedIoiId = expectedMap.get(_IOI_ID_TAG);
		final String actualIoiId = actualMap.get(_IOI_ID_TAG);
		final ComparisonResult ioiIdResult = new ExistenceComparator().compare(expectedIoiId, actualIoiId);
		if(!ioiIdResult.matches())
		{
			return ioiIdResult;
		}
		
		_cache.map(expectedIoiId, actualIoiId);
		
		final String expectedIoiRefId = expectedMap.get(_IOI_REF_ID_TAG);
		final String actualIoiRefId = actualMap.get(_IOI_REF_ID_TAG);
		
		final ComparisonResult ioiRefIdExistenceResult =
			new ExistenceComparator().compare(expectedIoiRefId, actualIoiRefId);
		if(!ioiRefIdExistenceResult.matches())
		{
			return ioiRefIdExistenceResult;
		}
		
		if(actualIoiRefId == null) return ComparisonResult.matched();
		if(actualIoiRefId.equals(_cache.get(expectedIoiRefId))) return ComparisonResult.matched();
		
		return ComparisonResult.unmatch(String.format(
			"IoiRefId(26) should be %s but was %s.",
			_cache.get(expectedIoiRefId),
			actualIoiRefId));
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return "23/26";
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get("23") + "/" + data.get("26");
	}
	
}
