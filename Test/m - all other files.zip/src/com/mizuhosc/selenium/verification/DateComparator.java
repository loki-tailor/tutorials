package com.mizuhosc.selenium.verification;

import java.text.*;

/**
 * Compares value is in format "yyyyMMdd".
 */
public class DateComparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null && actual == null)
		{
			return ComparisonResult.matched();
		}
		
		if(expected == null && actual != null)
		{
			return ComparisonResult.unmatch("unexpected");
		}
		
		if(expected != null && actual == null)
		{
			return ComparisonResult.unmatch("missing");
		}
		
		try
		{
			_dateFormat.get().parse(actual.replaceAll("\"", ""));
		}
		catch(final ParseException e)
		{
			return ComparisonResult.unmatch("wrong format");
		}
		
		// Date is the correct format
		return ComparisonResult.matched();
	}
	
	private final ThreadLocal<DateFormat> _dateFormat = new ThreadLocal<DateFormat>()
	{
		@Override
		protected DateFormat initialValue()
		{
			final SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			format.setLenient(false);
			return format;
		}
	};
	
}
