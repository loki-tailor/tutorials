package com.mizuhosc.selenium.verification;

import java.util.*;

/**
 * The comparator that compares the value for one tag or a couple of tags. This comparator usually need to look at
 * several tags in the message to make decision.
 */
public interface ComplexComparator
{
	// TODO: remove parameter gorClientId after GOR is retired
	ComparisonResult
		compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, final String gorClientId);
	
	String getTagsForDiffReport();
	
	String getValueForDiffReport(final Map<String, String> data);
}
