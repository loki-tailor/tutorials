package com.mizuhosc.selenium.verification;

import com.mizuhosc.quattro.util.value.*;
import java.util.*;

public class ComparisonResult extends Tuple<Boolean, Optional<String>>
{
	ComparisonResult(final boolean matches, final String reason)
	{
		super(matches, Optional.ofNullable(reason));
	}

	public static ComparisonResult matched()
	{
		return new ComparisonResult(true, null);
	}

	public static ComparisonResult unmatch(final String reason)
	{
		return new ComparisonResult(false, reason);
	}

	public boolean matches()
	{
		return _a;
	}

	//Holds reason for the mismatch. This is for the cases like ExecId is not an integer, for tag TransactTime is not following FIX spec etc.
	public Optional<String> getReason()
	{
		return _b;
	}

}
