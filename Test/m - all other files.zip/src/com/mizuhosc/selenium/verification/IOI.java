package com.mizuhosc.selenium.verification;

import com.mizuhosc.selenium.ioi.*;
import com.mizuhosc.selenium.message.*;
import java.util.*;

public class IOI
{
	private final Map<String, String> _values;
	private final Set<IOIRoutingInformation> _routings;
	private static final StringEqualsComparator _STRINGEQUALSCOMPARATOR = new StringEqualsComparator();
	
	private static final String _ROUTINGT_TYPE_TAG = "216";
	private final String _raw;
	
	public IOI(final String rawMsg)
	{
		_raw = rawMsg;
		_values = new HashMap<>();
		_routings = new HashSet<>();
		
		final List<FIXTagValue> tags = FIXMessage.ExtractFIXTags(rawMsg);
		for(int i = 0; i < tags.size(); i++)
		{
			final FIXTagValue tag = tags.get(i);
			if(_ROUTINGT_TYPE_TAG.equals(tag.getNumber()))
			{
				i++;
				final FIXTagValue routingId = tags.get(i);
				_routings.add(new IOIRoutingInformation(tag.getValue(), routingId.getValue()));
			}
			else
			{
				_values.put(tag.getNumber(), tag.getValue());
			}
		}
	}
	
	public Map<String, String> getNonRepeatingValues()
	{
		return _values;
	}
	
	public Set<String> getAllKeys()
	{
		return _values.keySet();
	}
	
	public String getNonRepeatingValue(final String key)
	{
		return _values.get(key);
	}
	
	/**
	 * @return true if current IOI matches the passed in IOI. This matching is not used in the diff, but used to find
	 *         the matching IOI that can be used as the target for compare. The reason behind this is GOR sends IOIs to
	 *         multiple sessions on receiving IOI from Neptune, there is no guarantee on the order of messages going
	 *         out.
	 *         We are using this match to find the matching IOI and then compare the tag values.
	 * 
	 */
	public boolean matches(final IOI ioi, final Set<String> matchTags)
	{
		for(final String tag: matchTags)
		{
			final String expectedValue = ioi._values.get(tag);
			final String actualValue = _values.get(tag);
			final FieldComparator comparator = "62".equals(tag) ? new Tag62Comparator() : _STRINGEQUALSCOMPARATOR;
			final ComparisonResult r = comparator.compare(expectedValue, actualValue);
			if(!r.matches()) return false;
		}
		
		// Compare for routing information
		return _routings.equals(ioi._routings);
	}
	
	public boolean matches(
		final IOI anotherIOI,
		final IOIIDWithVersion expectedIOIIDWithVersion,
		final Map<IOIIDWithVersion, List<String>> actualIOIMappings)
	{
		// Match the session name
		final String expectedSession = anotherIOI.get("56");
		final String actualSession = get("56");
		if(!expectedSession.equals(actualSession)) return false;
		
		// Match IOITransType: N/R/C
		final String expectedTransType = anotherIOI.get("28");
		final String actualTransType = get("28");
		if(!expectedTransType.equals(actualTransType)) return false;
		
		// Use tag 23 on New message
		if("N".equals(actualTransType))
		{
			return Optional
				.ofNullable(actualIOIMappings.get(expectedIOIIDWithVersion))
				.filter($ -> $.contains(get("23")))
				.isPresent();
		}
		
		// Use tag 26 on Replace/Cancel message. This is because in Quattro, we don't persist the Cancel message into
		// the jasper file when using Cancel/New pairs to substitute Replace.
		return _matchesPreviousVersion(actualIOIMappings, expectedIOIIDWithVersion);
	}
	
	private boolean _matchesPreviousVersion(
		final Map<IOIIDWithVersion, List<String>> actualIOIMappings,
		final IOIIDWithVersion expectedIOIIDWithVersion)
	{
		// If the previous version is the message came from Osprey GUI, we need to lookup for one more previous version.
		final IOIIDWithVersion previousVersion = expectedIOIIDWithVersion.previousVersion();
		final List<String> prevousIOIMappings = actualIOIMappings.get(previousVersion);
		final boolean matches = prevousIOIMappings.contains(get("26"));
		
		if(matches) return true;
		if(previousVersion.ioiVersion == 0) return matches;
		return _matchesPreviousVersion(actualIOIMappings, previousVersion);
	}
	
	public List<IOIDiff> diff(final IOIIDWithVersion ioiIDWithVersion, final IOI target)
	{
		return new IOIComparator().compare(ioiIDWithVersion, this, target);
	}
	
	@Override
	public String toString()
	{
		return _raw;
	}
	
	public String getRaw()
	{
		return _raw;
	}
	
	public String get(final String key)
	{
		return _values.get(key);
	}
	
	private String _getIOIClientIDWithoutDate(final String tag)
	{
		final String rawClientIOIID = get(tag);
		// There are some cases that 23 contains date. e.g. ATRIOI session. We only need the part without date.
		return rawClientIOIID.substring(rawClientIOIID.length() - 7);
	}
	
	public String getIOIClientIDWithDate()
	{
		final String sendTimeInUTC = get("52");
		return new UTCDateTimeParser(sendTimeInUTC).formatDateOfJapan() + "-" + _getIOIClientIDWithoutDate("23");
	}
	
	public String getKey()
	{
		return get("23") + "/" + get("26");
	}
}
