package com.mizuhosc.selenium.verification;

import java.util.*;

public class LastPxComparator implements ComplexComparator
{
	private static final String _LAST_PX_TAG = "31";
	private static final String _EXEC_TYPE_TAG = "150";
	
	@Override
	public ComparisonResult compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, final String clientId)
	{
		final String expectedLastPx = expectedMap.get(_LAST_PX_TAG);
		final String expectedExecType = actualMap.get(_EXEC_TYPE_TAG);
		final String actualLastPx = actualMap.get(_LAST_PX_TAG);
		final String actualExecType = actualMap.get(_EXEC_TYPE_TAG);

		// Treat LastPx 0.0 and 0 as matched for DFD when processing GOR messages replay
		if("3".equals(actualExecType) &&
			"3".equals(expectedExecType) &&
			"0".equals(actualLastPx) &&
			"0.0".equals(expectedLastPx))
		{
			return ComparisonResult.matched();
		}
		return new StringEqualsComparator().compare(expectedLastPx, actualLastPx);
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return _LAST_PX_TAG;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(_LAST_PX_TAG);
	}

}
