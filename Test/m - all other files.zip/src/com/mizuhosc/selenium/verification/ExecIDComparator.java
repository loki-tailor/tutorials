package com.mizuhosc.selenium.verification;

import java.util.*;
import java.util.concurrent.*;

public class ExecIDComparator implements ComplexComparator
{
	private static final String _MSG_TYPE_TAG = "35";
	private static final String _FIX_VERSION_TAG = "8";
	private static final String _EXEC_ID_TAG = "17";
	private static final String _EXEC_REF_ID_TAG = "19";
	private static final String _TARGET_COMP_ID_TAG = "56";
	private static final String _ORDER_ID_TAG = "37";

	// A map from OrderId to Order's expected and actual orderid
	private static final ConcurrentHashMap<String, ConcurrentHashMap<String, String>> _EXECIDS_PER_ORDER =
		new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Set<String>> _EXECIDS_PER_SESSION = new ConcurrentHashMap<>();

	@Override
	public ComparisonResult compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, String clientId)
	{
		final String msgType = expectedMap.get(_MSG_TYPE_TAG);

		// Don't compare if MsgType is not 8
		if(!"8".equals(msgType))
		{
			return ComparisonResult.matched();
		}

		// ExecID should not be null. Assume ExecID in expected is null
		final String actualExecId = actualMap.get(_EXEC_ID_TAG);
		if(actualExecId == null)
		{
			return ComparisonResult.unmatch(null);
		}
		
		// ExecID should be unique per session
		final String targetCompID = actualMap.get(_TARGET_COMP_ID_TAG);
		final Set<String> sessionExecIds = _EXECIDS_PER_SESSION.computeIfAbsent(targetCompID, $ -> new HashSet<>());
		if(sessionExecIds.contains(actualExecId))
		{
			return ComparisonResult.unmatch("ExecId not unique on this session");
		}
		else
		{
			sessionExecIds.add(actualExecId);
		}

		// ExecId should be positive int for FIX4.0
		if("FIX.4.0".equals(actualMap.get(_FIX_VERSION_TAG)))
		{
			try
			{
				final int i = Integer.parseInt(actualExecId);
				if(i <= 0)
				{
					return ComparisonResult.unmatch("not positive");
				}
			}
			catch(final NumberFormatException e)
			{
				return ComparisonResult.unmatch("not an integer");
			}
		}
		
		// ExecRefID should point to ExecID of same order
		final String orderId = actualMap.get(_ORDER_ID_TAG);
		final String expectedExecId = expectedMap.get(_EXEC_ID_TAG);
		final ConcurrentHashMap<String, String> orderExecIds =
			_EXECIDS_PER_ORDER.computeIfAbsent(orderId, $ -> new ConcurrentHashMap<>());
		orderExecIds.put(expectedExecId, actualExecId);
		
		final String expectedExecRefId = expectedMap.get(_EXEC_REF_ID_TAG);
		final String actualExecRefId = actualMap.get(_EXEC_REF_ID_TAG);
		if(actualExecRefId != null && expectedExecRefId == null)
		{
			return ComparisonResult.unmatch("unexpected");
		}
		else if(actualExecRefId == null && expectedExecRefId != null)
		{
			return ComparisonResult.unmatch("missing");
		}
		else if(actualExecRefId != null && expectedExecRefId != null)
		{
			// Value of actual ExecId. We can find it by the lookup using expectedExecRefId
			final String execRefIdInTrade = orderExecIds.get(expectedExecRefId);
			if(!actualExecRefId.equals(execRefIdInTrade))
			{
				return ComparisonResult.unmatch("ExecRefId doesn't point to same trade as expected");
			}
		}
		// ExecRefId null in both
		return ComparisonResult.matched();
	}

	@Override
	public String getTagsForDiffReport()
	{
		return "17/19";
	}

	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get("17") + "/" + data.get("19");
	}

}
