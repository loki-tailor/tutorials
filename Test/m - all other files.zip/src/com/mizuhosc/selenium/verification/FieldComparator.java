package com.mizuhosc.selenium.verification;

public interface FieldComparator
{
	ComparisonResult compare(final String expected, final String actual);
}
