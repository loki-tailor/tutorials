package com.mizuhosc.selenium.verification;

import java.util.*;

/**
 * Compares SourceRef's existence and uniqueness.
 */
public class SourceRefComparator implements FieldComparator
{
	private static final Set<String> _ALL_SOURCE_REFS = new HashSet<>();
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null && actual == null)
		{
			return ComparisonResult.matched();
		}
		if(expected != null && actual == null || expected == null && actual != null)
		{
			return ComparisonResult.unmatch(null);
		}
		if(!_ALL_SOURCE_REFS.contains(actual))
		{
			_ALL_SOURCE_REFS.add(actual);
			return ComparisonResult.matched();
		}
		return ComparisonResult.unmatch("value not unique");
	}

}
