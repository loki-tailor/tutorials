package com.mizuhosc.selenium.verification;

/**
 * Represents a routing information.
 */
public class IOIRoutingInformation
{
	private final String _routingType;
	private final String _routingId;
	
	public IOIRoutingInformation(final String routingType, final String routingId)
	{
		_routingType = routingType;
		_routingId = routingId;
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((_routingId == null) ? 0 : _routingId.hashCode());
		result = prime * result + ((_routingType == null) ? 0 : _routingType.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(final Object obj)
	{
		if(this == obj) return true;
		if(obj == null) return false;
		if(getClass() != obj.getClass()) return false;
		final IOIRoutingInformation other = (IOIRoutingInformation)obj;
		if(_routingId == null)
		{
			if(other._routingId != null) return false;
		}
		else if(!_routingId.equals(other._routingId)) return false;
		if(_routingType == null)
		{
			if(other._routingType != null) return false;
		}
		else if(!_routingType.equals(other._routingType)) return false;
		return true;
	}
	
	@Override
	public String toString()
	{
		return String.format("RoutingType: %s, RoutingId: %s", _routingType, _routingId);
	}
}
