package com.mizuhosc.selenium.verification;

import java.util.*;
import java.util.concurrent.*;

public class IOIIdCache
{
	private final Map<String, String> _gorToQuattro;
	
	public IOIIdCache()
	{
		_gorToQuattro = new ConcurrentHashMap<>();
	}
	
	public void map(final String gorIOIId, final String quattroIOIId)
	{
		_gorToQuattro.put(gorIOIId, quattroIOIId);
	}
	
	public String get(final String gorIoiId)
	{
		return _gorToQuattro.get(gorIoiId);
	}
}
