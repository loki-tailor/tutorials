package com.mizuhosc.selenium.verification;

import java.util.*;

/**
 * Comparator for FIX tag Account(1). Ignores the missing of tag 1 in 35=9.
 */
public class AccountComparator implements ComplexComparator
{
	private static final String _MSG_TYPE_TAG = "35";
	private static final String _FIX_VERSION_TAG = "8";
	public static final String ACCOUNT_TAG = "1";
	
	@Override
	public ComparisonResult compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, final String clientId)
	{
		final String expectedAccount = expectedMap.get(ACCOUNT_TAG);
		final String actualAccount = actualMap.get(ACCOUNT_TAG);
		
		// We don't have FIX4.0 session anymore. For FIX4.1, we will ignore the diff if tag 1 is in expected but not in
		// actual. Reason for this is Quattro doesn't copy back tag 1 for cancel reject
		final String fixVersion = actualMap.get(_FIX_VERSION_TAG);
		final String msgType = actualMap.get(_MSG_TYPE_TAG);
		if("FIX.4.1".equals(fixVersion) && "9".equals(msgType))
		{
			if(expectedAccount != null && actualAccount == null)
			{
				return ComparisonResult.matched();
			}
			return new StringEqualsComparator().compare(expectedAccount, actualAccount);
		}
		return new StringEqualsComparator().compare(expectedAccount, actualAccount);
	}

	@Override
	public String getTagsForDiffReport()
	{
		return ACCOUNT_TAG;
	}

	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(ACCOUNT_TAG);
	}

}
