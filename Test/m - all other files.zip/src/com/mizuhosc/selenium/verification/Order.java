package com.mizuhosc.selenium.verification;

import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.message.*;
import com.mizuhosc.selenium.replay.*;
import java.util.*;

/**
 * Encapsulates all the messages of an order to verify.
 *
 */
public class Order
{
	private final String _orderId;
	private final List<Message> _fixMessagesToClient;
	private final List<Message> _fixMessagesToMarket;
	private final List<Message> _fidessaMessages;
	private final FidessaMessageComparator _fidessaMessageComparator;
	
	public Order(final String orderId)
	{
		_orderId = orderId;
		_fixMessagesToClient = new LinkedList<>();
		_fixMessagesToMarket = new LinkedList<>();
		_fidessaMessages = new LinkedList<>();
		_fidessaMessageComparator = new FidessaMessageComparator();
	}
	
	public void add(final Message message, final MessageTarget target)
	{
		if(message.getType() == MessageType.FIX)
		{
			switch(target)
			{
				case CLIENT:
					_fixMessagesToClient.add(message);
					break;
				case MARKET:
					_fixMessagesToMarket.add(message);
			}
		}
		else if(message.getType() == MessageType.FIDESSA)
		{
			_fidessaMessages.add(message);
		}
	}
	
	public List<Diff> diff(final Order other, final ClOrdIDToATP clOrdIDToATP, final String clientId)
	{
		final List<Diff> result = new LinkedList<>();
		result.addAll(_diffFixMessages(_fixMessagesToClient, other._fixMessagesToClient, clOrdIDToATP, clientId));
		result.addAll(_diffFixMessages(_fixMessagesToMarket, other._fixMessagesToMarket, clOrdIDToATP, clientId));
		
		for(int i = 0; i < Math.max(_fidessaMessages.size(), other._fidessaMessages.size()); i++)
		{
			_fidessaMessageComparator
				.compare(_getMessage(i, _fidessaMessages), _getMessage(i, other._fidessaMessages))
				.forEach($ ->
				{
					$.setOrderId(_orderId);
					result.add($);
				});
		}
		return result;
	}
	
	List<Diff> _diffFixMessages(
		final List<Message> messagesOnThis,
		final List<Message> messagesOnOther,
		final ClOrdIDToATP clOrdIDToATP,
		final String clientId)
	{
		final List<Diff> result = new LinkedList<>();
		for(int i = 0; i < Math.max(messagesOnThis.size(), messagesOnOther.size()); i++)
		{
			new FIXMessageComparator(clOrdIDToATP)
				.compare(_getMessage(i, messagesOnThis), _getMessage(i, messagesOnOther), clientId)
				.forEach($ ->
				{
					$.setOrderId(_orderId);
					result.add($);
				});
		}
		return result;
	}
	
	Message _getMessage(final int index, final List<Message> list)
	{
		if(index < list.size())
		{
			return list.get(index);
		}
		return null;
	}
	
	public Optional<String> getLatestOutboundSourceRef()
	{
		if(_fidessaMessages.isEmpty()) return Optional.empty();
		return Optional.ofNullable(
			(String)FidessaReplayProcessor
				.toStructuredSet(_fidessaMessages.get(_fidessaMessages.size() - 1))
				.get("SOURCE_REF"));
	}
}
