package com.mizuhosc.selenium.verification;

import java.util.*;

public class TransactTimeComparator implements ComplexComparator
{
	private static final String _MSG_TYPE_TAG = "35";
	private static final String _FIX_VERSION_TAG = "8";
	public static final String TRANSACT_TIME_TAG = "60";

	@Override
	public ComparisonResult compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, final String clientId)
	{
		final String expectedTransactTime = expectedMap.get(TRANSACT_TIME_TAG);
		final String actualTransactTime = actualMap.get(TRANSACT_TIME_TAG);

		// We don't have FIX4.0 session anymore.
		// For FIX4.1, we will ignore the diff if tag 60 is in expected but not in actual.
		// Reason for this is Quattro doesn't set tag 60 for cancel reject
		final String fixVersion = actualMap.get(_FIX_VERSION_TAG);
		final String msgType = actualMap.get(_MSG_TYPE_TAG);
		if("FIX.4.1".equals(fixVersion) && "9".equals(msgType))
		{
			if(expectedTransactTime != null && actualTransactTime == null)
			{
				return ComparisonResult.matched();
			}
			return new FIXLooseTimestampFieldComparator().compare(expectedTransactTime, actualTransactTime);
		}
		return new FIXLooseTimestampFieldComparator().compare(expectedTransactTime, actualTransactTime);
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return TRANSACT_TIME_TAG;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(TRANSACT_TIME_TAG);
	}
	
}
