package com.mizuhosc.selenium.verification;

public class Diff
{
	public static final String CSV_HEADER =
		"OrderId,MessageType,Tag,Expected,Actual,Reason,Instrument,ExpectedFullMsg,ActualFullMsg";
	
	private String _orderId;
	private final String _messageType;
	private final String _tag;
	private final String _expected;
	private final String _actual;
	private final String _reason;
	private final String _instrument;
	private final String _expectedFullMsg;
	private final String _actualFullMsg;
	
	public Diff(
		final String orderId,
		final String messageType,
		final String tag,
		final String expected,
		final String actual,
		final String reason,
		final String instrument,
		final String expectedFullMsg,
		final String actualFullMsg)
	{
		_orderId = orderId;
		_messageType = messageType;
		_tag = tag;
		_expected = expected;
		_actual = actual;
		_reason = reason;
		_instrument = instrument;
		_expectedFullMsg = expectedFullMsg;
		_actualFullMsg = actualFullMsg;
	}
	
	public void setOrderId(final String orderId)
	{
		_orderId = orderId;
	}
	
	public static Diff missingOrder(final String orderId)
	{
		return new Diff(orderId, "ALL", "", "", "", "Missing order", "", "", "");
		
	}
	
	public static Diff unexpectedOrder(final String orderId)
	{
		return new Diff(orderId, "ALL", "", "", "", "Unexpected order", "", "", "");
	}
	
	public String toCsvLine()
	{
		return String.format(
			"%s,%s,%s,%s,%s,%s,%s,%s,%s",
			_orderId,
			_messageType,
			_tag,
			handleComma(_expected),
			handleComma(_actual),
			handleComma(_reason),
			_instrument,
			handleComma(_expectedFullMsg),
			handleComma(_actualFullMsg));
	}
	
	public static String handleComma(final String in)
	{
		if(in == null) return null;
		// When the column in csv has comma, add double quote to begin and end. And convert double quote to two double
		// quotes.
		if(in.contains(","))
		{
			return "\"" + in.replaceAll("\"", "\"\"") + "\"";
		}
		return in;
	}
	
}
