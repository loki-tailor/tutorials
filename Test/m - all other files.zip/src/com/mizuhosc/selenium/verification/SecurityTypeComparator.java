package com.mizuhosc.selenium.verification;

import java.util.*;

public class SecurityTypeComparator implements ComplexComparator
{
	private static final String _SECURITY_TYPE_TAG = "167";
	private static final String _ORD_STATUS_TAG = "39";
	private static final String _TARGET_COMP_ID_TAG = "56";
	private static final String _ORDER_ID_TAG = "37";
	private final List<String> _ignoreSessions = Arrays.asList(
		"JPNZQUICK1",
		"SBFIX",
		"SBFIXFS",
		"BLPTM_KIR",
		"INVESCO",
		"NYFXFEEZ",
		"SCHCRD",
		"BRANDES",
		"TTIN42",
		"TWARE",
		"POLUEGR",
		"TSGR",
		"JAMCRD",
		"ATRGR",
		"CAAM",
		"TSGRDSA",
		"FLXLNKAP",
		"LSEHub",
		"NYFXINTL",
		"ATRIOI",
		"DESHAW",
		"WMCPROD_AP",
		"CSD",
		"ITGA2",
		"METABITGR1",
		"FIDESSA",
		"CITADEL",
		"OPPEN",
		"POLUEDSA",
		"EPOCHIP",
		"METABITGR2",
		"FLEXLINK",
		"CITMIZASIA",
		"CFAMAP",
		"OHSTRS",
		"MFS",
		"ITGIOI",
		"ATRGR2",
		"ABBUYPW",
		"JPNZQUICK42",
		"PICTET",
		"STB",
		"NEUBGCRD",
		"BLKEMSAP",
		"ATRGR3",
		"ITGG",
		"VCMCRD",
		"INETMZHO",
		"FIDESSA2",
		"OAKTREE",
		"ULPROD",
		"SOROSCRD",
		"HANNA42",
		"FILCRDPRD",
		"POLUEIOI",
		"BAM",
		"ACIM",
		"LS1_AP_ALGO",
		"LS1_AP_DMA",
		"LS1_AP_DESK",
		"THORNBURG",
		"LAVADSA",
		"VIKING",
		"CCMCRD",
		"MOORECRD",
		"LAVA42",
		"LAVADISC",
		"KIWOOM",
		"ETRADE2",
		"NYFXFE42",
		"ULPROD1",
		"AAMCRD",
		"ATRGR4",
		"FEIMCRD",
		"JPMAMAP",
		"JPMAMAPIOI",
		"VALUECRD",
		"CBRECRD",
		"TSCM",
		"METABITGR3",
		"HARRISCRD",
		"NYX",
		"ANIMACRD",
		"CIINVCRD",
		"BLPTM_V9",
		"CAPG42",
		"CRMCG42",
		"CRMCW42",
		"DKPCRD",
		"NAMAPCRD",
		"FSICRD",
		"NOMAPCRD",
		"COPCAPCRD",
		"CFSCRD",
		"RIMCRD",
		"ATRSIOI",
		"PFGCRD");
	
	// Stores the list of orders that are in the ignored sessions and they got pending cancel/cancelled.
	// Doing this way, the following diff of 167 in execution report will be ignored(DFD ER).
	private static final Set<String> _ORDERS_TO_IGNORE_SECURITY_TYPE_DIFF = new HashSet<>();
	
	@Override
	public ComparisonResult compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, String clientId)
	{
		final String expected = expectedMap.get(_SECURITY_TYPE_TAG);
		final String actual = actualMap.get(_SECURITY_TYPE_TAG);
		if(new StringEqualsComparator().compare(expected, actual).matches()) return ComparisonResult.matched();
		final String targetCompId = actualMap.get(_TARGET_COMP_ID_TAG);
		final String ordStatus = actualMap.get(_ORD_STATUS_TAG);
		final String orderIdExpected = expectedMap.get(_ORDER_ID_TAG);
		if(expected != null &&
			actual == null &&
			_ignoreSessions.contains(targetCompId) &&
			("6".equals(ordStatus) ||
				"4".equals(ordStatus) ||
				_ORDERS_TO_IGNORE_SECURITY_TYPE_DIFF.contains(orderIdExpected)))
		{
			_ORDERS_TO_IGNORE_SECURITY_TYPE_DIFF.add(orderIdExpected);
			return ComparisonResult.matched();
		}
		return ComparisonResult.unmatch(null);
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return _SECURITY_TYPE_TAG;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(_SECURITY_TYPE_TAG);
	}
	
}
