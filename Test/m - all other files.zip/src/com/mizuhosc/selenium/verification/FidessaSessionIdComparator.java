package com.mizuhosc.selenium.verification;

public class FidessaSessionIdComparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null && actual == null)
		{
			return ComparisonResult.matched();
		}
		
		if(expected == null && actual != null)
		{
			return ComparisonResult.unmatch("unexpected");
		}
		
		if(expected != null && actual == null)
		{
			return ComparisonResult.unmatch("missing");
		}
		
		if(removeEnvPrefixAndDoubleQuotes(expected).equalsIgnoreCase(removeEnvPrefixAndDoubleQuotes(actual)))
		{
			return ComparisonResult.matched();
		}
		
		return ComparisonResult.unmatch(removeEnvPrefixAndDoubleQuotes(expected) +
			" vs " +
			removeEnvPrefixAndDoubleQuotes(actual));
	}
	
	String removeEnvPrefixAndDoubleQuotes(final String value)
	{
		final String withoutQuotes = value.replaceAll("\"", "");
		final int indexOfColon = withoutQuotes.indexOf(":");
		return indexOfColon < 0 ? withoutQuotes : withoutQuotes.substring(indexOfColon + 1);
	}
	
}
