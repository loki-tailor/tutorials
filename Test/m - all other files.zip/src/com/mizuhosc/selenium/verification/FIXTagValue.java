package com.mizuhosc.selenium.verification;

public class FIXTagValue
{
	private final String _number;
	private final String _value;
	
	public FIXTagValue(final String tag, final String value)
	{
		_number = tag;
		_value = value;
	}
	
	public String getNumber()
	{
		return _number;
	}
	
	public String getValue()
	{
		return _value;
	}
	
}
