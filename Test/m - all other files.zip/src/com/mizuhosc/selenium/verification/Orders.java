package com.mizuhosc.selenium.verification;

import static java.util.stream.Collectors.*;
import com.mizuhosc.quattro.util.function.*;
import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.log.*;
import com.mizuhosc.selenium.message.*;
import com.mizuhosc.selenium.replay.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import javax.annotation.*;

public class Orders
{
	// Map from orderId to messages of an order.
	// The key orderId here is without day number part. We don't expect client to repeat ClOrdID on the same day.
	private final Map<String, Order> _expected;
	private final Map<String, Order> _actual;
	
	// A mapping from ClOrdId to OrderId
	private final Map<String, String> _clOrdIDMapping;
	
	// A mapping from QuattroOrderId to OrderId.We can't directly use substring as QuattroOrderId's 2nd part is
	// SessionName, not SenderCompID
	private final Map<String, String> _quattroOrderIdToOrderId;
	private final QuattroOrderIdCache _idCache;
	
	private final ClOrdIDToATP _clOrdIDToATP;
	
	private final List<Message> _fixMessages = new ArrayList<>();
	
	public Orders(final QuattroOrderIdCache idCache, final ClOrdIDToATP clOrdIDToATP)
	{
		_expected = new ConcurrentHashMap<>();
		_actual = new ConcurrentHashMap<>();
		_clOrdIDMapping = new ConcurrentHashMap<>();
		_quattroOrderIdToOrderId = new ConcurrentHashMap<>();
		_idCache = idCache;
		_clOrdIDToATP = clOrdIDToATP;
	}
	
	public void addExpectedOrderMessages(final Message message)
	{
		_addOrderMessages(message, _expected, _DataType.EXPECTED);
	}
	
	public void addActualOrderMessages(final Message message)
	{
		if(message.getType() == MessageType.FIX)
		{
			_fixMessages.add(message);
		}
		_addOrderMessages(message, _actual, _DataType.ACTUAL);
	}
	
	private enum _DataType
	{
		EXPECTED,
		ACTUAL
	}
	
	private void _addOrderMessages(final Message message, final Map<String, Order> to, final _DataType type)
	{
		if(MessageType.FIX == message.getType())
		{
			_addFIXMessages(message, to, type);
		}
		else if(MessageType.FIDESSA == message.getType())
		{
			_addFidessaMessages(message, to);
		}
	}

	private void _addFIXMessages(final Message message, final Map<String, Order> to, final _DataType type)
	{
		final Map<String, String> m = FIXMessage.ParseUlBridgeLog(message.getRaw().get(0));
		final String clOrdID = m.get("11");
		final String targetCompID = m.get("56");
		final @Nullable String origClOrdID = m.get("41");
		final String msgType = m.get("35");
		String globalOrderIdWithoutDayNum = null;
		
		MessageTarget target = MessageTarget.CLIENT;
		// Messages on client sessions
		if("8".equals(msgType) || "9".equals(msgType))
		{
			globalOrderIdWithoutDayNum = _linkFixOrders(clOrdID, targetCompID, origClOrdID);
		}
		else if("D".equals(msgType) || "G".equals(msgType) || "F".equals(msgType))
		{
			// Only deal with ATP for now. QuattroOrderId in Quattro and GlobalOrderId in GOR.
			String systemOrderId = m.get("8053");
			if(systemOrderId == null)
			{
				final String lookupKey =
					type == _DataType.ACTUAL
						? origClOrdID
						: _clOrdIDToATP.getActualClOrdID(origClOrdID).orElse(null);
				
				// For the case in replay where order to market is not sent by OrderEngine somehow
				if(type == _DataType.EXPECTED && lookupKey == null)
				{
					globalOrderIdWithoutDayNum =
						_clOrdIDToATP.getOrderIdFromExpectedClOrdID(origClOrdID).orElse(null);
				}
				if(lookupKey != null)
				{
					systemOrderId = _idCache.getNewQuattroOrderId(lookupKey).orElse(null);
				}
			}
			
			if(globalOrderIdWithoutDayNum == null)
			{
				globalOrderIdWithoutDayNum = Optional
					.ofNullable(systemOrderId)
					.map($ -> $.substring($.indexOf(":") + 1))
					.orElse(null);
			}
			
			if(globalOrderIdWithoutDayNum != null)
			{
				if(type == _DataType.ACTUAL)
				{
					if(systemOrderId != null)
					{
						// Tag 11 to ATP is unique
						_idCache.mapNewQuattroOrderId(clOrdID, systemOrderId);
						
						// This is to map SenderCompID:ClOrdID in order request from client to QuattroOrderId
						// Required for ATP order's DFD replay
						_idCache.mapNewQuattroOrderId(globalOrderIdWithoutDayNum, systemOrderId);
					}
					
					_clOrdIDToATP.addActualClOrdID(clOrdID, globalOrderIdWithoutDayNum);
				}
				else
				{
					// Use Quattro's QuattroOrderId as the standard system order ID, because the session name will be
					// in all upper case, which is easy to converted to. If we use GOR's GlobalOrderId as the standard
					// one, it is difficult to convert from QuattroOrderId to GlobalOrderId, we can't replace session
					// name with SenderCompID, because SendCompID is "FDSA" when sending to ATP but not SendCompID of 
					// the client session.
					_clOrdIDToATP.addExpectedClOrdID(
						clOrdID,
						new QuattroOrderID(globalOrderIdWithoutDayNum).normalize());
				}
				
				target = MessageTarget.MARKET;
			}
		}
		
		if(globalOrderIdWithoutDayNum != null)
		{
			final Order orderMessages =
				to.computeIfAbsent(new QuattroOrderID(globalOrderIdWithoutDayNum).normalize(), Order::new);
			orderMessages.add(message, target);
		}
	}

	private void _addFidessaMessages(final Message message, final Map<String, Order> to)
	{
		final Map<String, String> m = FidessaMessageComparator.convertToMap(message.getRaw());
		// Example of ORIGINATOR_ORDER_ID: 1g:JASON:15012364811
		// Example of EXT_REF1: 15011340610::OETEST. We need to use the SenderCompID from EXT_REF1. In
		// QuattroOrderId, it's SessionName.
		String quattroOrderId = m.get("DETAILS.ORIGINATOR_ORDER_ID.s");// For TOP
		if(quattroOrderId == null)
		{
			quattroOrderId = m.get("XP_DATA.CUSTOM.EXT_REF2.s");// For JMIS
		}
		if(quattroOrderId == null)
		{
			final String omsOrderId = m.get("DETAILS.ORDER_ID.s").replaceAll("\"", "");
			quattroOrderId = _idCache.getQuattroOrderIdByOmsOrderId(omsOrderId).orElse(null);
			message.getRaw().add("DETAILS.ORIGINATOR_ORDER_ID.s = \"" + quattroOrderId + "\"");
		}
		quattroOrderId = quattroOrderId.replaceAll("\"", "");
		String orderId = _quattroOrderIdToOrderId.get(quattroOrderId);
		if(orderId == null)
		{
			// Make this final variable to use inside lambda below.
			final String finalQuattroId = quattroOrderId;
			orderId =
				Optional
					.ofNullable(_quattroOrderIdToOrderId.get(quattroOrderId))
					.orElseGet(() -> Optionals
						.firstNonEmpty(
							// For TOP
							() -> Optional.ofNullable(m.get("CUSTOM.EXT_REF1.s")),
							// For JMIS
							() -> Optional.ofNullable(m.get("XP_DATA.CUSTOM.EXT_REF1.s")))
						.map($ -> $.replaceAll("\"", ""))
						.map($ -> $.split("::"))
						// OrderId is clientRefId in this case. 
						.map(parts -> parts[0].contains(":")
							// For the case when clientRefId contains colon like "iAA0001:BAM", GOR handles it 
							// wrongly, making orderId like "iAA0001::FLEXLINK", which should actually be 
							// "iAA0001:BAM::FLEXLINK".
							? QuattroOrderIdCache.extractClientRefIdFromQuattorOrderId(finalQuattroId)
							: parts[1] + ":" + parts[0])
						// If No EXT_REF_1 in TXN_ORDER_COMPLETE
						.orElse(null));
			_quattroOrderIdToOrderId.put(quattroOrderId, orderId);
		}
		final Order orderMessages = to.computeIfAbsent(orderId, key -> new Order(key));
		orderMessages.add(message, MessageTarget.MARKET);
	}
	
	private String _linkFixOrders(final String clOrdID, final String targetCompID, final String origClOrdID)
	{
		final String key = targetCompID + ":" + clOrdID;
		String value = _clOrdIDMapping.get(key);
		if(value != null)
		{
			return value;
		}
		if(origClOrdID != null)
		{
			final String oldKey = targetCompID + ":" + origClOrdID;
			final String oldValue = _clOrdIDMapping.get(oldKey);
			if(oldValue != null)
			{
				_clOrdIDMapping.put(key, oldValue);
				value = oldValue;
			}
			else
			{
				Log.info("No mapping for " + oldKey);
				value = key;
			}
		}
		else
		{
			_clOrdIDMapping.put(key, key);
			value = key;
		}
		return value;
	}
	
	public void reportDiff(final String inputFileName) throws Exception
	{
		Log.info("Starts to report diff for file %s", inputFileName);
		
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		final File diffDirectory = new File("diffs");
		if(!diffDirectory.exists())
		{
			diffDirectory.mkdir();
		}
		final String clientId = inputFileName.substring(0, inputFileName.indexOf("."));
		final String reportFileName = "diffs/ReplayDiff_" + clientId + "_" + sdf.format(new Date()) + ".csv";
		try(final BufferedWriter writer =
			new BufferedWriter(new OutputStreamWriter(new FileOutputStream(reportFileName))))
		{
			writer.write(Diff.CSV_HEADER);
			writer.newLine();
			final Set<String> keys = new HashSet<>();
			keys.addAll(_expected.keySet());
			keys.addAll(_actual.keySet());
			for(final String orderId: keys)
			{
				final Order expected = _expected.get(orderId);
				final Order actual = _actual.get(orderId);
				if(expected != null && actual != null)
				{
					Log.info("Getting diff for order %s", orderId);
					final List<Diff> diff = expected.diff(actual, _clOrdIDToATP, clientId);
					for(final Diff line: diff)
					{
						writer.write(line.toCsvLine());
						writer.newLine();
					}
				}
				else if(expected != null && actual == null)
				{
					writer.write(Diff.missingOrder(orderId).toCsvLine());
					writer.newLine();
				}
				else if(expected == null && actual != null)
				{
					writer.write(Diff.unexpectedOrder(orderId).toCsvLine());
					writer.newLine();
				}
			}
		}
		
		Log.info("Finished reporting diff for file %s", inputFileName);
	}
	
	public void generateOnewayOutbound(final String onewayType) throws FileNotFoundException, IOException
	{
		Log.info("Starts to generate %s FIX outbound message file...", onewayType);
		
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		final File diffDirectory = new File(onewayType);
		if(!diffDirectory.exists())
		{
			diffDirectory.mkdir();
		}
		
		final String fixOutputFile = String.format("%s/FIX_outbound_%s.txt", onewayType, sdf.format(new Date()));
		try(final BufferedWriter writer =
			new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fixOutputFile))))
		{
			for(final Message message: _fixMessages)
			{
				writer.write(new FIXMessage(message.getRaw().get(0)).raw);
				writer.newLine();
			}
		}
		
		Log.info("Finished generating %s FIX outbound message file %s", onewayType, fixOutputFile);
	}
	
	public void reportOnewayDiff(final File inputFile) throws FileNotFoundException, IOException
	{
		final String inputFilePath = inputFile.getAbsolutePath();
		Log.info("Starts to generate oneway diff for file %s ...", inputFilePath);
		
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
		final File diffDirectory = new File("diffs");
		if(!diffDirectory.exists())
		{
			diffDirectory.mkdir();
		}
		
		final String inputFileName = inputFile.getName();
		final String clientId = inputFileName.substring(0, inputFileName.indexOf("."));
		final String reportFilePath =
			String.format("diffs/ReplayOnewayDiff_%s_%s.csv", clientId, sdf.format(new Date()));
		
		final List<FIXMessage> expectedFIXMessages = _extractFIXMessages(inputFile);
		final List<FIXMessage> actualFIXMessages = _fixMessages.stream().map(Message::toFIXMessage).collect(toList());
		
		new FIXDiff("37", reportFilePath).diff(expectedFIXMessages, actualFIXMessages);
		
		Log.info("Finished generating oneway diff to file %s", reportFilePath);
	}

	private static List<FIXMessage> _extractFIXMessages(final File inputFile)
		throws FileNotFoundException,
		IOException
	{
		final List<FIXMessage> expectedFIXMessages = new ArrayList<>();
		final InputStream inputStream = new FileInputStream(inputFile);
		try(final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream)))
		{
			@Nullable String line = null;
			do
			{
				line = reader.readLine();
				// Filter out non FIX messages.
				if(line != null && line.contains("8=FIX."))
				{
					expectedFIXMessages.add(new FIXMessage(line));
				}
			}
			while(line != null);
		}
		return expectedFIXMessages;
	}
	
	public Optional<String> getLatestOutboundSourceRef(final String orderId)
	{
		return Optional
			.ofNullable(orderId)
			.map($ -> _actual.get($))
			.flatMap($ -> $.getLatestOutboundSourceRef());
	}
	
}
