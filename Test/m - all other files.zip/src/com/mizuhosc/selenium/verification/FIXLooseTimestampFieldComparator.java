package com.mizuhosc.selenium.verification;

import java.text.*;

/**
 * Compares UTCTimestamp in that actual has same length with expected, and is with valid FIX Timestamp format.
 */
public class FIXLooseTimestampFieldComparator implements FieldComparator
{

	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null)
		{
			if(actual == null)
			{
				return ComparisonResult.matched();
			}
			return ComparisonResult.unmatch(null);
		}
		
		//expected !=null below
		if(actual == null)
		{
			return ComparisonResult.unmatch(null);
		}
		
		//both expected and actual not null
		if(expected.length() != actual.length())
		{
			return ComparisonResult.unmatch("time field length different");
		}
		
		//Validate that it's of correct FIX time format
		if(_SHORT_UTC_TIMESTAMP.length() == actual.length())
		{
			try
			{
				_SHORT_FORMATTER.get().parse(actual);
			}
			catch(final ParseException e)
			{
				return ComparisonResult.unmatch("invalid value, format should be yyyyMMdd-HH:mm:ss");
			}
		}
		else
		{
			try
			{
				_LONG_FORMATTER.get().parse(actual);
			}
			catch(final ParseException e)
			{
				return ComparisonResult.unmatch("invalid value, format should be yyyyMMdd-HH:mm:ss.SSS");
			}
		}

		//Return matched if actual is in correct format. We are not going to compare the value
		return ComparisonResult.matched();
	}
	
	static final String _SHORT_UTC_TIMESTAMP = "yyyyMMdd-HH:mm:ss";
	static final String _LONG_UTC_TIMESTAMP = "yyyyMMdd-HH:mm:ss.SSS";
	static final ThreadLocal<SimpleDateFormat> _SHORT_FORMATTER = new ThreadLocal<SimpleDateFormat>()
	{
		@Override
		protected SimpleDateFormat initialValue()
		{
			final SimpleDateFormat format = new SimpleDateFormat(_SHORT_UTC_TIMESTAMP);
			format.setLenient(false);
			return format;
		}
	};
	static final ThreadLocal<SimpleDateFormat> _LONG_FORMATTER = new ThreadLocal<SimpleDateFormat>()
	{
		@Override
		protected SimpleDateFormat initialValue()
		{
			final SimpleDateFormat format = new SimpleDateFormat(_LONG_UTC_TIMESTAMP);
			format.setLenient(false);
			return format;
		}
	};
}
