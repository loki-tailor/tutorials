package com.mizuhosc.selenium.verification;

import static com.mizuhosc.quattro.util.DelimitedString.*;
import static java.util.stream.Collectors.*;
import com.mizuhosc.quattro.util.function.*;
import java.util.*;
import java.util.stream.*;
import javax.annotation.*;

public class ConditionallyIgnoreComparator implements ComplexComparator
{
	private final String _tag;
	private final List<String> _conditions;
	
	// null conditions means there are no conditions.
	public ConditionallyIgnoreComparator(final @Nullable String conditions, final String tag)
	{
		_conditions = Optionals.streamNullables(conditions).flatMap(splitBy(",")).collect(toList());
		_tag = tag;
	}
	
	@Override
	public ComparisonResult compare(
		final Map<String, String> expectedMap,
		final Map<String, String> actualMap,
		final String gorClientId)
	{
		// The conditions can be defined multiple with logic OR and then AND. e.g.
		// conditions=35=8;150=A,35=9
		return _conditions
			.stream()
			.anyMatch(orConditions -> Stream.of(orConditions).flatMap(splitBy(";")).allMatch(entry ->
			{
				final String[] keyValuePairs = entry.split("=");
				final String key = keyValuePairs[0];
				final String value = keyValuePairs[1];
				return value.equals(expectedMap.get(key));
			}))
			? ComparisonResult.matched()
				: new StringEqualsComparator().compare(expectedMap.get(_tag), actualMap.get(_tag));
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return _tag;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(_tag);
	}
}
