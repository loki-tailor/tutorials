package com.mizuhosc.selenium.verification;

import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.ioi.*;
import java.util.*;
import java.util.concurrent.*;

public class IOIComparator
{
	
	private final static Map<String, FieldComparator> _staticSimpleComparators = new ConcurrentHashMap<>();
	
	static
	{
		Configuration.SINGLETON
			.getValues("FIX.tags.existenceCompare")
			.forEach($ -> _staticSimpleComparators.put($, new ExistenceComparator()));
		Configuration.SINGLETON
			.getValues("FIX.tags.numberCompare")
			.forEach($ -> _staticSimpleComparators.put($, new NumberComparator()));
		
		final Set<String> tagsToIgnore = new HashSet<>();
		tagsToIgnore.addAll((Configuration.SINGLETON.getValues("FIX.tags.ignore")));
		tagsToIgnore.add("23");
		tagsToIgnore.add("26");
		tagsToIgnore.forEach($ -> _staticSimpleComparators.put($, new IgnoreComparator()));
		
		_staticSimpleComparators.put("62", new Tag62Comparator());
		
		Configuration.SINGLETON
			.getValues("FIX.tags.looseTimeCompare")
			.forEach($ -> _staticSimpleComparators.put($, new FIXLooseTimestampFieldComparator()));
		
	}
	
	public List<IOIDiff> compare(final IOIIDWithVersion ioiIDWithVersion, final IOI expected, final IOI actual)
	{
		final List<IOIDiff> result = new LinkedList<>();
		final Set<String> allKeys = new HashSet<>();
		allKeys.addAll(expected.getAllKeys());
		allKeys.addAll(actual.getAllKeys());
		for(final String key: allKeys)
		{
			final FieldComparator comparator = _staticSimpleComparators.computeIfAbsent(
				key,
				$ -> new StringEqualsComparator());
			final String expectedTagValue = expected.getNonRepeatingValue(key);
			final String actualTagValue = actual.getNonRepeatingValue(key);
			final ComparisonResult cr = comparator.compare(expectedTagValue, actualTagValue);
			if(!cr.matches())
			{
				final IOIDiff diff = new IOIDiff(
					ioiIDWithVersion,
					key,
					expectedTagValue,
					actualTagValue,
					cr.getReason().orElse(null),
					expected.getNonRepeatingValue("55"),
					expected.getRaw(),
					actual.getRaw());
				result.add(diff);
			}
		}
		
		return result;
	}
}
