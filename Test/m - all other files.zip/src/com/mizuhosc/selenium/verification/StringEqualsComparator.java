package com.mizuhosc.selenium.verification;

/**
 * Compares fields values for string equality.
 */
public class StringEqualsComparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null)
		{
			if(actual == null)
			{
				return ComparisonResult.matched();
			}
			return ComparisonResult.unmatch(null);
		}
		
		if(expected.equals(actual))
		{
			return ComparisonResult.matched();
		}
		return ComparisonResult.unmatch(null);
	}
	
}
