package com.mizuhosc.selenium.verification;

import java.time.format.*;

/**
 * Checks that a date field has the correct format (yyyyMMdd HH:mm:ss.SSSSSS Z).
 *
 */
public final class FidessaDateTimeComparator implements FieldComparator
{

	final DateTimeFormatter _datetimeFormat = DateTimeFormatter.ofPattern("\"yyyyMMdd HH:mm:ss.SSSSSS Z\"");

	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null && actual == null)
		{
			return ComparisonResult.matched();
		}

		if(expected == null && actual != null)
		{
			return ComparisonResult.unmatch("unexpected");
		}

		if(expected != null && actual == null)
		{
			return ComparisonResult.unmatch("missing");
		}

		try
		{
			_datetimeFormat.parse(actual);
		}
		catch(final DateTimeParseException e)
		{
			return ComparisonResult.unmatch("wrong format");
		}

		// the correct format
		return ComparisonResult.matched();
	}

}
