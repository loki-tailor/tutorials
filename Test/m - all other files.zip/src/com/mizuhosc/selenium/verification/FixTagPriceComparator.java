package com.mizuhosc.selenium.verification;

import java.util.*;

// Ignore diff if expected is 0 and actual is null and order type is market.
public class FixTagPriceComparator implements ComplexComparator
{
	private static final String _ORDTYPE_TAG = "40";
	public static final String PRICE_TAG = "44";
	
	@Override
	public ComparisonResult compare(final Map<String, String> expectedMap, final Map<String, String> actualMap, String clientId)
	{
		final String expected = expectedMap.get(PRICE_TAG);
		final String actual = actualMap.get(PRICE_TAG);
		if(new StringEqualsComparator().compare(expected, actual).matches()) return ComparisonResult.matched();
		final String expectedOrdType = expectedMap.get(_ORDTYPE_TAG);
		final String actualOrdType = actualMap.get(_ORDTYPE_TAG);
		if("1".equals(expectedOrdType) && "1".equals(actualOrdType) && "0".equals(expected) && actual == null)
		{
			return ComparisonResult.matched();
		}
		return ComparisonResult.unmatch(null);
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return PRICE_TAG;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(PRICE_TAG);
	}
	
}
