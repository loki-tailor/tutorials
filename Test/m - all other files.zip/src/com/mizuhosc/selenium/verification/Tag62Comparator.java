package com.mizuhosc.selenium.verification;

/**
 * Compares fields values for tag 62 equality.
 */
public class Tag62Comparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null)
		{
			if(actual == null)
			{
				return ComparisonResult.matched();
			}
			return ComparisonResult.unmatch(null);
		}
		
		if(expected.replaceAll("\\.\\d{3}$", "").equals(actual))
		{
			return ComparisonResult.matched();
		}
		return ComparisonResult.unmatch(null);
	}
	
}
