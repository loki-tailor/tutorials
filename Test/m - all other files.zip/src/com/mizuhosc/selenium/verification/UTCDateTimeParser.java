package com.mizuhosc.selenium.verification;

import com.mizuhosc.quattro.util.function.*;
import org.joda.time.*;
import org.joda.time.format.*;

public class UTCDateTimeParser
{
	private final DateTime _dateTimeInUTC;
	
	public UTCDateTimeParser(final String utcDateTime)
	{
		_dateTimeInUTC = Result
			.attempt(() -> DateTimeFormat
				.forPattern("yyyyMMdd-HH:mm:ss.SSS")
				.withZoneUTC()
				.parseDateTime(utcDateTime))
			.orElseGet(() -> DateTimeFormat
				.forPattern("yyyyMMdd-HH:mm:ss")
				.withZoneUTC()
				.parseDateTime(utcDateTime));
	}
	
	public String formatDateOfJapan()
	{
		return DateTimeFormat.forPattern("yyyyMMdd").withZone(DateTimeZone.forID("Japan")).print(_dateTimeInUTC);
	}
}
