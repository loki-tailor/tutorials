package com.mizuhosc.selenium.verification;

public class IgnoreComparator implements FieldComparator
{
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		return ComparisonResult.matched();
	}
}
