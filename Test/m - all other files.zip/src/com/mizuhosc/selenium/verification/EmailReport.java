package com.mizuhosc.selenium.verification;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.functionlibraries.CommonFunctions;

public class EmailReport {

	// private static final String SELENIUM_ENVIRONMENT = "QA10";
	// private static final String JIRA_NUMBER = "QTR-11279";
	private static final String testResultPassMessage = "No exceptions in any counterparty or alert logs And also Email reports generated are correct";

	private boolean marathonResult = false;
	private int rowCount = 0;
//	public WebDriver driver; // Selects appropraite driver
	private WebDriver driverUpdateResult;

	private static final String SeleniumAutomation_RunEmailReport_batPath = Configuration.SINGLETON
			.getProperty("selenium.Automation.RunEmailReport.path");
	
	private static final String AlertsBeforeUpdate = Configuration.SINGLETON
			.getProperty("selenium.Exception.AlertsBeforeUpdate");
	private static final String CounterpartyBeforeUpdate = Configuration.SINGLETON
			.getProperty("selenium.Exception.CounterpartyBeforeUpdate");
	private static final String AlertsAfterUpdate = Configuration.SINGLETON
			.getProperty("selenium.Exception.AlertsAfterUpdate");
	private static final String CounterpartyAfterUpdate = Configuration.SINGLETON
			.getProperty("selenium.Exception.CounterpartyAfterUpdate");
	private static final String AlertsAfterRevert = Configuration.SINGLETON
			.getProperty("selenium.Exception.AlertsBeforeRevert");
	private static final String CounterpartyAfterRevert = Configuration.SINGLETON
			.getProperty("selenium.Exception.CounterpartyAfterRevert");

	private static final String DiffLimitChangeReportBeforeUpdate = Configuration.SINGLETON
			.getProperty("selenium.Email.DiffLimitChangeReportBeforeUpdate");
	private static final String DiffEODLimitChangeReportBeforeUpdate = Configuration.SINGLETON
			.getProperty("selenium.Email.DiffEodLimitChangeReportBeforeUpdate");
	private static final String DiffLimitChangeReportAfterUpdate = Configuration.SINGLETON
			.getProperty("selenium.Email.DiffLimitChangeReportAfterUpdate");
	private static final String DiffEODLimitChangeReportAfterUpdate = Configuration.SINGLETON
			.getProperty("selenium.Email.DiffEodLimitChangeReportAfterUpdate");
	private static final String DiffLimitChangeReportAfterRevert = Configuration.SINGLETON
			.getProperty("selenium.Email.DiffLimitChangeReportBeforeRevert");
	private static final String DiffEODLimitChangeReportAfterRevert = Configuration.SINGLETON
			.getProperty("selenium.Email.DiffEodLimitChangeReportAfterRevert");
	
	int flag = 1;

	public String testResultFailedMessage = new String();

	@Parameters({ "username", "password", "quattroEnv", "browser", "caseID", "SELENIUM_ENVIRONMENT", "JIRA_NUMBER" ,"ClientSesionXpath" ,"PluginActionServer" ,"PluginName" ,"PluginParamterXpath" ,"PluginParamterValue_First" ,"PluginParamterValue_Second" ,"PluginTabXpath"})
	@Test
	public void EmailReport(final String user, String pass, String monEnv, final String browser, final int caseID,
			final String SELENIUM_ENVIRONMENT, final String JIRA_NUMBER ,final String ClientSesionXpath,final String PluginActionServer,final String PluginName,final String PluginParamterXpath, final String PluginParamterValue_First ,final String PluginParamterValue_Second,final String PluginTabXpath) throws IOException, InterruptedException {

		// SendEmailReport BeforeUpdate
		
		SendEmailReport("BeforeUpdate");
		Thread.sleep(80000);
		CheckExceptions("BeforeUpdate", "alerts", AlertsBeforeUpdate);
		CheckExceptions("BeforeUpdate", "counterparty", CounterpartyBeforeUpdate);
		CheckEmailFile("BeforeUpdate","limit-change-report",DiffLimitChangeReportBeforeUpdate);
		CheckEmailFile("BeforeUpdate","eod-limit-change-report",DiffEODLimitChangeReportBeforeUpdate);

		//	 Selenium updates Client
		
		Reporter.log(String.format("[%s UPDATE:] In updating Plugin block", CommonFunctions.getTimeStamp()), true);
		WebDriver driverFirstChange=CommonFunctions.DriverInvoke(browser);
		CommonFunctions.LoginToMonitoringSystem(  driverFirstChange, user, pass, monEnv);
		CommonFunctions.NavigateClientSession(driverFirstChange, ClientSesionXpath ,PluginActionServer);
        CommonFunctions.EditScreen(driverFirstChange,PluginActionServer);
        CommonFunctions.SelectPluginTab(driverFirstChange,PluginTabXpath);
        CommonFunctions.UpdatePlugin(driverFirstChange, PluginName ,PluginActionServer,PluginParamterXpath,PluginParamterValue_First);
        CommonFunctions.SaveChanges(driverFirstChange,PluginActionServer,PluginParamterValue_First);
        CommonFunctions.CloseDriver(driverFirstChange);
//		UpdateRevertClient(user, pass, monEnv, browser, "10");
        
		// SendEmailReport AfterUpdate
	
		SendEmailReport("AfterUpdate");
		Thread.sleep(80000);
		CheckExceptions("AfterUpdate", "alerts", AlertsAfterUpdate);
		CheckExceptions("AfterUpdate", "counterparty", CounterpartyAfterUpdate);
		CheckEmailFile("AfterUpdate","limit-change-report",DiffLimitChangeReportAfterUpdate);
		CheckEmailFile("AfterUpdate","eod-limit-change-report",DiffEODLimitChangeReportAfterUpdate);

    	// Selenium reverts Client
	
		Reporter.log(String.format("[%s UPDATE:] In updating Plugin block", CommonFunctions.getTimeStamp()), true);
		WebDriver driverSecondChange=CommonFunctions.DriverInvoke(browser);
		CommonFunctions.LoginToMonitoringSystem( driverSecondChange, user, pass, monEnv);
		CommonFunctions.NavigateClientSession(driverSecondChange, ClientSesionXpath ,PluginActionServer);
        CommonFunctions.EditScreen(driverSecondChange,PluginActionServer);
        CommonFunctions.SelectPluginTab(driverSecondChange,PluginTabXpath);
        CommonFunctions.UpdatePlugin(driverSecondChange, PluginName ,PluginActionServer,PluginParamterXpath,PluginParamterValue_Second);
        CommonFunctions.SaveChanges(driverSecondChange,PluginActionServer,PluginParamterValue_Second);
        CommonFunctions.CloseDriver(driverSecondChange);
//		UpdateRevertClient(user, pass, monEnv, browser, "100");

		
        
    	// SendEmailReport AfterRevert
        SendEmailReport("AfterRevert");
		Thread.sleep(80000);
		CheckExceptions("AfterRevert", "alerts", AlertsAfterRevert);
		CheckExceptions("AfterRevert", "counterparty", CounterpartyAfterRevert);
		CheckEmailFile("AfterRevert","limit-change-report",DiffLimitChangeReportAfterRevert);
		CheckEmailFile("AfterRevert","eod-limit-change-report",DiffEODLimitChangeReportAfterRevert);
		
		//System.out.println(testResultFailedMessage);

		UpdateResult(user, pass, monEnv, browser, caseID, SELENIUM_ENVIRONMENT, JIRA_NUMBER);

	}

	private void SendEmailReport(String eventType) throws IOException, InterruptedException {

		Runtime.getRuntime()
				.exec(new String[] { "cmd", "/c", "start " + SeleniumAutomation_RunEmailReport_batPath, eventType });
		System.out.println("Exiting from Email report window bat file");
		Reporter.log(String.format("[..%s Email Report sent] Exiting from Email report window bat file : %s ",
				getTimeStamp(), eventType, true));
		Thread.sleep(8000);

	}

	public void CheckExceptions(String EventType, String serverName, String filePath)
			throws IOException, InterruptedException {

		try {
			System.out.println("Checking for the Exception in : " + serverName + " " + EventType);
			Reporter.log(String.format("[..%s Exception finding] Checking for the Exception in :%s %s", getTimeStamp(),
					serverName, EventType, true));
			System.out.println("--Checking in file :" + filePath + "--");
			Reporter.log(String.format("[..%s Exception finding] --Checking in file : %s--", getTimeStamp(),
					filePath, true));
			CountRows(filePath);
			if (rowCount == 0) {
				System.out.println("No exception in " + serverName + " in " + EventType + " Logs");
				Reporter.log(String.format("No exception in %s in %s Logs",serverName,EventType, true));

			} else {
				flag = 0;
				System.out.println("Exception in " + serverName + " in " + EventType + " Logs");
				Reporter.log(String.format("Exception in %s in %s Logs",serverName,EventType, true));
				testResultFailedMessage = testResultFailedMessage + "|" + "Exception in " + serverName + EventType;
			}

			// Reset the rowcount again
			rowCount = 0;
		} catch (IOException e) {
			Reporter.log(
					String.format("[%s Error- File check] ERROR Found %s Exception while checking exception file",
							getTimeStamp(), e.getMessage()));
			flag = 0;
			System.out.println("Error/Exception:" +e.getMessage());
			testResultFailedMessage = testResultFailedMessage + "|" + "Exception while checking: " + serverName + EventType;
			
		}

	}

	// String testResultFailedMessage=testResultMessageFailed1+
	// testResultMessageFailed2 + testResultMessageFailed3
	// + testResultMessageFailed4 + testResultMessageFailed5
	// + testResultMessageFailed6;
	// return testResultFailedMessage;
	public void CheckEmailFile(String EventTypeForMail, String EmailSubject, String EmailDiffFilePath)
			throws IOException, InterruptedException {

		try {
			System.out.println("Checking for the difference in : " + EmailSubject + " " + EventTypeForMail);
			Reporter.log(String.format("[..%s Difference finding in email report] Checking for the diffs in :%s %s", getTimeStamp(),
					EmailSubject, EventTypeForMail, true));
			Reporter.log(String.format("Email File is located in E:/Selenium.Automation/Emails/jainsank.%s.%s.Actual",EmailSubject,EventTypeForMail,true));
			System.out.println("--Checking in file :" + EmailDiffFilePath + "--");
			Reporter.log(String.format("--Checking in file :%s --",EmailDiffFilePath , true));
			CountRows(EmailDiffFilePath);
			if (rowCount == 0) {
				//System.out.println("No diff found in " + EmailSubject + " in " + EventTypeForMail + " diff file");
				System.out.println("No diff found in" +  EventTypeForMail + " event for " + EmailSubject + " report ");
				Reporter.log(String.format("No diff found in %s event for %s report",EventTypeForMail,EmailSubject,true));

			} else {
				flag = 0;
				System.out.println("Email Report for <" + EmailSubject + "><" + EventTypeForMail + ">is not Correct");
				Reporter.log(String.format("Email Report for <%s><%s>is not Correct",EmailSubject,EventTypeForMail , true));
				testResultFailedMessage = testResultFailedMessage + "|" + "Email Report for <" + EmailSubject + "><" + EventTypeForMail + ">is not Correct";
			}

			// Reset the rowcount again
			rowCount = 0;
		} catch (Exception e) {
			Reporter.log(
					String.format("[%s Error while checking email report] ERROR Found: %s Exception while checking diff file for Email report",
							getTimeStamp(), e.getMessage()));
			flag = 0;
			System.out.println("Error/Exception:" +e.getMessage());
			testResultFailedMessage = testResultFailedMessage + "|" + "Exception while checking: "+ EmailSubject + EventTypeForMail;
			
		
		}

	}
	
	
	
	private static String getTimeStamp() {
		return new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	}

	public void CountRows(final String fileName) throws IOException {
		final BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
		String input;
		while ((input = bufferedReader.readLine()) != null) {
			rowCount++;
		}
		System.out.println("Number of rows= " + rowCount);
		Reporter.log(String.format("Number of rows= %d",rowCount, true));
		bufferedReader.close();
	}

	public void UpdateResult(String user, String pass, String monenv, String browser, final int caseId,
			String SELENIUM_ENVIRONMENT, String JIRA_NUMBER) {
		try {

			if (flag == 1) 
			{
				marathonResult = true;
				System.out.println("Test case is passed and No exception in any log");

			}
			// testResult();// setting test result message based on File and UI
			// checks

			Reporter.log(String.format("[%s Marathon] Updating Marathon test result.", getTimeStamp()), true);
			// Get release version for QA10- from release version dash board and
			// update Marathon case
			driverUpdateResult = new ChromeDriver();
			driverUpdateResult.get("http://tkqtrapq2:8000/FidessaConnectivity.html");

			System.out.println("chrome invoked");
			final WebElement fetchData = driverUpdateResult
					.findElement(By.xpath("//*[@id='env-status']/tbody/tr/td[1][contains(.,'QA10')]//..//td[2]"));
			CharSequence releaseVersion = fetchData.getText();
			System.out.println("Release is being checked");
			releaseVersion = releaseVersion.subSequence(3, 9).toString();
			Reporter.log(String.format("Release version %s ruuning on %s.", releaseVersion, SELENIUM_ENVIRONMENT));

			driverUpdateResult.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + caseId);
			Reporter.log("Current time is :" + Calendar.getInstance(), true);
			driverUpdateResult.findElement(By.name("username")).sendKeys(user);
			driverUpdateResult.findElement(By.name("password")).sendKeys(pass);
			driverUpdateResult.findElement(By.name("username")).submit();
			Thread.sleep(1000);

			driverUpdateResult.findElement(By.xpath("//*[contains(text(),'Enter Result')]")).click();
			Thread.sleep(1000);

			driverUpdateResult.findElement(By.xpath("//*[contains(text(),'Edit')]")).click();

			if (marathonResult) {
				driverUpdateResult.findElement(By.xpath("//*[contains(text(),'Passed')]")).click();
				driverUpdateResult.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input"))
						.sendKeys(String.format("%s on %s %s", testResultPassMessage, SELENIUM_ENVIRONMENT,
								releaseVersion));
				driverUpdateResult.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input"))
						.sendKeys(JIRA_NUMBER);
				driverUpdateResult.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
				Thread.sleep(3000);
				Reporter.log("Marathon testcase passed", true);
			} else {
				driverUpdateResult.findElement(By.xpath("//*[contains(text(),'Failed')]")).click();
				// String testResultFailedMessage=testResultMessageFailed1+
				// testResultMessageFailed2 + testResultMessageFailed3
				// + testResultMessageFailed4 + testResultMessageFailed5
				// + testResultMessageFailed6;
				System.out.println(testResultFailedMessage);
				driverUpdateResult.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input"))
						.sendKeys(String.format("%s on %s %s", testResultFailedMessage, SELENIUM_ENVIRONMENT,
								releaseVersion));

				driverUpdateResult.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input"))
						.sendKeys(JIRA_NUMBER);
				driverUpdateResult.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
				Thread.sleep(3000);
				Reporter.log("Marathon testcase failed", true);

			}
			Reporter.log("[Marathon] Marathon test result updated.", true);
			driverUpdateResult.close();
		} catch (final Exception e) {
			Reporter.log(String.format("[%s Marathon] ERROR %s Exception found when updating Marathon test result.",
					getTimeStamp(), e.getMessage()));

			driverUpdateResult.close();
		}
	}

//	public void UpdateRevertClient(String user, String pass, String monenv, String browser, String ValueLimit)
//			throws InterruptedException {
//		// TODO Auto-generated method stub
//		// Navigate to client page
//		driver = new ChromeDriver();
//		driver.get("http://" + monenv + ".mizuho-sc.com:9050/client/146");
//		Reporter.log("Current time is :" + Calendar.getInstance(), true);
//		driver.findElement(By.name("username")).sendKeys(user);
//		driver.findElement(By.name("password")).sendKeys(pass);
//		driver.findElement(By.name("username")).submit();
//		Thread.sleep(1000);
//		Reporter.log(String.format("[..%s Editing plugin] Changing value in the plugin ", true));
//		// click on Edit button
//		WebElement EditButton = driver.findElement(By.xpath(
//				"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Value Limit Validator')]/../.././/*[@class='q-attachment-buttons']/*[@class='edit-q-attachment']"));
//		EditButton.click();
//		
//		// Add value in first text feild of plugin
//		WebElement TypeOfFlow = driver.findElement(By.xpath(
//				"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Value Limit Validator')]/../.././/*[@class='q-attachment-wrapper']/table/tbody/tr[1]/td[2]/input"));
//		TypeOfFlow.clear();
//		Actions action = new Actions(driver);
//		action.moveToElement(TypeOfFlow);
//		action.click();
//		action.sendKeys("DMA");
//		action.build().perform();
//		System.out.println("updated type of flow text field on client");
//		// Add value in second text feild
//		WebElement OrderValueLimit = driver.findElement(By.xpath(
//				"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Value Limit Validator')]/../.././/*[@class='q-attachment-wrapper']/table/tbody/tr[1]/td[4]/input"));
//		// OrderValueLimit.clear();
//		action.moveToElement(OrderValueLimit);
//
//		action.click();
//		// action.keyDown(Keys.CONTROL)
//		// .sendKeys(Keys.chord("A"))
//		// .keyUp(Keys.CONTROL)
//		// .perform();
//		// Thread.sleep(1000);
//		// action.sendKeys(Keys.DELETE);
//
//		System.out.println("ValueLimit " + ValueLimit);
//		// action.sendKeys(ValueLimit);
//		action.sendKeys(Keys.chord(Keys.CONTROL, "a"), ValueLimit);
//		action.build().perform();
//
//		System.out.println("updated value feild on client");
//		// Click on save button
//		WebElement SaveButton = driver.findElement(By.xpath(
//				"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Value Limit Validator')]/../../..//*[@class='q-attachment-buttons']//*[@class='save-q-attachment']"));
//		SaveButton.click();
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		WebElement MsgBoxText = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-content']/textarea"));
//		MsgBoxText.sendKeys("Put limit value:" + ValueLimit);
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		// click on ok button on dialogue box..
//		WebElement MsgBoxTextOk = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-control-button']/../q-button[@dialog-action='ok']"));
//		MsgBoxTextOk.click();
//
//		try {
//			Thread.sleep(8000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		driver.close();
//
//	}

}
