package com.mizuhosc.selenium.verification;

public class OrderIdComparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null && actual == null)
		{
			return ComparisonResult.matched();
		}
		
		if(expected == null && actual != null)
		{
			return ComparisonResult.unmatch("unexpected");
		}
		
		if(expected != null && actual == null)
		{
			return ComparisonResult.unmatch("missing");
		}
		
		final int indexOfColonInExpected = expected.indexOf(':');
		final int indexOfColonInActual = actual.indexOf(':');
		if(indexOfColonInActual < 0 && indexOfColonInExpected >= 0 ||
			indexOfColonInExpected < 0 && indexOfColonInActual >= 0)
		{
			return ComparisonResult.unmatch("format different with :");
		}

		// Both the OrderID(37)s don't have colon, probably ShortenOrderId applied
		if(indexOfColonInActual < 0 && indexOfColonInExpected < 0 && !expected.equalsIgnoreCase(actual))
		{
			return ComparisonResult.unmatch("Neither OrderID(37)s has colon, and they are not equal.");
		}
		final String expectedOrderIdWithoutDayNumber =
			expected.substring(Math.min(expected.length(), indexOfColonInExpected + 1));
		final String actualOrderIdWithoutDayNumber =
			actual.substring(Math.min(actual.length(), indexOfColonInActual + 1));
		if(!expectedOrderIdWithoutDayNumber.equalsIgnoreCase(actualOrderIdWithoutDayNumber))
		{
			return ComparisonResult.unmatch(expectedOrderIdWithoutDayNumber + "vs" + actualOrderIdWithoutDayNumber);
		}
		return ComparisonResult.matched();
	}

}
