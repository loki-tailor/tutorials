package com.mizuhosc.selenium.verification;

import com.mizuhosc.selenium.cache.*;

public class ClOrdIDComparator implements FieldComparator
{
	private final ClOrdIDToATP _clOrdIDToATP;
	
	public ClOrdIDComparator(final ClOrdIDToATP clOrdIDToATP)
	{
		_clOrdIDToATP = clOrdIDToATP;
	}
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		// Try string equals compare first.
		final ComparisonResult stringEqualsCompareResult = new StringEqualsComparator().compare(expected, actual);
		if(stringEqualsCompareResult.matches()) return ComparisonResult.matched();
		
		// If not matched, fall back to compare ClOrdID to ATP
		final String clOrdIDToATP = _clOrdIDToATP.getActualClOrdID(expected).orElse(null);
		if(clOrdIDToATP == null)
		{
			return stringEqualsCompareResult;
		}
		
		return new StringEqualsComparator().compare(clOrdIDToATP, actual);
	}
	
}
