package com.mizuhosc.selenium.verification;

import java.math.*;

/**
 * Compares numbers for equality without checking decimal points.
 */
public class NumberComparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null)
		{
			if(actual == null) return ComparisonResult.matched();
			return ComparisonResult.unmatch(null);
		}
		
		if(actual == null) return ComparisonResult.unmatch(null);
		if(expected.equals(actual)) return ComparisonResult.matched();
		try
		{
			final BigDecimal d1 = new BigDecimal(expected.replaceAll("\"", ""));
			final BigDecimal d2 = new BigDecimal(actual.replaceAll("\"", ""));
			return d1.compareTo(d2) == 0 ? ComparisonResult.matched() : ComparisonResult.unmatch(null);
		}
		catch(final NumberFormatException e)
		{
			return ComparisonResult.unmatch(e.getMessage());
		}
	}
	
}
