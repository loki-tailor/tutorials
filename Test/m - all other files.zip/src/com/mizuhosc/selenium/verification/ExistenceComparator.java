package com.mizuhosc.selenium.verification;

public class ExistenceComparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null && actual == null)
		{
			return ComparisonResult.matched();
		}
		if(expected != null && actual != null)
		{
			return ComparisonResult.matched();
		}
		if(expected != null && actual == null)
		{
			return ComparisonResult.unmatch("missing value");
		}

		// expected ==null and actual !=null
		return ComparisonResult.unmatch("unexpected value");
	}
	
}
