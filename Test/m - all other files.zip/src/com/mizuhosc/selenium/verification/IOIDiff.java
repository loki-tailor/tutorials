package com.mizuhosc.selenium.verification;

import static com.mizuhosc.selenium.verification.Diff.*;
import com.mizuhosc.selenium.ioi.*;
import javax.annotation.*;

public class IOIDiff
{
	public static final String IOI_CSV_HEADER =
		"IOIIDWithVersion,Tag,Expected,Actual,Reason,Instrument,ExpectedFullMsg,ActualFullMsg";
	private final IOIIDWithVersion _ioiIDWithVersion;
	private final String _tag;
	private final String _expected;
	private final String _actual;
	private final String _reason;
	private final String _instrument;
	private final String _expectedFull;
	private final String _actualFull;
	
	public IOIDiff(
		final IOIIDWithVersion ioiIDWithVersion,
		final String tag,
		final String expected,
		final String actual,
		final String reason,
		final String instrument,
		final String expectecFull,
		final String actualFull)
	{
		_ioiIDWithVersion = ioiIDWithVersion;
		_tag = tag;
		_expected = expected;
		_actual = actual;
		_reason = reason;
		_instrument = instrument;
		_expectedFull = expectecFull;
		_actualFull = actualFull;
	}
	
	public static IOIDiff missingIOI(final IOIIDWithVersion ioiIDWithVersion, final IOI ioi)
	{
		return new IOIDiff(
			ioiIDWithVersion,
			"ALL",
			"",
			"",
			"Missing IOI",
			ioi.getNonRepeatingValue("55"),
			ioi.getRaw(),
			"");
	}
	
	public static IOIDiff unexpectedIOI(final @Nullable IOIIDWithVersion ioiIDWithVersion, final IOI ioi)
	{
		return new IOIDiff(
			ioiIDWithVersion,
			"ALL",
			"",
			"",
			"Unexpected IOI",
			ioi.getNonRepeatingValue("55"),
			"",
			ioi.getRaw());
	}
	
	public String toCsvLine()
	{
		return String.format(
			"%s,%s,%s,%s,%s,%s,%s,%s",
			_ioiIDWithVersion,
			_tag,
			handleComma(_expected),
			handleComma(_actual),
			handleComma(_reason),
			_instrument,
			handleComma(_expectedFull),
			handleComma(_actualFull));
	}
}
