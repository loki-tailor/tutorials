package com.mizuhosc.selenium.verification;

import com.mizuhosc.selenium.*;
import java.sql.*;
import java.util.*;

// This class is written with FIX4.1, FIX4.2. FIX4.4 is not handled since we don't have 4.4 clients now.
public class LastCapacityComparator implements ComplexComparator
{
	final static Set<String> _CLIENTS_WiTH_COPY_LAST_CAPACITY_IN_GOR = gorClientsWithLastCapacity();
	private static final String _LAST_CAPACITY_TAG = "29";
	private static final String _EXEC_TYPE_TAG = "150";
	private static final String _EXEC_TRANS_TYPE_TAG = "20";
	private final Set<String> _correctBustExecTransTypes;
	private final Set<String> _fillExecTypes;
	
	public LastCapacityComparator()
	{
		_correctBustExecTransTypes = new HashSet<>();
		_correctBustExecTransTypes.add("1");
		_correctBustExecTransTypes.add("2");
		_fillExecTypes = new HashSet<>();
		_fillExecTypes.add("1");
		_fillExecTypes.add("2");
	}
	
	@Override
	public ComparisonResult compare(
		final Map<String, String> expectedMap,
		final Map<String, String> actualMap,
		final String clientId)
	{
		final String actual = actualMap.get(_LAST_CAPACITY_TAG);
		
		// The client is not configured to send LastCapacity in GOR
		if(!_CLIENTS_WiTH_COPY_LAST_CAPACITY_IN_GOR.contains(clientId))
		{
			if(actual != null) return ComparisonResult.unmatch("Client not configured with CopyLastCapacity in GOR");
			return ComparisonResult.matched();
		}
		
		// Client is configured to send LastCapacity in GOR
		final String expected = expectedMap.get(_LAST_CAPACITY_TAG);
		// Client configured to send 29, but historically 29 was not sent
		if(expected == null && actual != null)
		{
			return ComparisonResult.matched();
		}
		
		if(new StringEqualsComparator().compare(expected, actual).matches()) return ComparisonResult.matched();
		
		final String expectedExecTransType = expectedMap.get(_EXEC_TRANS_TYPE_TAG);
		final String actualExecTransType = actualMap.get(_EXEC_TRANS_TYPE_TAG);
		final boolean isCorrectOrBust = expectedExecTransType.equals(actualExecTransType) &&
			_correctBustExecTransTypes.contains(actualExecTransType);
		
		final String expectedExecType = expectedMap.get(_EXEC_TYPE_TAG);
		final String actualExecType = actualMap.get(_EXEC_TYPE_TAG);
		final boolean isExecution = expectedExecType.equals(actualExecType) && _fillExecTypes.contains(actualExecType);
		
		// For fill, correct and bust, tag 29 has to match
		if(isCorrectOrBust || isExecution)
		{
			return ComparisonResult.unmatch(null);
		}
		
		// GOR is sending 29 in non fill ERs, but Quattro is not. Treat as matched.
		if(expected != null && actual == null)
		{
			return ComparisonResult.matched();
		}
		return ComparisonResult.unmatch(null);
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return _LAST_CAPACITY_TAG;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(_LAST_CAPACITY_TAG);
	}
	
	public static Set<String> gorClientsWithLastCapacity()
	{
		try
		{
			final Set<String> clients = new HashSet<>();
			final Connection gorSybase = Configuration.SINGLETON.createConnection("SOURCE_DB");
			
			final ResultSet clientQueryResult = gorSybase.createStatement().executeQuery(
				" select fc.FixClientId " +
					" from FixClient fc" +
					" inner join FixClientVersion fcv on fc.FixClientId = fcv.FixClientId and fc.Version =fcv.DeployedVersion" +
					" inner join FixClientEnrichmentSetup fces on fc.FixClientId = fces.FixClientId and fc.Version = fces.FixClientVersion" +
					" inner join Enrichment e on fces.EnrichmentId = e.Id" +
					" where fc.Deleted ='N' and fc.Enabled = 'Y' and e.Name ='CopyLastCapacity'");
			while(clientQueryResult.next())
			{
				clients.add(clientQueryResult.getString("FixClientId"));
			}
			clientQueryResult.close();
			
			final ResultSet sessionClientQueryResult = gorSybase.createStatement().executeQuery(
				" select s.SenderCompId, sc.FixClientId " +
					" from Session s" +
					" inner join SessionEnrichmentSetup ses on s.SessionId = ses.SessionId and s.Version = ses.SessionVersion" +
					" inner join SessionVersion sv on s.SessionId = sv.SessionId and s.Version = sv.DeployedVersion" +
					" inner join Enrichment e on ses.EnrichmentId = e.Id" +
					" inner join SessionClient sc on s.SessionId =sc.SessionId and s.Version=sc.SessionVersion" +
					" where e.Name ='CopyLastCapacity' and s.Deleted ='N' ");
			while(sessionClientQueryResult.next())
			{
				clients.add(sessionClientQueryResult.getString("FixClientId"));
			}
			sessionClientQueryResult.close();
			gorSybase.close();
			return clients;
		}
		catch(final SQLException e)
		{
			throw new RuntimeException(e);
		}
	}
	
}
