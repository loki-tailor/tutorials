package com.mizuhosc.selenium.verification;

import java.util.*;
import java.util.stream.*;

public class FidessaOrderFlagsComparator implements FieldComparator
{
	
	@Override
	public ComparisonResult compare(final String expected, final String actual)
	{
		if(expected == null && actual == null)
		{
			return ComparisonResult.matched();
		}
		
		if(expected == null && actual != null)
		{
			return ComparisonResult.unmatch("unexpected");
		}
		
		if(expected != null && actual == null)
		{
			return ComparisonResult.unmatch("missing");
		}

		final String sortedExpectedFlags = Arrays.asList(expected.replaceAll("\"", "").split("\\s"))
			.stream().sorted()
			.collect(Collectors.joining(" "));
		final String sortedActualFlags = Arrays.asList(actual.replaceAll("\"", "").split("\\s"))
			.stream().sorted()
			.collect(Collectors.joining(" "));
		if(sortedExpectedFlags.equals(sortedActualFlags))
		{
			return ComparisonResult.matched();
		}
		
		return ComparisonResult.unmatch(null);
	}
	
}
