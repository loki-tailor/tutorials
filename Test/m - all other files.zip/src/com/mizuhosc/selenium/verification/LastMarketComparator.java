package com.mizuhosc.selenium.verification;

import com.mizuhosc.selenium.*;
import java.sql.*;
import java.util.*;

public class LastMarketComparator implements ComplexComparator
{
	private static final String _LAST_MARKET_TAG = "30";
	
	private final Map<String, String> _micToRic;
	
	private final Set<String> _clientsWithMicCodeInGOR;
	
	public LastMarketComparator(final Set<String> clientsWithNonMicCode)
	{
		_clientsWithMicCodeInGOR = clientsWithNonMicCode;
		_micToRic = new HashMap<>();
		_micToRic.put("XTKS", "T");
		_micToRic.put("XOSE", "OS");
		_micToRic.put("CHIJ", "CHJ");
		_micToRic.put("XFKA", "FU");
		_micToRic.put("SBIJ", "JNX");
		_micToRic.put("XNGO", "NG");
		_micToRic.put("XOFF", "11");
		_micToRic.put("XSAP", "SP");
		_micToRic.put("XJAS", "Q");
		_micToRic.put("XOSJ", "OS");
		_micToRic.put("XTK1", "T");
		_micToRic.put("XTK2", "T");
		_micToRic.put("XTK3", "T");
		_micToRic.put("XASX", "AX");
		_micToRic.put("XBOM", "BO");
		_micToRic.put("XSTC", "VN");
		_micToRic.put("XHKG", "HK");
		_micToRic.put("XIDX", "JK");
		_micToRic.put("XKRX", "KS");
		_micToRic.put("XKOS", "KQ");
		_micToRic.put("XKLS", "KL");
		_micToRic.put("XNSE", "NS");
		_micToRic.put("XNZE", "NZ");
		_micToRic.put("XPHS", "PS");
		_micToRic.put("XSES", "SI");
		_micToRic.put("XTAI", "TW");
		_micToRic.put("ROCO", "TWO");
		_micToRic.put("XBKK", "BK");
	}
	
	@Override
	public ComparisonResult compare(
		final Map<String, String> expectedMap,
		final Map<String, String> actualMap,
		final String gorClientId)
	{
		final String expected = expectedMap.get(_LAST_MARKET_TAG);
		final String actual = actualMap.get(_LAST_MARKET_TAG);
		if(_clientsWithMicCodeInGOR.contains(gorClientId))
		{
			return _compareMicCode(expected, actual);
		}
		
		// No MIC code attachment on the client in GOR, should send exact same value as before
		return new StringEqualsComparator().compare(expected, actual);
	}
	
	ComparisonResult _compareMicCode(final String expected, final String actual)
	{
		if(expected == null)
		{
			if(actual == null)
			{
				return ComparisonResult.matched();
			}
			return ComparisonResult.unmatch(null);
		}
		
		// expected !=null for be
		if(actual == null)
		{
			return ComparisonResult.unmatch(null);
		}
		
		// If value string equals, return matched
		if(expected.equals(actual)) return ComparisonResult.matched();
		
		// convert actual to RIC and compare
		if(expected.equals(_micToRic.get(actual)))
		{
			return ComparisonResult.matched();
		}
		
		// Special logic for XOTC to XOFF and XTK1 to MIZX
		if("XOTC".equals(expected) && "XOFF".equals(actual))
		{
			return ComparisonResult.matched();
		}
		
		if("XTK1".equals(expected) && "MIZX".equals(actual))
		{
			return ComparisonResult.matched();
		}
		
		return ComparisonResult.unmatch(null);
		
	}
	
	@Override
	public String getTagsForDiffReport()
	{
		return _LAST_MARKET_TAG;
	}
	
	@Override
	public String getValueForDiffReport(final Map<String, String> data)
	{
		return data.get(_LAST_MARKET_TAG);
	}
	
	public static Set<String> gorClientsWithSendMicInLastMkt()
	{
		try
		{
			final Set<String> clients = new HashSet<>();
			final Connection gorSybase = Configuration.SINGLETON.createConnection("SOURCE_DB");
			
			final ResultSet clientQueryResult = gorSybase.createStatement().executeQuery(
				" select fc.FixClientId " +
					" from FixClient fc" +
					" inner join FixClientVersion fcv on fc.FixClientId = fcv.FixClientId and fc.Version =fcv.DeployedVersion" +
					" inner join FixClientEnrichmentSetup fces on fc.FixClientId = fces.FixClientId and fc.Version = fces.FixClientVersion" +
					" inner join Enrichment e on fces.EnrichmentId = e.Id" +
					" where fc.Deleted ='N' and fc.Enabled = 'Y' and e.Name like 'SendMICInLastMarket%'");
			while(clientQueryResult.next())
			{
				clients.add(clientQueryResult.getString("FixClientId"));
			}
			clientQueryResult.close();
			
			final ResultSet sessionClientQueryResult = gorSybase.createStatement().executeQuery(
				" select s.SenderCompId, sc.FixClientId " +
					" from Session s" +
					" inner join SessionEnrichmentSetup ses on s.SessionId = ses.SessionId and s.Version = ses.SessionVersion" +
					" inner join SessionVersion sv on s.SessionId = sv.SessionId and s.Version = sv.DeployedVersion" +
					" inner join Enrichment e on ses.EnrichmentId = e.Id" +
					" inner join SessionClient sc on s.SessionId =sc.SessionId and s.Version=sc.SessionVersion" +
					" where e.Name like 'SendMICInLastMarket%' and s.Deleted ='N' ");
			while(sessionClientQueryResult.next())
			{
				clients.add(sessionClientQueryResult.getString("FixClientId"));
			}
			sessionClientQueryResult.close();
			gorSybase.close();
			return clients;
		}
		catch(final SQLException e)
		{
			throw new RuntimeException(e);
		}
	}
	
	public static void main(final String[] args)
	{
		System.out.println(gorClientsWithSendMicInLastMkt());
	}
}
