package com.mizuhosc.selenium.env;

import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.log.*;
import java.sql.*;

public class CopyAccount
{
	final static String developerDBName = "QUATTRO_DB";
	final static String developer = System.getProperty("user.name");
	final static String sourceDB = "quattro_q15";
	
	public static void main(final String[] args) throws Exception
	{
		if(args.length != 1)
		{
			Log.error("Account code parameter is required.");
		}
		else
		{
			new CopyAccount().execute(args[0]);
		}
	}
	
	public void execute(final String account) throws Exception
	{
		try(final Connection connDeveloper = Configuration.SINGLETON.createConnection(developerDBName);)
		{
			_copyTokyoFDACounterparty(account, connDeveloper);
			_copyTokyoFDAOrderProfile(account, connDeveloper);
			_copyTokyoFDAInsiderTrading(account, connDeveloper);
			_copyTokyoFDAMarketAccess(account, connDeveloper);
		}
	}

	private void _copyTokyoFDAMarketAccess(final String account, final Connection connDeveloper) throws SQLException
	{
		final String marketAccessSQL = String.format(
			"insert into %s.dbo.TokyoFDAMarketAccess (counterpartyId, marketId, dmaEnabled) " +
				"select counterpartyId, marketId, dmaEnabled from %s.quattro.TokyoFDAMarketAccess " +
				"where counterpartyId=?",
			developer,
			sourceDB);
		try(final PreparedStatement stmt = connDeveloper.prepareStatement(marketAccessSQL))
		{
			stmt.setString(1, account);
			stmt.execute();
			Log.info("Finished copying TokyoFDAMarketAccess for account %s", account);
		}
	}

	private void _copyTokyoFDAInsiderTrading(final String account, final Connection connDeveloper) throws SQLException
	{
		final String insiderTradingSQL = String.format(
			"insert into %s.dbo.TokyoFDAInsiderTrading " +
				"(counterpartyId, instrumentId, insiderType, cautionStatus) " +
				"select counterpartyId, instrumentId, insiderType, cautionStatus " +
				"from %s.quattro.TokyoFDAInsiderTrading where counterpartyId=?",
			developer,
			sourceDB);
		try(final PreparedStatement stmt = connDeveloper.prepareStatement(insiderTradingSQL))
		{
			stmt.setString(1, account);
			stmt.execute();
			Log.info("Finished copying TokyoFDAInsiderTrading for account %s", account);
		}
	}

	private void _copyTokyoFDAOrderProfile(final String account, final Connection connDeveloper) throws SQLException
	{
		final String tradingProfileSQL = String.format(
			"insert into %s.dbo.TokyoFDAOrderProfile " +
				"(counterpartyId, darkpoolEnabled, dpMarketRoute, exchangeCODEnabled, counterpartyGroupId) " +
				"select counterpartyId, darkpoolEnabled, dpMarketRoute, exchangeCODEnabled, counterpartyGroupId " +
				"from %s.quattro.TokyoFDAOrderProfile where counterpartyId=?",
			developer,
			sourceDB);
		try(final PreparedStatement stmt = connDeveloper.prepareStatement(tradingProfileSQL))
		{
			stmt.setString(1, account);
			stmt.execute();
			Log.info("Finished copying TokyoFDAOrderProfile for account %s", account);
		}
	}

	private void _copyTokyoFDACounterparty(final String account, final Connection connDeveloper) throws SQLException
	{
		final String counterpartySQL = String.format(
			"insert into %s.dbo.TokyoFDACounterparty " +
				"(counterpartyId, parentCounterpartyId, hideOrders, sorEnabled, status, description) " +
				"select counterpartyId, parentCounterpartyId, hideOrders, sorEnabled, status, description " +
				"from %s.quattro.TokyoFDACounterparty where counterpartyId=?",
			developer,
			sourceDB);
		try(final PreparedStatement stmt = connDeveloper.prepareStatement(counterpartySQL))
		{
			stmt.setString(1, account);
			stmt.execute();
			Log.info("Finished copying TokyoFDACounterparty for account %s", account);
		}
	}
}
