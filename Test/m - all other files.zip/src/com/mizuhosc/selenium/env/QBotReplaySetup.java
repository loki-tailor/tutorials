package com.mizuhosc.selenium.env;

import com.mizuhosc.selenium.*;
import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.stream.*;

public class QBotReplaySetup
{
	public static void main(final String[] args) throws Exception
	{
		// Create all the IOI sessions if the argument is "ioi".
		if(args.length > 0 && args[0].equals("ioi"))
		{
				final List<String> sessions = new ArrayList<>();
				try(final Connection connection = Configuration.SINGLETON.createConnection("SOURCE_DB");
					final Statement stmt = connection.createStatement();
					final ResultSet rs = stmt.executeQuery("select distinct SessionName from vIoiSessionClient"))
				{
					while(rs.next())
					{
						sessions.add(rs.getString("SessionName"));
					}
				}
				new QBotReplaySetup(sessions.toArray(new String[0])).execute("Connection.ini.ioi.template");
		}
		else if(args.length > 1 && (args[0].equals("oneway") || args[0].equals("nyow")))
		{
			final QBotReplaySetup setup = new QBotReplaySetup(Arrays.copyOfRange(args, 1, args.length));
			setup.execute("Connection.ini.template");
			
			// Copy OA service of oneway file to oneway project
			Files.copy(
				new ConfigFile("oneway.OAServices").getPath(),
				Paths.get(setup._quattroWorkSpaceDir + "\\oneway\\server\\play\\conf\\local\\OAServices"),
				StandardCopyOption.REPLACE_EXISTING);
		}
		else
		{
			final QBotReplaySetup setup = new QBotReplaySetup(args);
			setup.execute("Connection.ini.template");
			
			// Copy OA service file to Quattro
			Files.copy(
				new ConfigFile("OAServices").getPath(),
				Paths.get(setup._quattroWorkSpaceDir + "\\orderengine\\server\\play\\conf\\dev\\OAServices"),
				StandardCopyOption.REPLACE_EXISTING);
		}
	}
	
	private final String[] _sessionNames;
	private final String _dbName;
	private final String _quattroWorkSpaceDir = Configuration.SINGLETON.getProperty("quattro.workspace.path");
	
	public QBotReplaySetup(final String[] sessionNames)
	{
		_sessionNames = sessionNames;
		_dbName = System.getProperty("user.name");
	}
	
	private _Session loadSession(final String sessionName) throws SQLException
	{
		final String sql =
			String.format(
				"select senderCompID, targetCompID, fixVersion, sendingTimePrecision from Session where name ='%s'",
				sessionName);
		try(final Connection connection = createConnection(_dbName);
			final Statement stmt = connection.createStatement();
			final ResultSet rs = stmt.executeQuery(sql))
		{
			if(rs.next())
			{
				return new _Session(sessionName, rs);
			}
		}
		return null;
	}
	
	public void execute(final String qbotIniTemplate) throws Exception
	{
		for(final String sessionName: _sessionNames)
		{
			migrateSessionIfNotExist(sessionName);
		}
		createAppiaIniFiles(qbotIniTemplate);
	}
	
	public void migrateSessionIfNotExist(final String sessionName)
	{
		try(final Connection connection = createConnection(_dbName);
			final Statement stmt = connection.createStatement();
			final ResultSet rs = stmt.executeQuery("select * from Session where name ='" + sessionName + "' "))
		{
			if(!rs.next())
			{
				System.out.println("Copying session " + sessionName + " from quattro_q15");
				try(final PreparedStatement ptst = connection.prepareStatement(
					"insert into Session (" +
						" deleted, enabled, name, description, " +
						" senderCompID, targetCompID, remoteHost, localHost, port, " +
// 23.1
						" type, fixVersion, dailyConnectDays, connectHour, connectMinute, " +
// 24.0 onwards
// " type, fixVersion, connectDays, connectHour, connectMinute, " +
						" disconnectHour, disconnectMinute, eodHour, eodMinute, heartbeatInterval, " +
						"orderEngine, alertIfMessageSentOnConnectionDown, sendingTimePrecision" +
						" ) select " +
						" deleted, enabled, name, description, " +
						" senderCompID, targetCompID, '', localHost, port, " +
						" 'ACCEPTOR', fixVersion, 'sun,mon,tue,wed,thu,fri,sat', 3, 0, " +
						" 2, 50, 2, 55, heartbeatInterval, " +
						" 'OETEST', alertIfMessageSentOnConnectionDown, sendingTimePrecision" +
						" from quattro_q15v.quattro.Session where name=?"))
				{
					ptst.setString(1, sessionName);
					ptst.execute();
				}
				System.out.println(String.format("Session %s created", sessionName));
			}
			else
			{
				System.out.println("Session already exists in db " + _dbName);
			}
		}
		catch(final SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public void createAppiaIniFiles(final String qbotIniTemplate) throws Exception
	{
		final List<_Session> sessions = new LinkedList<>();
		for(final String sessionName: _sessionNames)
		{
			final _Session session = loadSession(sessionName);
			if(session != null)
			{
				sessions.add(session);
			}
		}
		_createIniFileForOrderEngine(sessions);
		System.out.println("Appia ini file in order engine updated");
		_createIniFileForQbot(sessions, qbotIniTemplate);
		System.out.println("Appia ini file in qbot updated");
	}
	
	private void _createIniFileForOrderEngine(final List<_Session> sessions) throws IOException
	{
		final String template = _readFile(new ConfigFile("OETEST.ini.template").getPath());
		
		final String connectionEntryAdded =
			template.replace(
				"<CONNECTION_ENTRY>",
				sessions
					.stream()
					.map(session -> String.format("connection = [%s]", session._name.toUpperCase()))
					.collect(Collectors.joining(_LINE_DELIMITER)));
		final String middlewareAdded = connectionEntryAdded
			.replaceAll(
				"<CONNECTION_IN_MIDDLEWARE>",
				sessions
					.stream()
					.map(session -> String.format("middleware_session_id = %s", session._name.toUpperCase()))
					.collect(Collectors.joining(_LINE_DELIMITER)));
		final String connectionDefinitionAdded =
			middlewareAdded.replace(
				"<CONNECTION_DEFINITION>",
				sessions
					.stream()
					.map(session -> _orderEngineConnectionBlock(session))
					.collect(Collectors.joining(_LINE_DELIMITER)));
		
		try(final FileWriter fileWriter = new FileWriter(
			_quattroWorkSpaceDir +
				"\\orderengine\\server\\play\\conf\\" +
				System.getProperty("user.name") +
				"\\OETEST.ini"))
		{
			fileWriter.write(connectionDefinitionAdded);
			fileWriter.flush();
		}
	}
	
	private void _createIniFileForQbot(final List<_Session> sessions, final String qbotIniTemplate) throws IOException
	{
		final Path templatePath = new ConfigFile(qbotIniTemplate).getPath();
		final String template = _readFile(templatePath);
		final String connectionEntryAdded =
			template.replace(
				"<CONNECTION_ENTRY>",
				sessions
					.stream()
					.map(session -> String.format("connection = [%s]", session._name.toUpperCase()))
					.collect(Collectors.joining(_LINE_DELIMITER)));
		final String middlewareAdded = connectionEntryAdded
			.replaceAll(
				"<CONNECTION_IN_MIDDLEWARE>",
				sessions
					.stream()
					.map(session -> String.format("middleware_session_id = %s", session._name.toUpperCase()))
					.collect(Collectors.joining(_LINE_DELIMITER)));
		final String connectionDefinitionAdded =
			middlewareAdded.replace(
				"<CONNECTION_DEFINITION>",
				sessions
					.stream()
					.map(session -> _qbotConnectionBlock(session))
					.collect(Collectors.joining(_LINE_DELIMITER)));
		try(final FileWriter fileWriter = new FileWriter(templatePath.getParent().toString() + "/Connection.ini"))
		{
			fileWriter.write(connectionDefinitionAdded);
			fileWriter.flush();
		}
	}
	
	private static final String _LINE_DELIMITER = System.getProperty("line.separator");
	
	public String _orderEngineConnectionBlock(final _Session session)
	{
		final StringBuilder builder = new StringBuilder();
		builder.append("[").append(session._name.toUpperCase()).append("]").append(_LINE_DELIMITER);
		builder.append("connection_type = ").append(session._fixVersion).append(_LINE_DELIMITER);
		builder.append("local_firm_id = ").append(session._targetCompID).append(_LINE_DELIMITER);
		builder.append("remote_firm_id = ").append(session._senderCompID).append(_LINE_DELIMITER);
		builder.append("heartbeat_interval = 30").append("").append(_LINE_DELIMITER);
		builder.append("validation = [VALIDATION_OFF]").append("").append(_LINE_DELIMITER);
		builder.append("hold_on_startup = SUSPEND").append("").append(_LINE_DELIMITER);
		if("MILLISECOND".equals(session._sendTimePrecision))
		{
			builder.append("ms_precision_sending_time = ON").append("").append(_LINE_DELIMITER);
		}
		return builder.toString();
	}
	
	public String _qbotConnectionBlock(final _Session session)
	{
		final StringBuilder builder = new StringBuilder();
		builder.append("[").append(session._name.toUpperCase()).append("]").append(_LINE_DELIMITER);
		builder.append("connection_type = ").append(session._fixVersion).append(_LINE_DELIMITER);
		builder.append("local_firm_id = ").append(session._senderCompID).append(_LINE_DELIMITER);
		builder.append("remote_firm_id = ").append(session._targetCompID).append(_LINE_DELIMITER);
		builder.append("net_address = localhost").append(_LINE_DELIMITER);
		builder.append("remote_port = 29001").append(_LINE_DELIMITER);
		builder.append("heartbeat_interval = 30").append("").append(_LINE_DELIMITER);
		builder.append("validation = [VALIDATION_OFF]").append("").append(_LINE_DELIMITER);
		builder.append("trading_session = [DAILY_AUTO_RECONNECT]").append("").append(_LINE_DELIMITER);
		return builder.toString();
	}
	
	String _readFile(final Path path) throws IOException
	{
		return new String(Files.readAllBytes(path));
	}
	
	public Connection createConnection(final String db) throws SQLException
	{
		final Properties p = new Properties();
		p.put("user", "quattro");
		p.put("password", "quattro");
		final String url = "jdbc:sybase:Tds:tkfixdbd2.mizuho-sc.com:4105/" + db;
		return DriverManager.getConnection(url, p);
	}
	
	class _Session
	{
		private final String _name;
		private final String _senderCompID;
		private final String _targetCompID;
		private final String _fixVersion;
		private final String _sendTimePrecision;
		
		public _Session(final String sessionName, final ResultSet rs) throws SQLException
		{
			_name = sessionName;
			_senderCompID = rs.getString("senderCompID");
			_targetCompID = rs.getString("targetCompID");
			_fixVersion = rs.getString("fixVersion");
			_sendTimePrecision = rs.getString("sendingTimePrecision");
		}
	}
}
