package com.mizuhosc.selenium;

public class Version {
	public static void main(final String[] args) {
		System.out.println("0.1");

	}
}
