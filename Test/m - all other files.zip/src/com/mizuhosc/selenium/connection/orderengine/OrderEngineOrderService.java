package com.mizuhosc.selenium.connection.orderengine;

import com.mizuhosc.quattro.jasper.*;
import com.mizuhosc.quattro.jasper.client.*;
import com.mizuhosc.quattro.jasper.message.Request.*;
import com.mizuhosc.quattro.jasper.persistence.write.*;
import com.mizuhosc.quattro.util.*;
import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.log.*;
import java.util.*;

public class OrderEngineOrderService
{
	private final Map<String, JasperClient> _jasperClients;
	
	public OrderEngineOrderService() throws Exception
	{
		final Jasper jasper = new SimpleJasper("qbot", new FilePersisterFactory(), 30, 30);
		_jasperClients = new HashMap<>();
		
		final List<String> orderEngineNames = Configuration.SINGLETON.getValues("orderengine.names");
		final List<String> ports = Configuration.SINGLETON.getValues("orderengine.jasper.orderServicePorts");
		final HostName host = new HostName(Configuration.SINGLETON.getProperty("orderengine.hostname"));
		for(int i = 0; i < orderEngineNames.size(); i++)
		{
			final String orderEngineName = orderEngineNames.get(i);
			final PortNumber port = new PortNumber(ports.get(i));
			final JasperClient client = jasper.createClient(orderEngineName + ".OrderStatus", port, host);
			_jasperClients.put(orderEngineName, client);
		}
		
	}
	
	public void start()
	{
		_jasperClients.values().forEach($ -> $.start());
	}
	
	public boolean allConnected()
	{
		return _jasperClients.values().stream().filter($ -> !$.isAuthenticated()).count() == 0;
	}
	
	public long getConnectedOrderEngines()
	{
		return _jasperClients.values().stream().filter($ -> $.isAuthenticated()).count();
	}
	
	public void sendCommandToOrderEngine(final String orderEngine, final RequestType requestType, final MessageMap data)
	{
		Log.info("Sending command " + requestType + " with data " + data.getTransmitString() + " to " + orderEngine);
		Optional.ofNullable(_jasperClients.get(orderEngine)).ifPresent($ ->
		{
			try
			{
				$.request(requestType, data, JasperClient.Listener.NULL);
			}
			catch(final Exception e)
			{
				Log.error(e, e.getMessage());
			}
		});
	}
	
}
