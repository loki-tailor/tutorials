package com.mizuhosc.selenium.connection.fix;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mizuhosc.selenium.scripts.util.ULBridgeFIXReplay2;

public class SendFIXMessage

{
	private String testResult;
	private WebDriver driver; // Selects appropraite driver
	public ULBridgeFIXReplay2 ulBridgeFIXReplay2;

	@Parameters({ "IniFilePath", "File_Order1" })
	@Test
	public void SendFIXMessage(final String AppiaIniFilePath, final String Order1) throws Exception {
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try {

			Reporter.log(String.format("Using Appia Ini File without sendAnotherOrder %s and replaying Log file %s",
					AppiaIniFilePath, Order1), true);
			ulBridgeFIXReplay2 = new ULBridgeFIXReplay2(Order1, ULBridgeFIXReplay2.ConnectionType.CLIENT2GOR, 1000,
					AppiaIniFilePath);
			Thread.sleep(100000);

		} catch (final InterruptedException e) {
			e.printStackTrace();
		}   

	}
}
