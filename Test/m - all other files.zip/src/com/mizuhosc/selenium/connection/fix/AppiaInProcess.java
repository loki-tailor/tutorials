package com.mizuhosc.selenium.connection.fix;

import static com.javtech.appia.middleware.MiddlewareEventIF.*;
import com.javtech.appia.*;
import com.javtech.appia.middleware.*;
import com.javtech.javatoolkit.fix.*;
import com.javtech.javatoolkit.message.*;
import com.mizuhosc.selenium.log.*;
import com.mizuhosc.selenium.message.*;
import com.mizuhosc.selenium.message.MessageType;
import com.mizuhosc.selenium.verification.*;
import java.util.*;

public class AppiaInProcess implements MiddlewareEventListenerIF
{
	private final MiddlewareInterface _middleware;
	private final Orders _orders;
	private final IOIs _iois;
	private final String _appiaIniFile;
	
	public AppiaInProcess(final Orders orders, final IOIs iois, final String appiaIniFile)
	{
		_appiaIniFile = appiaIniFile;
		_orders = orders;
		_iois = iois;
		_middleware = create("MIZUHO");
	}
	
	/**
	 * @return Newly created middleware interface based on the specified middlewareId.
	 */
	public MiddlewareInterface create(final String middlewareId)
	{
		MiddlewareInterface appia;
		final String iniFilePath = _appiaIniFile;
		
		// Connect to Appia. Since this is inproc, we cannot use Java ToolKit MiddlewareInterface
		Log.info("Loading Appia ini file: %s", iniFilePath);
		try
		{
			// The Appia ini file, second parameter is used for indicating which HA block to use
			final String[] iniFile = new String[] {iniFilePath};
			appia =
				com.javtech.appia.middleware.MiddlewareInterfaceFactory.getInProcMiddlewareInterface(
					iniFile,
					middlewareId,
					false);
			Log.info("Appia middleware %s initialized successfully.", middlewareId);
		}
		catch(final Exception e)
		{
			Log.error(e, "Failed to connect to Appia for middleware: %s", middlewareId);
			
			// Throw a runtime exception, this should already cause problem for the application to start
			// correctly.
			throw new RuntimeException(e);
		}
		return appia;
	}
	
	public MiddlewareInterface getMiddleware()
	{
		return _middleware;
	}
	
	public void start() throws Exception
	{
		_middleware.setMiddlewareEventListener(this);
		_middleware.start();
	}
	
	public boolean isAllSessionConencted()
	{
		try
		{
			for(final SessionInfo info: _middleware.getAllSessionInfo())
			{
				if(ConnectState.APPLICATION_CONNECTION != info.getConnectState())
				{
					return false;
				}
			}
			return true;
		}
		catch(final Exception e)
		{
			Log.error(e, "Failed to get appia session status", e.getMessage());
			return false;
		}
	}
	
	@Override
	public void onMiddlewareEvent(final MiddlewareEvent msg) throws Exception
	{
		switch(msg.getEventType())
		{
			case APPLICATION_MESSAGE_RECEIVED:
			{
				final FixMessageObject fixMsg = (FixMessageObject)msg.getEventData();
				final MessageData data = fixMsg.getMessageData();
				Log.info("Received FIX message: %s", data);
				final com.javtech.javatoolkit.message.MessageType msgType = fixMsg.getMessageType();
				
				// Raw message doesn't have tag 8, 9 and 10. Tried "Converter.loadProtocol" and still doesn't work.
				final String rawFIXMsg = Converter.getString(fixMsg).replaceAll("\u0001", "|");
				final String fullRawFIXMsg = _formatFIXTag(data, FixConstants.BeginString) +
					_formatFIXTag(data, FixConstants.BodyLength) +
					rawFIXMsg +
					_formatFIXTag(data, FixConstants.CheckSum);
				final Message message =
					new Message(Direction.IN, MessageType.FIX, Collections.singletonList(fullRawFIXMsg));
				
				// IOI messages
				if(FixConstants.IOI.equals(msgType))
				{
					_iois.addActual(message);
				}
				// Order messages
				else
				{
					_orders.addActualOrderMessages(message);
				}
				break;
			}
			
		}
	}
	
	private static final String _formatFIXTag(final MessageData data, final Attribute tag)
	{
		return String.format("%d=%s|", tag.getId(), data.getValue(tag));
	}
	
}
