package com.mizuhosc.selenium.connection.fix;

import com.mizuhosc.selenium.functionlibraries.CommonFunctions;
import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.scripts.util.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;
import com.mizuhosc.selenium.functionlibraries.*;


public class ResetSessionScript
{
	
	@Parameters({
		"SessionName",
		"ResetSessionBatchFile",
		"ResetSessionBatchFileScriptsPath",
		"LogsPath"
		})
	@Test
	public void ResetSessionScript (
			final String sessionname,
			final String ResetSessionBatchFile,
			final String ResetSessionBatchFileScriptsPath,
			final String LogsPath
		) throws IOException, InterruptedException

	{
		
		CommonFunctions.ResetSession(sessionname, ResetSessionBatchFile, ResetSessionBatchFileScriptsPath, LogsPath,  15000);
	}
	
}