package com.mizuhosc.selenium.connection.fidessa;

import com.fidessa.inf.oa.*;
import com.fidessa.inf.utl.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class OnewayStreamService implements NewSessionListener, OrderEngineConnectionService
{
	// This is to support Quattro OrderEngine parameterized logon.
	private final Map<String, Session> _streamsPerOrderEngine;
	
	private final AtomicInteger _connectedOrderEngines;
	
	public OnewayStreamService()
	{
		_streamsPerOrderEngine = new ConcurrentHashMap<>();
		_connectedOrderEngines = new AtomicInteger();
	}
	
	public void start() throws Exception
	{
		final Server s = new Server("SITE_IN_RDS_OKAPI");
		s.addNewSessionListener(this);
		s.setServiceUp(true);
	}
	
	@Override
	public void newSession(final NewSessionEvent sessionEvent)
	{
		final StructuredSet request = sessionEvent.getSessionMessage().getStructuredSet();
		
		final String user = (String)request.get("USER_NAME");
		
		final Session session = sessionEvent.getSession();
		
		// Acknowledge
		final StructuredSet ss = new StructuredSet();
		ss.add("MESSAGE_TYPE", "DS_ACK");
		session.write(ss);
		_streamsPerOrderEngine.put(user, session);
		_connectedOrderEngines.incrementAndGet();
	}
	
	public void send(final String user, final StructuredSet msg)
	{
		Optional.ofNullable(_streamsPerOrderEngine.get(user)).ifPresent($ -> $.write(msg));
	}
	
	@Override
	public int getConnectedOrderEngines()
	{
		return _connectedOrderEngines.get();
	}
}
