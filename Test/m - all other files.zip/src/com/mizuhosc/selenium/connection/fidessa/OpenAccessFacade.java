package com.mizuhosc.selenium.connection.fidessa;

import com.fidessa.inf.oa.*;
import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.log.*;
import java.io.*;
import java.nio.file.*;

/**
 * Fidessa Open Access facade copied from Quattro.
 */
public final class OpenAccessFacade
{
	private OpenAccessFacade()
	{
		// Don't instantiate a utility class
	}
	
	// QTR-3082: Why is this necessary? It seems that initialisation is done in the @Connect phase, so why is it
	// necessary to maintain a global variable to flag initialisation state? I suspect you felt slightly nauseous when
	// you wrote this code, but you just swallowed and went ahead with it. Please, TRUST YOUR INSTINCTS. This stinks,
	// and you know it! ;)
	private static volatile boolean _initialised = false;
	
	/**
	 * Initialise Fidessa Open Access.
	 *
	 * @param instanceId application instance ID
	 */
	public static void initialise(final String oaServicesFileName)
	{
		synchronized(OpenAccessFacade.class)
		{
			if(_initialised)
			{
				return;
			}
			
			Log.info("Initialising OpenAccess...");
			
			final Path path = new ConfigFile(oaServicesFileName).getPath();
			
			// The default directory in Linux is ~/quattro/orderengine/server/play, so OA services path will point to
			// ~/quattro/orderengine/server/play/conf
			final String oaservicesPath =
				System.getProperty("oaservices.path", path.getParent().toString());
			Log.info("OA Services path: %s", oaservicesPath);
			
			// Set so that the Fidesa API knows where the OpenAccess configuration file is.
			System.setProperty("com.fidessa.FID_CONFIG_PATH", oaservicesPath);
			System.setProperty("com.fidessa.FID_DEFAULT_REMOTE_CAPABILITIES", "");
			System.setProperty("com.fidessa.FID_TRACE_ENABLE", "LOG_TRACE_OA_CONNECTION");
			
			final String openAccessLogFileName = "./logs/OpenAccess" + ".log";
			Log.info("Open Access log file: %s", openAccessLogFileName);
			try(PrintStream s = new PrintStream(openAccessLogFileName, "UTF-8"))
			{
				com.fidessa.inf.utl.Log.setPrintStream(s);
			}
			catch(final FileNotFoundException | UnsupportedEncodingException e)
			{
				// no need to log stacktrace since we know it's FileNotFoundException
				Log.info("OpenAccess Init Error, unable to open OpenAccess log file: %s", openAccessLogFileName);
				// QTR-3082: Can we proceed if this happens? Wouldn't it make sense to combine with the below try block,
				// and catch this exception as one of the resulting errors?
			}
			
			// Show which Fidessa server we are connecting to
			try
			{
				Log.info("Attempting to initialize open access service");
				OpenAccess.initialise();
				_initialised = true;
			}
			
			catch(final OAException e)
			{
				// log stacktrace as OAException is a generic error
				Log.error(
					e,
					"OpenAccess Init Error, error in loading OAServices file '%s'. Reason: %s",
					oaServicesFileName,
					e.getMessage());
			}
		}
	}
	
	/**
	 * Destroy Open Access. Call this to clean-up all connections to Fidessa.
	 */
	public static void destroy()
	{
		synchronized(OpenAccessFacade.class)
		{
			OpenAccess.destroy();
			_initialised = false;
			Log.info("OpenAccess destroyed.");
		}
	}
}
