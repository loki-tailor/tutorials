package com.mizuhosc.selenium.connection.fidessa;

import com.fidessa.inf.oa.*;
import com.fidessa.inf.utl.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * The service that provides stream message for SITE_IN_RDS_QUATTRO_HSE. Currently only support one stream
 * DS_DMAJMIS_ORDSTATUS_QUATTRO on it.
 */
public class SwapStreamService implements NewSessionListener, OrderEngineConnectionService
{
	//This is to support Quattro OrderEngine parameterized logon.
	private final Map<String, Session> _streamsPerOrderEngine;
	
	private final AtomicInteger _connectedOrderEngines;
	
	public SwapStreamService()
	{
		_streamsPerOrderEngine = new ConcurrentHashMap<>();
		_connectedOrderEngines = new AtomicInteger();
	}
	
	public void start() throws Exception
	{
		final Server s = new Server("SITE_IN_RDS_QUATTRO_HSE");
		s.addNewSessionListener(this);
		s.setServiceUp(true);
	}
	
	@Override
	public void newSession(final NewSessionEvent sessionEvent)
	{
		final StructuredSet request = sessionEvent.getSessionMessage().getStructuredSet();
		
		final String orderEngineName = (String)request.get("USER_NAME");
		_streamsPerOrderEngine.put(orderEngineName, sessionEvent.getSession());
		_connectedOrderEngines.incrementAndGet();
	}
	
	public void send(final String orderEngine, final StructuredSet msg)
	{
		Optional.ofNullable(_streamsPerOrderEngine.get(orderEngine)).ifPresent($ -> $.write(msg));
	}
	
	@Override
	public int getConnectedOrderEngines()
	{
		return _connectedOrderEngines.get();
	}
	
}
