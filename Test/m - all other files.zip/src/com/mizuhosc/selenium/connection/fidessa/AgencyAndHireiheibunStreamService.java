package com.mizuhosc.selenium.connection.fidessa;

import com.fidessa.inf.oa.*;
import com.fidessa.inf.utl.*;
import com.mizuhosc.selenium.log.Log;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * The service that provides stream of messages for SITE_IN_RDS_QUATTRO. This covers streams of OMAR agency and
 * hireihaibun.
 */
public class AgencyAndHireiheibunStreamService implements NewSessionListener, OrderEngineConnectionService
{
	// This is to support Quattro OrderEngine parameterized logon.
	private final Map<String, Map<StreamName, Session>> _streamsPerOrderEngine;
	
	private final AtomicInteger _connectedOrderEngines;
	
	public AgencyAndHireiheibunStreamService()
	{
		_streamsPerOrderEngine = new ConcurrentHashMap<>();
		_connectedOrderEngines = new AtomicInteger();
	}
	
	public void start() throws Exception
	{
		final Server s = new Server("SITE_IN_RDS_QUATTRO");
		s.addNewSessionListener(this);
		s.setServiceUp(true);
	}
	
	@Override
	public void newSession(final NewSessionEvent sessionEvent)
	{
		final StructuredSet request = sessionEvent.getSessionMessage().getStructuredSet();
		
		final String orderEngineName = (String)request.get("USER_NAME");
		final Map<StreamName, Session> orderEngineStreams = _streamsPerOrderEngine.computeIfAbsent(
			orderEngineName,
			s -> new ConcurrentHashMap<>());
		
		final StreamName streamName = StreamName.valueOf((String)request.get("DATASTREAM_NAME"));
		final Session session = sessionEvent.getSession();
		
		// Acknowledge
		final StructuredSet ss = new StructuredSet();
		ss.add("MESSAGE_TYPE", "DS_ACK");
		session.write(ss);
		orderEngineStreams.put(streamName, session);
		_connectedOrderEngines.incrementAndGet();
	}
	
	public void send(final String orderEngine, final StreamName stream, final StructuredSet msg)
	{
		final Map<StreamName, Session> orderEngineStreams = _getStreamsForOE(orderEngine);
		if(orderEngineStreams != null)
		{
			final Session s = orderEngineStreams.get(stream);
			if(s != null)
			{
				final boolean succesed = s.write(msg);
				if(!succesed) Log.info("Failed to write %s", msg);
			}
		}
		else
		{
			Log.error("No stream for order engine %s", orderEngine);
		}
		
	}
	
	/**
	 * 
	 * @param orderEngine either $env:OrderEngineName or OrderEngineName
	 */
	Map<StreamName, Session> _getStreamsForOE(final String orderEngine)
	{
		final Map<StreamName, Session> orderEngineStreams = _streamsPerOrderEngine.get(orderEngine);
		if(orderEngineStreams == null)
		{
			// Search based on OrderEngineName without prefix
			return _streamsPerOrderEngine
				.entrySet()
				.stream()
				.filter($ -> $.getKey().endsWith(":" + orderEngine))
				.map($ -> $.getValue())
				.findFirst()
				.orElse(null);
		}
		return orderEngineStreams;
	}
	
	@Override
	public int getConnectedOrderEngines()
	{
		// 2 connections per OE
		return _connectedOrderEngines.get() / 2;
	}
	
	public enum StreamName
	{
		// This is the stream to send message to OE for OMAR agency order accept,
		DS_QUATTRO_ORDSTATUS,
		// This is the stream to send message to OE for hireihaibun executions
		DS_QUATTRO_HH_EXECS
	}
}
