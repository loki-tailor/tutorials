package com.mizuhosc.selenium.connection.fidessa;

import com.fidessa.inf.oa.*;
import com.fidessa.inf.utl.*;
import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.log.Log;
import com.mizuhosc.selenium.message.*;
import com.mizuhosc.selenium.message.Message;
import com.mizuhosc.selenium.verification.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * ChildManagementHandler receives order request from OE for request to OMAR.
 *
 */
public class JmisTransactionService
{
	private final QuattroOrderIdCache _cache;
	private final Orders _orders;
	private final ConcurrentHashMap<String, NewSessionEvent> _txnNackMapping;
	
	public JmisTransactionService(final QuattroOrderIdCache cache, final Orders orders)
	{
		_cache = cache;
		_orders = orders;
		_txnNackMapping = new ConcurrentHashMap<>();
	}
	
	public void start()
	{
		try
		{
			final Server s = new Server("JMIS_ORDSVR");
			s.addNewSessionListener(new NewSessionListener()
			{
				@Override
				public void newSession(final NewSessionEvent sessionEvent)
				{
					Log.info(sessionEvent.toString());
					final StructuredSet ss = sessionEvent.getSessionMessage().getStructuredSet();
					final String sourceRef = (String)ss.get("SOURCE_REF");
					if(sourceRef != null)
					{
						_txnNackMapping.put(sourceRef, sessionEvent);
					}
					_processRequest(ss);
					final StructuredSet response = new StructuredSet();
					response.add("MESSAGE_TYPE", "TXN_ACK");
					response.add("TEXT", "Good to go");
					sessionEvent.getSession().write(response);
				}
			});
			s.setServiceUp(true);
		}
		catch(final Exception e)
		{
			Log.error(e, e.getMessage());
		}
		
	}
	
	public void _sendTxnNack(final StructuredSet nackMsg)
	{
		final String omsOrderId = (String)nackMsg.get("DETAILS.ORDER_ID");
		final String orderId =
			omsOrderId != null
				? _cache
					.getQuattroOrderIdByOmsOrderId(omsOrderId)
					.map($ -> $.substring($.indexOf(":") + 1))
					.orElse(null)
				: Optional
					.ofNullable((String)nackMsg.get("XP_DATA.CUSTOM.EXT_REF2"))
					.map($ -> $.substring($.indexOf(":") + 1))
					.orElse(null);
		
		// This assumes the NACK is for latest request OE sent.
		final String replaySourceRef = _orders.getLatestOutboundSourceRef(orderId).orElse(null);
		if(replaySourceRef == null)
		{
			Log.error("Source ref null in message: " + nackMsg);
			return;
		}
		nackMsg.remove("SOURCE_REF");
		nackMsg.add("SOURCE_REF", replaySourceRef);
		final NewSessionEvent se = _txnNackMapping.get(replaySourceRef);
		if(se != null)
		{
			se.getSession().write(nackMsg);
		}
		else
		{
			Log.error("No nack handler for %s", replaySourceRef);
		}
	}
	
	private void _processRequest(final StructuredSet request)
	{
		// Example of QuattroOrderId: 1c:JASON:15011340610
		final String quattroOrderId = (String)request.get("XP_DATA.DETAILS.ORIGINATOR_ORDER_ID");
		final String orderEngineName = (String)request.get("XP_DATA.CUSTOM.ORDER_SOURCE");
		final String clientRefId = QuattroOrderIdCache.extractClientRefIdFromQuattorOrderId(quattroOrderId);
		_cache.mapNewQuattroOrderId(clientRefId, quattroOrderId);
		// orderEngineName is not set in cancel request
		if(orderEngineName != null)
		{
			_cache.mapClientRefIdToOrderEngineName(clientRefId, orderEngineName);
		}
		
		final Message msg = new Message(Direction.IN, MessageType.FIDESSA, Arrays.asList(request.toString().split(
			"\n")));
		_orders.addActualOrderMessages(msg);
	}
	
}
