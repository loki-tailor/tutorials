package com.mizuhosc.selenium.connection.fidessa;

public interface OrderEngineConnectionService
{
	int getConnectedOrderEngines();
}
