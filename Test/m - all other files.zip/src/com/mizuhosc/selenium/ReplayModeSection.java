package com.mizuhosc.selenium;

public enum ReplayModeSection
{
	ONE_WAY,
	TWO_WAY,
	IOI;
}
