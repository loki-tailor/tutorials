package com.mizuhosc.selenium.diff;

import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.message.*;
import com.mizuhosc.selenium.verification.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;
import javax.annotation.*;

public class FIXComparator
{
	private final static Map<String, FieldComparator> _staticSimpleComparators = new HashMap<>();
	private final static List<ComplexComparator> _staticComplexComparators = new LinkedList<>();
	
	static
	{
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.existenceCompare"))
			.forEach($ -> _staticSimpleComparators.put($, new ExistenceComparator()));
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.numberCompare"))
			.forEach($ -> _staticSimpleComparators.put($, new NumberComparator()));
		
		_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.looseTimeCompare"))
			.forEach($ -> _staticSimpleComparators.put($, new FIXLooseTimestampFieldComparator()));
		
		_staticSimpleComparators.put("37", new OrderIdComparator());
		_staticSimpleComparators.put("8053", new OrderIdComparator());
		_staticSimpleComparators.put("64", new DateComparator());
		_staticSimpleComparators.put("75", new DateComparator());
		
		_ignoreCompareTags();
		
		_staticComplexComparators.add(new ExecIDComparator());
		_staticComplexComparators.add(new AccountComparator());
		// Below is commented by Sankalp on 2019-01-30 so as not to get invalid value diffs in Allocation Comparison this needs to be reverted back when QTR-12097 is done and dusted
		//_staticComplexComparators.add(new TransactTimeComparator());
		_staticComplexComparators.add(new LastPxComparator());
		_staticComplexComparators.add(new SecurityTypeComparator());
		_staticComplexComparators.add(new FixTagPriceComparator());
		//_staticComplexComparators.add(new LastCapacityComparator());
		//_staticComplexComparators.add(new LastMarketComparator(LastMarketComparator.gorClientsWithSendMicInLastMkt()));
		_staticComplexComparators.add(
			new LastLiquidityIndicateComparator(
				Configuration.SINGLETON
					.getValues("FIX.MiFID2.clients.block.851")
					.stream()
					.collect(Collectors.toSet())));
	}

	private static void _ignoreCompareTags()
	{
		final Set<String> tagsToIgnore = new HashSet<>();
		tagsToIgnore.add("17");
		tagsToIgnore.add("19");
		tagsToIgnore.add("44");
		tagsToIgnore.add("29");// LastCapacity(29) will be compared by LastCapacityComparator
		tagsToIgnore.add("30");// LastMkt(30) will be compared by LastMarketComparator
		tagsToIgnore.add("1");// Account(1) will be compared by AccountComparator
		tagsToIgnore.add("60");// TransactTime(60) will be compared by TransactTimeComparator
		tagsToIgnore.add("31");// LastPx(31) will be compared by LastPxComparator
		tagsToIgnore.add("167");// SecurityType(167) will be compared by SecurityTypeComparator
		tagsToIgnore.add("851");// LastLiquidityInd(851) will be compared by LastLiquidityIndicateComparator
		tagsToIgnore.addAll(_getTagsConfigured(Configuration.SINGLETON.getProperty("FIX.tags.ignore")));
		tagsToIgnore.forEach($ -> _staticSimpleComparators.put($, new IgnoreComparator()));
	}
	
	private final Map<String, FieldComparator> _simpleComparators = new ConcurrentHashMap<>();
	
	public FIXComparator()
	{
		_simpleComparators.putAll(_staticSimpleComparators);
	}
	
	public List<Diff> compare(final FIXMessage expected, final FIXMessage actual)
	{
		final List<Diff> result = new LinkedList<>();
		if(expected == null && actual != null)
		{
			result.add(new Diff(
				actual.get("37"),
				MessageType.FIX.name(),
				"WholeMsg",
				"",
				"",
				"unexpected message",
				_getInstrument(actual),
				"",
				actual.raw));
		}
		else if(expected != null && actual == null)
		{
			result.add(new Diff(
				expected.get("37"),
				MessageType.FIX.name(),
				"WholeMsg",
				"",
				"",
				"missing message",
				_getInstrument(expected),
				expected.raw,
				""));
		}
		else if(expected != null && actual != null)
		{
			final Map<String, String> expectedMap = expected.fixTags;
			final Map<String, String> actualMap = actual.fixTags;
			final Set<String> keys = new TreeSet<>();
			keys.addAll(expectedMap.keySet());
			keys.addAll(actualMap.keySet());
			for(final String key: keys)
			{
				final String expectedTagValue = expectedMap.get(key);
				final String actualTagValue = actualMap.get(key);
				final FieldComparator comparator = _simpleComparators.computeIfAbsent(
					key,
					$ -> new StringEqualsComparator());
				final ComparisonResult cr = comparator.compare(expectedTagValue, actualTagValue);
				if(!cr.matches())
				{
					final Diff diff = new Diff(
						expected.get("37"),
						MessageType.FIX.name(),
						key,
						expectedTagValue,
						actualTagValue,
						cr.getReason().orElse(""),
						_getInstrument(expected),
						expected.raw,
						actual.raw);
					result.add(diff);
				}
			}
			
			for(final ComplexComparator cc: _staticComplexComparators)
			{
				final ComparisonResult cr = cc.compare(expectedMap, actualMap, null);
				if(!cr.matches())
				{
					final Diff diff = new Diff(
						expected.get("37"),
						MessageType.FIX.name(),
						cc.getTagsForDiffReport(),
						cc.getValueForDiffReport(expectedMap),
						cc.getValueForDiffReport(actualMap),
						cr.getReason().orElse(""),
						_getInstrument(expected),
						expected.raw,
						actual.raw);
					result.add(diff);
				}
			}
			
		}
		return result;
	}
	
	static @Nullable String _getInstrument(final @Nonnull FIXMessage message)
	{
		return Stream.of("55", "48").map(message::get).filter(Objects::nonNull).findFirst().orElse(null);
	}
	
	static Set<String> _getTagsConfigured(final String configValue)
	{
		final Set<String> result = new HashSet<>();
		if(configValue == null)
		{
			return result;
		}
		for(final String s: configValue.split(","))
		{
			final String trimmed = s.trim();
			if(!trimmed.isEmpty())
			{
				result.add(trimmed);
			}
		}
		return result;
	}
}
