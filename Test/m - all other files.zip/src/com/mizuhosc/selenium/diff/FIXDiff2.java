package com.mizuhosc.selenium.diff;

import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.log.*;
import com.mizuhosc.selenium.message.*;
import com.mizuhosc.selenium.verification.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;

public class FIXDiff2 {
	public static void main(final String[] args) throws FileNotFoundException, IOException {

		if (args.length < 3) {
			Log.error("Usage: FIXDiff {file1|-} {file2|-}");
			return;
		}

		final String file1 = args[0];
		final String file2 = args[1];
		final String FIXDiffFilepath = args[2];

		Log.info("Will output the diff in %s ", FIXDiffFilepath);
		
		if ("-".equals(file1) && "-".equals(file2)) {
			Log.error("Only either of the parameter can be '-'");
			return;
		}

		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
//		final String FIXDiffFilepath = Configuration.SINGLETON.getProperty("selenium.FIXDifffile.path");
		//final String reportFile = String.format("I:/IT_WSD/FIX/Selenium.Automation/diffs/FIXDiff.csv",
			//	sdf.format(new Date()));
		final String reportFile = String.format(FIXDiffFilepath,sdf.format(new Date()));
		
		final FIXDiff2 diffTool = new FIXDiff2("37", reportFile);

		Log.info("Starts to report diff between files %s and %s", file1, file2);
		// Parse file1 into list of FIXMessage
		final List<FIXMessage> messages1 = diffTool._parseFIXMessageFile(file1);

		// Parse file2 into list of FIXMessage
		final List<FIXMessage> messages2 = diffTool._parseFIXMessageFile(file2);

		diffTool.diff(messages1, messages2);
		Log.info("Finished reporting diff between files %s and %s", file1, file2);

		Log.info("Diff Files kept in %s", FIXDiffFilepath);

	}

	private final String _idTag;
	private final String _outputFilePath;

	public FIXDiff2(final String idTag, final String outputFilePath) {
		_idTag = idTag;
		_outputFilePath = outputFilePath;
	}

	public void diff(final List<FIXMessage> expectedMessages, final List<FIXMessage> actualMessages)
			throws FileNotFoundException, IOException {
		final File diffDirectory = new File("diffs");
		if (!diffDirectory.exists()) {
			diffDirectory.mkdir();
		}

		try (final BufferedWriter writer = new BufferedWriter(new FileWriter(_outputFilePath))) {
			writer.write(Diff.CSV_HEADER);
			writer.newLine();

			for (int i = 0; i < Math.max(expectedMessages.size(), actualMessages.size()); i++) {
				if (i >= expectedMessages.size()) {
					writer.write(Diff.unexpectedOrder(actualMessages.get(i).get(_idTag)).toCsvLine());
					writer.newLine();
				} else if (i >= actualMessages.size()) {
					writer.write(Diff.missingOrder(expectedMessages.get(i).get(_idTag)).toCsvLine());
					writer.newLine();
				} else {
					final List<Diff> diff = new FIXComparator().compare(expectedMessages.get(i), actualMessages.get(i));
					for (final Diff line : diff) {
						writer.write(line.toCsvLine());
						writer.newLine();
					}
				}
			}
		}
	}

	private List<FIXMessage> _parseFIXMessageFile(final String file) throws FileNotFoundException, IOException {
		final List<FIXMessage> messages = new ArrayList<>();
		final InputStream inputStream = "-".equals(file) ? System.in : new FileInputStream(file);
		try (final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
			@Nullable
			String line = null;
			do {
				line = reader.readLine();
				if (line != null && SimpleString.isNotEmpty.test(line)) {
					messages.add(new FIXMessage(line));
				}
			} while (line != null);
		}
		return messages;
	}
}
