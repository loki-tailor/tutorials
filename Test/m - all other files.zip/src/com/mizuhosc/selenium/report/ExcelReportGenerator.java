package com.mizuhosc.selenium.report;

import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import com.mizuhosc.selenium.*;

public class ExcelReportGenerator {
	public void generateExcelReport() throws ParserConfigurationException, SAXException, IOException {

		// String path =
		// ExcelReportGenerator.class.getClassLoader().getResource("./").getPath();
		final String path = Configuration.SINGLETON.getProperty("selenium.workspace.path");
		// final String CSVPath =
		// "I:/IT_WSD/FIX/Selenium.Automation/Scripts/CSV/";
		// final String CSVPath =
		// Configuration.SINGLETON.getProperty("selenium.csv.path");
		final String CSVPath = "./lokeshde/";
		// final String XMLPath =
		// Configuration.SINGLETON.getProperty("selenium.xmlfile.path");
		final String XMLPath = "./test-output/testng-results.xml";
		System.out.println("Found path : " + path);
		System.out.println("Found CSVPath : " + CSVPath);
		System.out.println("Found XMLPath : " + XMLPath);
		// path = path.replaceAll("src", "");

		// final File xmlFile = new File(path +
		// "/test-output/testng-results.xml");
		final File xmlFile = new File(XMLPath);
		System.out.println("XML reached :" + xmlFile.isFile());

		final DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
		final DocumentBuilder build = fact.newDocumentBuilder();
		final Document doc = build.parse(xmlFile);
		doc.getDocumentElement().normalize();

		final NodeList test_list = doc.getElementsByTagName("suite");

		for (int i = 0; i < test_list.getLength(); i++) {

			final Node test_node = test_list.item(i);
			final String test_name = ((Element) test_node).getAttribute("name");

			// added for permission case

			NodeList class_list;
			if (test_name.equals("Manual_RT_Global_Permission_Check"))

			{
				class_list = ((Element) test_node).getElementsByTagName("test");
			} else

			{
				class_list = ((Element) test_node).getElementsByTagName("class");
			}

			// Generate CSV

			final PrintWriter pw = new PrintWriter(new File(CSVPath + test_name + ".csv"));
			final StringBuilder sb = new StringBuilder();

			for (int j = 0; j < class_list.getLength(); j++) {

				final Node class_node = class_list.item(j);
				final String class_name = ((Element) class_node).getAttribute("name");
				final NodeList test_method_list = ((Element) class_node).getElementsByTagName("test-method");

				for (int k = 0; k < test_method_list.getLength(); k++) {
					final Node test_method_node = test_method_list.item(k);
					// String test_method_name =
					// ((Element)test_method_node).getAttribute("name");
					final String test_method_status = ((Element) test_method_node).getAttribute("status");

					String exp_msg = "No Exception";

					if ("fail".equalsIgnoreCase(test_method_status)) {
						final NodeList exp_list = ((Element) test_method_node).getElementsByTagName("exception");
						final Node exp_node = exp_list.item(0);
						exp_msg = ((Element) exp_node).getAttribute("class");

					}
					sb.append(class_name);
					sb.append(',');
					sb.append(test_method_status);
					sb.append(',');
					sb.append(exp_msg);
					sb.append('\n');

				}
				// pw.write(sb.toString());

			}
			pw.write(sb.toString());
			pw.close();
			System.out.println("done!");

		}

	}

	public static void main(final String[] args) throws ParserConfigurationException, SAXException, IOException {

		new ExcelReportGenerator().generateExcelReport();
		System.out.println("Excel");

	}

}
