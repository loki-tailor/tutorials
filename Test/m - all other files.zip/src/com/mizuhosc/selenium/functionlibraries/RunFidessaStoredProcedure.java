package com.mizuhosc.selenium.functionlibraries;

import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.scripts.util.*;
import com.mizuhosc.selenium.util.sql.Query;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;
import java.net.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;
import com.mizuhosc.selenium.functionlibraries.*;

public class RunFidessaStoredProcedure{

	private static final String driver =  Configuration.SINGLETON.getProperty("db.FIDESSA_DB.driver");
    private static final String url =  Configuration.SINGLETON.getProperty("db.FIDESSA_DB.url");
    private static final String username = Configuration.SINGLETON.getProperty("db.FIDESSA_DB.username");
    private static final String password = Configuration.SINGLETON.getProperty("db.FIDESSA_DB.password");
    //private static final String output = Configuration.SINGLETON.getProperty("db.FIDESSA_DB.output");
    private static String query = "";


    
	@Parameters({
        "output",
		"StoredProcedure",
        "iSC_operation",
        "iSC_admin_user",
        "iSC_operation_user",
        "instrument_id",
        "counterparty_id",
        "insider_type",
        "status",
        "validate_data",
        "read_date"
		})
	@Test
	public void InsiderTrading(
			final String output,
			final String StoredProcedure,
            final String iSC_operation,
            final String iSC_admin_user,
            final String iSC_operation_user,
            final String instrument_id,
            final String counterparty_id,
            final String insider_type,
            final String status,
            final String validate_data,
            final String read_date
		) throws UnknownHostException
	
	{
		String regist_date = CommonFunctions.getDate()	;
		String CurrentTimeStamp = CommonFunctions.getTimeStamp()	;
	    InetAddress iSC_workstationIP=InetAddress.getLocalHost();
	    String iSC_workstation=iSC_workstationIP.getHostName();
	    
	    String ActualOutput= output + CurrentTimeStamp;
		query = "exec " + StoredProcedure + " @iSC_operation ='" + iSC_operation + "',@iSC_admin_user = '" + iSC_admin_user + "',@iSC_workstation = '" + iSC_workstation + "',@instrument_id = '" + instrument_id + "',@counterparty_id = '" + counterparty_id +  "',@insider_type = '" + insider_type +  "',@regist_date = " + regist_date + ",@status = '" + status +  "',@validate_data = '" + validate_data +  "',@read_date = '" + read_date + "'";                                                             
		
		Reporter.log(String.format("[%s Will execute %s and output will be saved in %s",CommonFunctions.getTimeStamp(),query,output),true);
		
		Query.main(url, username, password, query, ActualOutput);
    
	}    
    
    
}



