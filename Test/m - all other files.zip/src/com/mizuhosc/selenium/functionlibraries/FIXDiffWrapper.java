package com.mizuhosc.selenium.functionlibraries;
import java.io.IOException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mizuhosc.selenium.diff.FIXDiff2;

public class  FIXDiffWrapper
	{

	
	@Parameters({"SuppliedFIXFile1","SuppliedFIXFile2","DiffFilePath"})
	@Test
	public void FIXDiffWrapper (
			final String SuppliedFIXFile1, final String SuppliedFIXFile2, final String DiffFilePath) throws IOException, InterruptedException

	{

		try 
		{
			
			Reporter.log(String.format("[%s File Comparision] Printing File1 (%s)", CommonFunctions.getTimeStamp(),
					SuppliedFIXFile1), true);
				CommonFunctions.printFileContents(SuppliedFIXFile1);
				
				Reporter.log(String.format("[%s File Comparision] Printing File1 (%s)", CommonFunctions.getTimeStamp(),
						SuppliedFIXFile2), true);
					CommonFunctions.printFileContents(SuppliedFIXFile2);
				
				Reporter.log(String.format("[%s Allocation File Comparision] Comparing above files %s and %s  and diff is kept in %s", CommonFunctions.getTimeStamp(),SuppliedFIXFile1,SuppliedFIXFile2,DiffFilePath ), true);
				FIXDiff2.main(new String[] {SuppliedFIXFile1, SuppliedFIXFile2, DiffFilePath });
				
				Thread.sleep(8000);
			
			
		}
		
		catch (IOException | InterruptedException e)
		{
			Reporter.log(String.format(
					"[%s Allocation File Comparision] ERROR Found %s Exception while comparing files %s and %s ", CommonFunctions.getTimeStamp(),e.getMessage(),SuppliedFIXFile1,SuppliedFIXFile2 ), true);
				Assert.fail("ERROR Found while comparing Allocation log files.Hence failing the case");

			
		}
		
	
	
	}
	
	}