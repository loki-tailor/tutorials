package com.mizuhosc.selenium.functionlibraries;

import java.text.SimpleDateFormat;

import javax.annotation.Nullable;

import org.testng.Reporter;
import com.mizuhosc.selenium.functionlibraries.CommonFunctions;
import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.scripts.util.*;

import static org.testng.Assert.assertTrue;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

import com.mizuhosc.quattro.util.value.SimpleString;

public class CommonFunctions {
	
	// Check order status of mentioned order
		public static void LoginToMonitoringSystem( WebDriver driver,String user,String pass,String monEnv) throws InterruptedException {
			driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			driver.findElement(By.name("username")).sendKeys(user);
			driver.findElement(By.name("password")).sendKeys(pass);
			driver.findElement(By.name("username")).submit();
			Thread.sleep(1000);

		}
		
		public static WebDriver DriverInvoke(String browser) throws InterruptedException {
			final ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("useAutomationExtension", false);

			WebDriver driver = null;
			if (browser.equals("Mozilla")) {
				driver = new FirefoxDriver();
			} else if (browser.equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
			} else if (browser.equals("IE")) {
				final File file = new File("drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver = new InternetExplorerDriver();
			}
			
			return driver;
		}
		
		
		
		public static void CloseDriver( WebDriver driver) throws InterruptedException {
			driver.close();

		}
	

	// Check order status of mentioned order
	public static Boolean CheckOrderStatus(String clOrderId, String expectedStatus, WebDriver driver) {
		final String ActualOrderStaus = driver
				.findElement(By.xpath("//*[@class='order-client-ref-id']//*[contains(text(),'" + clOrderId
						+ "')]/../../td[@class='order-status ']"))
				.getText();
		if (ActualOrderStaus.equalsIgnoreCase(expectedStatus)) {
			System.out.println("Order status is :" + ActualOrderStaus);
			Reporter.log(String.format("Order status is : %s", ActualOrderStaus, true));
			return true;
		} else {
			System.out.println("Order status is :" + ActualOrderStaus);
			Reporter.log(String.format("Order status is : %s", ActualOrderStaus, true));
			return false;
		}

	}

	public static String CheckViewFirstColumnByClOrderId(final String username,final String password,final String monEnv,final String viewName, final String clOrderId,final String ExpectedValue, WebDriver driver,final String WebDriverUsage)
			throws InterruptedException {
		
		if(WebDriverUsage=="TRUE")
		{
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
        driver = new ChromeDriver(options);
		driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
		driver.findElement(By.name("username")).sendKeys("selenium");
		driver.findElement(By.name("password")).sendKeys("password");
		driver.findElement(By.name("username")).submit();
		}
					    
		Thread.sleep(2000);	
		WebElement OrderViewsMenu = driver.findElement(By.xpath("//*[@id='orderViewsMenu']//*[@class='arrow']"));
		Thread.sleep(2000);
		OrderViewsMenu.click();
		Thread.sleep(2000);
		//a[@href='/orders?viewName=InsiderTrading']//*[contains(text(),"InsiderTrading")]
		WebElement View = driver.findElement(By.xpath("//a[@href='/orders?viewName=" + viewName +"']//*[contains(text(),'" + viewName +"')]"));
		Thread.sleep(2000);
		View.click();
		Thread.sleep(2000);
		final String ActualValue = driver
				.findElement(By.xpath("//*[@class='order-client-ref-id']//*[contains(text(),'" + clOrderId
						+ "')]/../../td[1]"))
				.getText();
		Thread.sleep(2000);
		System.out.println("Actual Value is %s :" + ActualValue);
		Reporter.log(String.format("Actual Value is : %s", ActualValue, true));

		System.out.println("Expected Value is %s :" + ExpectedValue);
		Reporter.log(String.format("Expected Value is : %s", ExpectedValue, true));
		
		if(WebDriverUsage=="TRUE")
		{
        driver.quit();
		}
		
		if (ActualValue.equalsIgnoreCase(ExpectedValue)) {
			return "Passed";
		} else {
			return "Failed";
		}
		
	}
	
	
			
	// Get TimeStamp for logging purposes
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	}
	
	public static String getDate() {
		return new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
	}


	// Print File Contents
	public static void printFileContents(final String file) throws FileNotFoundException, IOException {
		final InputStream inputStream = "-".equals(file) ? System.in : new FileInputStream(file);
		try (final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
			@Nullable
			String line = null;
			do {
				line = reader.readLine();
				if (line != null && SimpleString.isNotEmpty.test(line)) {
					Reporter.log(line, true);
				}
			} while (line != null);
		}
	}
   // Return the number of rows with in the supplied file 
	public static int CountRows(final String fileName) throws IOException {
		int rowCount = 0;
		final BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
		String input;
		while ((input = bufferedReader.readLine()) != null) {
			rowCount++;
		}
		bufferedReader.close();
		return rowCount;
	}
// Run a supplied windows batch command
	public static void RunWindowsBatchCommand(final String BatchFilePath, int WaitTime, final String ScriptsPath,
			final String LogsPath) throws IOException, InterruptedException {
		try {
			System.out.println("Running Batch Command -" + BatchFilePath + " " + ScriptsPath + " " + LogsPath);
			Runtime.getRuntime().exec("cmd /c start " + BatchFilePath + " " + ScriptsPath + " " + LogsPath);
			System.out.println("Sleeping for " + WaitTime);
			Thread.sleep(WaitTime);
		} catch (IOException | InterruptedException e) {
			Reporter.log(String.format(
					"ERROR Found while running batch command" + BatchFilePath + " " + ScriptsPath + " " + LogsPath,
					getTimeStamp(), e.getMessage()));

		}

	}

	
	
	public static void RunWindowsBatchCommand2(final String BatchFilePath, final String ScriptsPath,
			final String LogsPath, final String ScriptName,final String LogFileName, int WaitTime) throws IOException, InterruptedException {
		try {
			System.out.println("Running Batch Command - " + BatchFilePath + " " + ScriptsPath + " " + LogsPath + " " + ScriptName + " " + LogFileName);
			Runtime.getRuntime().exec("cmd /c start " + BatchFilePath + " " + ScriptsPath + " " + LogsPath + " " + ScriptName + " " + LogFileName);
			System.out.println("Sleeping for " + WaitTime);
			Thread.sleep(WaitTime);
		} catch (IOException | InterruptedException e) {
			Reporter.log(String.format(
					"ERROR Found while running batch command" + BatchFilePath + " " + ScriptsPath + " " + LogsPath + " " + ScriptName + " " + LogFileName,
					getTimeStamp(), e.getMessage()));

		}

	}
	
	
	public static void ResetSession(final String SessionName,final String BatchFilePath,final String ScriptsPath, final String LogsPath,  int WaitTime) throws IOException, InterruptedException {
//		final String BatchFilePath = Configuration.SINGLETON.getProperty("selenium.Automation.ResetSessionBatchFile");
//	 final String ScriptsPath = Configuration.SINGLETON.getProperty("selenium.Automation.Scripts.path");
//		final String LogsPath = Configuration.SINGLETON.getProperty("selenium.Automation.Logs.path");
		try {
			
			System.out.println("Running Batch Command -" + BatchFilePath + " " + ScriptsPath + " " + LogsPath  + " " + SessionName);
			Runtime.getRuntime().exec("cmd /c start " + BatchFilePath + " " + ScriptsPath + " " + LogsPath + " " + SessionName);
			System.out.println("Sleeping for " + WaitTime);
			Thread.sleep(WaitTime);
		} catch (IOException | InterruptedException e) {
			Reporter.log(String.format(
					"ERROR Found while running batch command"  + BatchFilePath + " " + ScriptsPath + " " + LogsPath + " " + SessionName ,
					getTimeStamp(), e.getMessage()));

		}

	}	
	
	// Get release version of QA10, to update marathon result

		
	public static String GetReleaseVersion() {

		final WebDriver localdriver;
		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");

		localdriver = new ChromeDriver(options);
		localdriver.get("http://tkqtrapq2:8000/FidessaConnectivity.html");

		final WebElement fetchData = localdriver
				.findElement(By.xpath("//*[@id='env-status']/tbody/tr/td[1][contains(.,'QA10')]//..//td[3]"));
		String releaseVersion = fetchData.getText();
		//String actualreleaseVersion = releaseVersion.subSequence(3, 9).toString();
		Reporter.log(String.format("Release version %s ruuning on QA10", releaseVersion));
		localdriver.quit();
		return releaseVersion;
	}

	// Update marathon test result

	public static void updateResult(final int caseId, final String releaseVersion, final String marathonResult,
			final String TestResultString, final String JIRA_Number, WebDriver driver,
			final String WebDriverUsage) {
		try {
			// testResult();// setting test result message based on File and UI
			// checks
			// If WebDriverUsage is true (In case of Allocation testing) , then create new webdriver 
			//otherwise(In most of the cases) use the existing one
			Reporter.log(String.format("[%s Marathon] Updating Marathon test result as %s for test case %s", getTimeStamp(),TestResultString,caseId), true);
			// Get release version for QA10- from release version dash board and update Marathon case
               
			if(WebDriverUsage=="TRUE")
			{ 
				final ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("useAutomationExtension", false);
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver = new ChromeDriver(options);
				driver.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + caseId);
				Thread.sleep(1000);
			    driver.findElement(By.name("username")).sendKeys("selenium");
				driver.findElement(By.name("password")).sendKeys("password");
				driver.findElement(By.name("username")).submit();
				
			}
			else
			{
				driver.get("http://tkqtrapq18.mizuho-sc.com:9090");
				Thread.sleep(2000);
			    driver.findElement(By.name("username")).sendKeys("selenium");
				driver.findElement(By.name("password")).sendKeys("password");
				driver.findElement(By.name("username")).submit();
				Thread.sleep(2000);
				driver.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + caseId);
			}
			
			System.out.println("Before entering Results");
			Reporter.log(String.format("Before entering Results"), true);
			
			driver.findElement(By.xpath("//*[contains(text(),'Enter Result')]")).click();
			Thread.sleep(1000);

			Reporter.log(String.format("After entering Results"), true);
			
			driver.findElement(By.xpath("//*[contains(text(),'Edit')]")).click();
			Thread.sleep(1000);
			
			Reporter.log(String.format("After Clicking Edit"), true);
			
			driver.findElement(By.xpath("//*[contains(text(),'" + marathonResult + "')]")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input"))
					.sendKeys(String.format("%s on %s", TestResultString, releaseVersion));
			driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input"))
					.sendKeys(JIRA_Number);
			driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
			Thread.sleep(3000);
			Reporter.log(String.format("[%s Marathon] Marathon TestCase %s %s ReleaseVersion %s.", getTimeStamp(),
					caseId, marathonResult, releaseVersion), true);
			driver.quit();

		} catch (final Exception e) {
			Reporter.log(String.format("[%s Marathon] ERROR %s Exception found when updating Marathon test result.",
					getTimeStamp(), e.getMessage()));
		}
	}
	

	//Function to update/Revert on Version screen
	
	public static void  RevertRestore(String OperationName, WebDriver driver) throws InterruptedException 
	{
	
		WebElement VersionButton=driver.findElement(By.xpath("//*[@id='version-button']"));
		//*[@id="q-render-table-version-table"]/tbody/tr[1]/td[3]
		VersionButton.click();
		Thread.sleep(10000);		
		WebElement SelectFirstRow=driver.findElement(By.xpath("//*[@id='q-render-table-version-table']/tbody/tr[1]/td[3]"));
		Actions Action = new Actions(driver);
		Action.contextClick(SelectFirstRow).sendKeys(Keys.RETURN).build().perform();
		Thread.sleep(2000);		
		WebElement OperationButton=driver.findElement(By.xpath("//q-button[@id='"+OperationName+"-commit-button']"));
		
		OperationButton.click();
		Thread.sleep(2000);	
		driver.switchTo().alert().accept();
		Thread.sleep(6000);
				
	}
	

	
	//Function to add 'Reject order validator ' to client ,session or destination
	
	public static void PluginAdd(WebDriver driver)
	{
		try
		{
			// select value in dropdown plugin
			// WebElement PluginDropdown = driver.findElement(By.xpath("//*[@name='pluginId']"));
			final WebElement PluginDropdown = driver.findElement(By.xpath("//*[@id='new-plugin-id']"));
			final Select select = new Select(PluginDropdown);
			select.selectByVisibleText("Reject Order Validator");
			
			// click Add button
			final WebElement AddButton = driver.findElement(By.xpath("//*[@id='add-plugin-attachment']"));
			AddButton.click();
			
			Thread.sleep(3000);
			final WebElement RejectionMessage = driver.findElement(By.xpath(
				"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Reject Order Validator')]/../table[@class='content horizontal']//tr[1]//td[4]"));
			
			final Actions action = new Actions(driver);
			action.moveToElement(RejectionMessage);
			action.click();
			action.sendKeys("tests");
			action.build().perform();
			// Click on save button
			final WebElement SaveButton = driver.findElement(By.xpath(
				"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Reject Order Validator')]/../../..//*[@class='q-attachment-buttons']//*[@class='save-q-attachment']"));
			SaveButton.click();
			Thread.sleep(2000);
			
			final WebElement MsgBoxText = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-content']/textarea"));
			MsgBoxText.sendKeys("test");
			Thread.sleep(1000);
			// click on ok button on dialogue box..
			final WebElement MsgBoxTextOk = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-control-button']/../q-button[@dialog-action='ok']"));
			MsgBoxTextOk.click();
			
			Thread.sleep(10000);
		}
		catch(final InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}
	//Function to remove 'Reject order validator ' to client ,session or destination
	
	public static void PluginRemove(WebDriver driver)
	{ //edit-q-attachment
		// click on Edit button
		final WebElement EditButton = driver.findElement(By.xpath(
			"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Reject Order Validator')]/../.././/*[@class='q-attachment-buttons']/*[@class='edit-q-attachment']"));
		EditButton.click();
		
		final WebElement RemoveButton = driver.findElement(By.xpath(
			"//*[@id='plugin-attachment-container']/q-attachment//h2[contains(.,'Reject Order Validator')]/../../..//*[@class='q-attachment-buttons']//*[@class='remove-q-attachment']"));
		RemoveButton.click();
		
		driver.switchTo().alert().accept();
		try
		{
			Thread.sleep(1000);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
		
		final WebElement MsgBoxText = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-content']/textarea"));
		MsgBoxText.sendKeys("test");
		
		// click on ok button on dialogue box..
		final WebElement MsgBoxTextOk = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-control-button']/../q-button[@dialog-action='ok']"));	
		MsgBoxTextOk.click();
		
	}
	
	
	
	
	public static void ReportPositiveResult (final String ActionName, final String Result)
	{
		
		String PositivetestResultString = "Action - "+ ActionName + " Passed";
		String NegativetestResultString = "Action - "+ ActionName + " Failed";
		if (Result == "Failed")
		{
			Reporter.log(String.format("[%s Exception] %s ",getTimeStamp(),NegativetestResultString),true);
			Assert.fail("NegativetestResultString");				
			
		}
		else
		{
			Reporter.log(String.format("[%s Exception] %s ",getTimeStamp(),PositivetestResultString),true);
			
		}
			
		
		
	}
	
	
	public static void ReportNegativeResult (final String ActionName, final String Result)
	{
		
		String PositivetestResultString = "Action - "+ ActionName + " Passed";
		String NegativetestResultString = "Action - "+ ActionName + " Failed";
		if (Result == "Failed")
		{
			Reporter.log(String.format("[%s Exception] %s ",getTimeStamp(),PositivetestResultString),true);
			
		}
		else
		{
			Reporter.log(String.format("[%s Exception] %s ",getTimeStamp(),NegativetestResultString),true);
			Assert.fail("NegativetestResultString");			
		}
			
		
		
	}
	
	public static String  RighClickActionMonitoringGUI(final String user,final String pass,final String monEnv,final String ClOrderId,final String RightClickActionName, WebDriver localdriver,
			final String WebDriverUsage) throws InterruptedException
	{
		
		System.out.println("localdriver-1" + localdriver);			    
		Thread.sleep(2000);	

		System.out.println("localdriver-3 " + localdriver);
		
		WebElement waitForOrder =
				new WebDriverWait(localdriver, 45)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'" + ClOrderId + "')]")));// 20:21:28.
		
		
		System.out.println("waitForOrder " + waitForOrder);
			  
			//WebElement webElement = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
		    WebElement webElement = localdriver.findElement(By.xpath("//*[contains(text(),'" + ClOrderId + "')]"));
		    
		    System.out.println("webElement " + webElement);

			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-1 ",getTimeStamp()), true);
			Actions rightClickAction = new Actions(localdriver);
				// Do the first right-click on the the first order
			
			try {
		
			System.out.println("Actions rightClickAction" + rightClickAction);
			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-2 ",getTimeStamp()), true);
			rightClickAction.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			}
			catch(final Exception e)
			{
				
				System.out.println("Printing - " + e);
				
			}
			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-3 ",getTimeStamp()), true);
			Thread.sleep(2000);	
			List<WebElement> rightClickActionElementList = localdriver.findElements(By.xpath("//*[@id='" + RightClickActionName + "']")); // Find out Id of RightClickAction
			System.out.println("rightClickActionElementList" + rightClickActionElementList);
			Thread.sleep(2000);	
			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-4 ",getTimeStamp()), true);
			
			Thread.sleep(2000);
			System.out.println("rightClickActionElementList size is - " + rightClickActionElementList.size() + "for action name" + RightClickActionName);
			
			// Checking if the RighClickAction Item is available or not. Return Failed , in case is not available otherwise return Passed
			
			
			if (rightClickActionElementList.size() == 0 )
			{
				Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-5 ",getTimeStamp()), true);
				Reporter.log(String.format("[%s Right Click] Right Click ActionItem %s Not Available.Hence returing Failed",getTimeStamp(), RightClickActionName), true);
				
				if(WebDriverUsage=="TRUE")
				{ 
					localdriver.quit();
					
				}
			return "Failed";
		
			}
			
			else
				
			{
				Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-6 ",getTimeStamp()), true);
				WebElement rightClickActionElement = localdriver.findElement(By.xpath("//*[@id='" + RightClickActionName + "']")); // Find out Id of RightClickAction
				System.out.println("rightClickActionElement" + rightClickActionElement);
				Reporter.log(String.format("[%s Right Click] WebElement %s ",getTimeStamp(), rightClickActionElement), true);
				rightClickAction.moveToElement(rightClickActionElement);
				
				try{
					rightClickAction.click();
					rightClickActionElement.click();
				Thread.sleep(2000);
				//Assert.fail("Add Order Notes Right Click Menu option available on the Active Order. So failing the Selenium case");
				Reporter.log(String.format("[%s Right Click] RightClickActionName  %s is clickable ",getTimeStamp(),RightClickActionName), true);
				return "Passed";
			    }
			   catch (Exception e)
			    {
				   Reporter.log(String.format("[%s Right Click] RightClickActionName  %s is not clickable ",getTimeStamp(),RightClickActionName), true);
				   return "Failed";			
			    }
				
			}

			
		
	}
	

	
	public static String  RighClickCheckMonitoringGUI(final String user,final String pass,final String monEnv,final String ClOrderId,final String RightClickActionName, WebDriver localdriver,
			final String WebDriverUsage) throws InterruptedException
	{
		
		System.out.println("localdriver-1" + localdriver);			    
		Thread.sleep(2000);	
		if(WebDriverUsage=="TRUE")
		{ 
			final ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("useAutomationExtension", false);
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			localdriver = new ChromeDriver(options);
			localdriver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
			System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
			localdriver.findElement(By.name("username")).sendKeys(user);
			localdriver.findElement(By.name("password")).sendKeys(pass);
			localdriver.findElement(By.id("signin")).submit();
			System.out.println("localdriver-2" + localdriver);
		}

		System.out.println("localdriver-3 " + localdriver);
		
		WebElement waitForOrder =
				new WebDriverWait(localdriver, 45)
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'" + ClOrderId + "')]")));// 20:21:28.
		
		
		System.out.println("waitForOrder " + waitForOrder);
			  
			//WebElement webElement = driver.findElement(By.xpath("//*[@id='q-render-table-order-list']//tr[1]//td[5]"));
		    WebElement webElement = localdriver.findElement(By.xpath("//*[contains(text(),'" + ClOrderId + "')]"));
		    
		    System.out.println("webElement " + webElement);

			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-1 ",getTimeStamp()), true);
			
				// Do the first right-click on the the first order
			
			try {
			Actions rightClickAction = new Actions(localdriver);
			System.out.println("Actions rightClickAction" + rightClickAction);
			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-2 ",getTimeStamp()), true);
			rightClickAction.contextClick(webElement).sendKeys(Keys.RETURN).build().perform();
			}
			catch(final Exception e)
			{
				
				System.out.println("Printing - " + e);
				
			}
			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-3 ",getTimeStamp()), true);
			Thread.sleep(2000);	
			List<WebElement> rightClickActionElementList = localdriver.findElements(By.xpath("//*[@id='" + RightClickActionName + "']")); // Find out Id of RightClickAction
			System.out.println("rightClickActionElementList" + rightClickActionElementList);
			Thread.sleep(2000);	
			Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-4 ",getTimeStamp()), true);
			
			System.out.println("rightClickActionElementList size is - " + rightClickActionElementList.size() + "for action name" + RightClickActionName);
			
			// Checking if the RighClickAction Item is available or not. Return Failed , in case is not available otherwise return Passed
			
			
			if (rightClickActionElementList.size() == 0 )
			{
				Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-5 ",getTimeStamp()), true);
				Reporter.log(String.format("[%s Right Click] Right Click ActionItem %s Not Available.Hence returing Failed",getTimeStamp(), RightClickActionName), true);
				
				if(WebDriverUsage=="TRUE")
				{ 
					localdriver.quit();
					
				}
			return "Failed";
		
			}
			
			else
				
			{
				Reporter.log(String.format("[%s Right Click] ClOrderId appeared in Monitoring GUI-6 ",getTimeStamp()), true);

				WebElement rightClickActionElement = localdriver.findElement(By.xpath("//*[@id='" + RightClickActionName + "']")); // Find out Id of RightClickAction
				System.out.println("rightClickActionElement" + rightClickActionElement);
				Reporter.log(String.format("[%s Right Click] WebElement %s ",getTimeStamp(), rightClickActionElement), true);
				
				try{
				rightClickActionElement.click();
				Thread.sleep(2000);
				//Assert.fail("Add Order Notes Right Click Menu option available on the Active Order. So failing the Selenium case");
				Reporter.log(String.format("[%s Right Click] RightClickActionName  %s is clickable ",getTimeStamp(),RightClickActionName), true);

				Reporter.log(String.format("[%s Right Click] Right Click ActionItem %s Available.Hence returing Passed",getTimeStamp(), RightClickActionName), true);

				if(WebDriverUsage=="TRUE")
				{ 
					localdriver.quit();
					
				}
				return "Passed";
			    }
			   catch (Exception e)
			    {
				   Reporter.log(String.format("[%s Right Click] RightClickActionName  %s is not clickable ",getTimeStamp(),RightClickActionName), true);
				   return "Failed";			
			    }
				
			}

			
		
	}

	
	
	
	
	public static void addOrderNotes(final String text,final String monEnv, WebDriver driver,
			final String WebDriverUsage) throws InterruptedException
	{
	
		Thread.sleep(1000);
		WebElement addOrderNotesTextBox = driver.findElement(By.xpath("//*[@id='dialog-container']/div/div[2]/input")); // Find out Id of Add OrderNotes right
		addOrderNotesTextBox.click();
		Thread.sleep(1000);
		//driver.findElement(By.xpath("//*[@id='dialog-container']/div/div[2]/input")).sendKeys("Adding order notes for test1");
	
		driver.findElement(By.xpath("//*[@id='dialog-container']/div/div[2]/input")).sendKeys("" + text + "");
		
		System.out.println("Waiting for Text to be passed to Add OrderNotes Dialogue Box");
		Reporter.log(String.format("[%s AddOrderNotes Dialogue Box] Waiting for Text to be passed to Add OrderNotes Dialogue Box",getTimeStamp()), true);
		
		System.out.println("Sleeping for 2 secs");
		Reporter.log("[%s AddOrderNotes Dialogue Box] Sleeping for 2 secs");
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException e2)
		{
			e2.printStackTrace();
		}
	
		System.out.println("Text is passed to Add OrderNotes Dialogue Box");
		Reporter.log(String.format("[%s AddOrderNotes Dialogue Box] Text is passed to Add OrderNotes Dialogue Box",getTimeStamp()), true);
		// Click on OK button
		WebElement OKBox = driver.findElement(By.xpath("//*[@id='dialog-container']/div/div[3]/q-button[2]"));
		OKBox.click();
		
		System.out.println("Sleeping for 2 secs to click on OK Box");
		Reporter.log(String.format("[%s OK Button] Sleeping for 2 secs to click on OK Box",getTimeStamp()), true);
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException e2)
		{
			e2.printStackTrace();
			
		}
		
		System.out.println("OK Box Clicked");
		Reporter.log(String.format("[%s OK Button] OK Box Clicked",getTimeStamp()), true);

	}
	
	
	public static void updateResult2(final int caseId, final String releaseVersion,final String JIRA_Number,  String testResultString,
			final String InsertOrUpdate,WebDriver driver) {
		try {
			
			// Paramtere: 1.caseId 
			// Paramtere: 2.releaseVersion=Which release we are testing
			// Paramtere: 3.JIRA_Number = Rleated Jira should be given 
			// Paramtere: 4.testResultString = Result string for particular scenario
			// Paramtere: 5.InsertOrUpdate = 'Insert' would be used when this function is called first time , otherwise 'update'
			
			
			String VerifyFailedMarathonString = "Failed";
			String finalTestResultString = "";
			String marathonResult=null;
			
		
			driver.get("http://tkqtrapq18.mizuho-sc.com:9090");
			Thread.sleep(2000);
		    driver.findElement(By.name("username")).sendKeys("selenium");
			driver.findElement(By.name("password")).sendKeys("password");
			driver.findElement(By.name("username")).submit();
			Thread.sleep(2000);
			driver.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + caseId);
			Reporter.log(String.format("[%s Marathon] Updating Marathon test result.", getTimeStamp()), true);
			if(InsertOrUpdate.equals("Update")) 
			{ 
				WebElement RundateRow=driver.findElement(By.xpath("//h3[contains(.,'Result History')]//../table/thead/tr/th[contains(text(),'Run Date')]//../../../tbody/tr[1]/td[2]"));
				
				RundateRow.click();
				
				WebElement Comment=driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span[2]"));
					String Commenttext=Comment.getText();
					finalTestResultString=testResultString + Commenttext + "|";
			}
			else
			{
				finalTestResultString=testResultString + "|" + releaseVersion;
				//driver.findElement(By.xpath("//*[contains(text(),'Enter Result')]")).click();
				
			}

			driver.get("http://tkqtrapq18.mizuho-sc.com:9090/case/" + caseId);
			
			Thread.sleep(1000);
			
			if ( finalTestResultString.indexOf(VerifyFailedMarathonString) != -1 ) 	{	
				Reporter.log(String.format("[%s Found the VerifyFailedMarathonString - %s in testResultString - %s. Will fail the Marathon Case",CommonFunctions.getTimeStamp(),VerifyFailedMarathonString, testResultString),true);
				marathonResult="Failed";
				}
		    else {
		    	Reporter.log(String.format("[%sNot Found the VerifyFailedMarathonString - %s in testResultString - %s. Will Pass the Marathon Case",CommonFunctions.getTimeStamp(),VerifyFailedMarathonString, testResultString),true);
				marathonResult="Passed";
				
				}
			
			if(InsertOrUpdate.equals("Update")) 
			{ 
				WebElement RundateRow=driver.findElement(By.xpath("//h3[contains(.,'Result History')]//../table/thead/tr/th[contains(text(),'Run Date')]//../../../tbody/tr[1]/td[2]"));
				RundateRow.click();
			}
			else
			{
				driver.findElement(By.xpath("//*[contains(text(),'Enter Result')]")).click();
			}
			
			

			//BasicUpdateResult(driver,marathonResult,testResultString, JIRA_Number);
 		
		} 
		catch (Exception e)
		{
			Reporter.log(String.format("[%s Marathon] ERROR %s Exception found when updating Marathon test result.",
					getTimeStamp(), e.getMessage()));
		}
	}

	public static void BasicUpdateResult(WebDriver driver,String marathonResult ,String testResultString,String JIRA_Number) throws InterruptedException
	{
		

		driver.findElement(By.xpath("//*[contains(text(),'" + marathonResult + "')]")).click();
	//	if(InsertOrUpdate.equals("Insert")) 
	//	{driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input"))
	//			.sendKeys(String.format("%s on %s",  releaseVersion,testResultString));
	//	}
	//	else
		{driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[5]/td[2]/span/input"))
			.sendKeys(String.format("%s",testResultString));
			
		}
		driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input"))
		.clear();
		driver.findElement(By.xpath("/html/body/div[3]/table/tbody/tr[6]/td[2]/span[2]/input"))
				.sendKeys(JIRA_Number);
		driver.findElement(By.xpath("//*[contains(text(),'Save')]")).click();
	}

	public static void ReloadButton(WebDriver driver)
	{
		try
		{
			System.out.println("clcik reload");
			// Click on Reload button
			final WebElement ReloadButton = driver.findElement(By.xpath("//*[contains(text(),'Reload') and @class]"));
			ReloadButton.click();
			System.out.println("reload clicked");
			
			Thread.sleep(1000);
			
			driver.switchTo().alert().accept();
			System.out.println("Alert visible");
			
			Thread.sleep(1000);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
	}
	
	
	public static void NavigateClientSession(WebDriver driver,String ClientSesionXpath, String PluginActionServer) throws InterruptedException
	{
		Reporter.log(String.format("[%s NavigateClientSession:] Navigation to client or session", CommonFunctions.getTimeStamp()), true);
		driver.get(ClientSesionXpath);
		Reporter.log(String.format("[%s NavigateClientSession:] Navigated to client or session", CommonFunctions.getTimeStamp()), true);
	}
	
	public static void SearchForPlugin(WebDriver driver,String PluginName,String PluginActionServer) throws InterruptedException
	{
		// select value in dropdown plugin
		Reporter.log(String.format("[%s SelectPlugin:] Selecting a plugin", CommonFunctions.getTimeStamp()), true);
		final  WebElement PluginSearchBoxClick = driver.findElement(By.xpath("//*[@id='tab-search']/trigger/q-button"));
		PluginSearchBoxClick.click();
//		final WebElement PluginSelect = driver.findElement(By.xpath("//*[@id='dropdown-menu']//*[contains(text(),'"+PluginName+"')]"));
		//final WebElement PluginSelect = driver.findElement(By.xpath("//action[contains(text(),'"+PluginName+"')]"));
		//PluginSelect.click();
		
		final  WebElement TextBox = driver.findElement(By.xpath("//*[@id='tab-search']//input"));
		TextBox.sendKeys(PluginName);
		Thread.sleep(2000);
			
		final WebElement PluginDropdown = driver.findElement(By.cssSelector("#hint-drop-down-list .input-hint"));
     	PluginDropdown.click();
     	
//     	final List<WebElement>  HighlightCheck = driver.findElements(By.cssSelector("q-block.highlight"));
//     	if(HighlightCheck.size()>0)
//     	{Reporter.log(String.format("[%s SelectPlugin:] Plugin Identified on the respective tab", CommonFunctions.getTimeStamp()), true);
//     	}
//     	else
//     	{
//     		Reporter.log(String.format("[%s SelectPlugin:] Plugin NOT Identified on the respective tab", CommonFunctions.getTimeStamp()), true);
//     	}
//     	
     	
	}
     	
	
	public static void AttachPlugin(WebDriver driver,String PluginName,String PluginActionServer) throws InterruptedException
	{
		Reporter.log(String.format("[%s AttachPlugin:] Attaching the Plugin ", CommonFunctions.getTimeStamp()), true);
//		final  WebElement AttachButton = driver.findElement(By.cssSelector("#plugin-attachments > q-blocks > q-block-group:nth-child(44) > q-block-row > q-button"));
//		AttachButton.click();
		final WebElement AttachButton = driver.findElement(By.cssSelector("q-block.highlight + q-button"));
		AttachButton.click();
		  
		Reporter.log(String.format("[%s AttachPlugin:] Plugin Attached", CommonFunctions.getTimeStamp()), true);
}
	
	public static void UpdatePlugin(WebDriver driver,String  PluginName,String PluginActionServer,String PluginParamterXpath,String PluginParamterValue)
	{
		try
		{ Reporter.log(String.format("[%s UpdatePlugin:] Updating a plugin", CommonFunctions.getTimeStamp()), true);
				
			Thread.sleep(3000);
			final WebElement UpdateTextField = driver.findElement(By.xpath(PluginParamterXpath));
			final Actions action = new Actions(driver);
			action.moveToElement(UpdateTextField);
			action.click();
			action.sendKeys(Keys.chord(Keys.CONTROL, "a"), PluginParamterValue);
//			action.sendKeys(PluginParamterValue);
			action.build().perform();
			// Click on save button
				
			Thread.sleep(10000);
			 Reporter.log(String.format("[%s UpdatePlugin:] Plugin updated", CommonFunctions.getTimeStamp()), true);
		}
		catch(final InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	
	public static void SaveChanges(WebDriver driver,String PluginActionServer,String PluginParamterValue)
	{
		try
		{   Reporter.log(String.format("[%s SaveChanges:] Saving changes on screen", CommonFunctions.getTimeStamp()), true);
			// Click on save button
			final WebElement SaveButton = driver.findElement(By.xpath("//*[@id='save-entity-button']"));
			SaveButton.click();
			Thread.sleep(2000);
			
			final WebElement MsgBoxText = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-content']/textarea"));
			MsgBoxText.sendKeys(PluginParamterValue);
			Thread.sleep(1000);
			// click on ok button on dialogue box..
			final WebElement MsgBoxTextOk = driver.findElement(By.xpath("//*[@id='dialog-container']/..//*[@class='dialog-control-button']/../q-button[@dialog-action='ok']"));
			MsgBoxTextOk.click();
			
			Thread.sleep(10000);
			 Reporter.log(String.format("[%s SaveChanges:]  changes on screen saved", CommonFunctions.getTimeStamp()), true);
		}
		catch(final InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void ReloadPlugin(WebDriver driver,String PluginActionServer)
	{
		try
		{ Reporter.log(String.format("[%s ReloadPlugin:]  Reloading changes", CommonFunctions.getTimeStamp()), true);
			System.out.println("clcik reload");
			// Click on Reload button
			final WebElement ReloadButton = driver.findElement(By.xpath("//*[contains(text(),'Reload') and @class]"));
			ReloadButton.click();
			System.out.println("reload clicked");
			
			Thread.sleep(1000);
			
			driver.switchTo().alert().accept();
			System.out.println("Alert visible");
			
			Thread.sleep(1000);
			Reporter.log(String.format("[%s ReloadPlugin:]   changes reloaded", CommonFunctions.getTimeStamp()), true);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
	}
	
	public static void EditScreen(WebDriver driver,String PluginActionServer)
	{ //edit-q-attachment
		// click on Edit button
		Reporter.log(String.format("[%s EditScreen:]  Edit screen", CommonFunctions.getTimeStamp()), true);
		final WebElement EditButton = driver.findElement(By.xpath("//*[@id='edit-detail-edit-buttons']"));
		EditButton.click();
		Reporter.log(String.format("[%s EditScreen:]  screen in editable mode", CommonFunctions.getTimeStamp()), true);
	}
	
	public static void SelectPluginTab(WebDriver driver,String PluginTabXpath) throws InterruptedException
	{Reporter.log(String.format("[%s SelectPluginTab:]  Selecting plugin tab on screen", CommonFunctions.getTimeStamp()), true);
		Thread.sleep(1000);
		final WebElement PluginTab = driver.findElement(By.xpath(PluginTabXpath));
		PluginTab.click();
		
		Reporter.log(String.format("[%s SelectPluginTab:]   plugin tab on screen selected", CommonFunctions.getTimeStamp()), true);
	}
	
	public static void RemovePlugin(WebDriver driver,String  PluginName,String PluginActionServer,String PluginParamterValue) throws InterruptedException
	{ //edit-q-attachment
		Reporter.log(String.format("[%s RemovePlugin:]  Removing plugin  on screen", CommonFunctions.getTimeStamp()), true);
		Thread.sleep(1000);
		final WebElement RemoveButton = driver.findElement(By.xpath("//*[@type='com.mizuhosc.quattro.orderengine.plugins.validator.RejectOrderValidator']//q-button[@class='detach-block']"));
		RemoveButton.click();
		Thread.sleep(500);
		driver.switchTo().alert().accept();
		try
		{
			Thread.sleep(1000);
		}
		catch(final InterruptedException e2)
		{
			e2.printStackTrace();
		}
		
		Reporter.log(String.format("[%s RemovePlugin:]  plugin  on screen removed", CommonFunctions.getTimeStamp()), true);
	}
	
	
}
