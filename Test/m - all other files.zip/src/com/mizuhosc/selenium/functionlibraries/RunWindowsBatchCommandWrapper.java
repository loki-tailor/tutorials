package com.mizuhosc.selenium.functionlibraries;

import java.io.IOException;

import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mizuhosc.quattro.util.value.*;


public class RunWindowsBatchCommandWrapper
{
	
	@Parameters({"BatchFilePath","ScriptsPath","LogsPath", "ScriptName", "LogFileName", "WaitTime"})
	@Test
	public void RunWindowsBatchCommandWrapper (
			final String BatchFilePath,
			final String ScriptsPath,
			final String LogsPath,
			final String ScriptName,
			final String LogFileName,
			final int WaitTime
		) throws IOException, InterruptedException

	{
		CommonFunctions.RunWindowsBatchCommand2(BatchFilePath, ScriptsPath, LogsPath, ScriptName,LogFileName,WaitTime);
	}
	

	
}