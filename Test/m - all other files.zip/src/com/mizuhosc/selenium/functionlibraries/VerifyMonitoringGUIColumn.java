package com.mizuhosc.selenium.functionlibraries;

import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.scripts.util.*;
import com.mizuhosc.selenium.util.sql.Query;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;
import java.net.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;
import com.mizuhosc.selenium.functionlibraries.*;

public class VerifyMonitoringGUIColumn
{
	
	WebDriver driver = null;
	
	@Parameters({"caseId","jiraId","username", "password", "quattroEnv", "browser", "ClOrderId", "ViewName", "FirstColumnValue","testcasename"})
	@Test
	public void VerifyMonitoringGUIColumn (
			final int caseId,final String JIRA_Number, final String user, final String pass, final String monEnv, final String browser, final String clOrderid, final String ViewName, final String FirstColumnValue,final String testcasename
		) throws IOException, InterruptedException

	{

		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		
		if(browser.equals("Mozilla"))
		{
			driver = new FirefoxDriver();
		}
		else if(browser.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
		}
		else if(browser.equals("IE"))// Internet Explorer Driver
		{
			final File file = new File("drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
		}
//		driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
//		System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
//		driver.findElement(By.name("username")).sendKeys(user);
//		driver.findElement(By.name("password")).sendKeys(pass);
//		driver.findElement(By.id("signin")).submit();
//		
		try
		{
			// Selects appropriate browser as declared by user in global declaration
			String orderStatusResult=CommonFunctions.CheckViewFirstColumnByClOrderId(user,pass,monEnv,ViewName,clOrderid,FirstColumnValue, driver, "TRUE");
			Reporter.log(String.format("[%s Exception] TestCase is %s ",CommonFunctions.getTimeStamp(),orderStatusResult),true);
			String releaseVersion=CommonFunctions.GetReleaseVersion();
			String testResultString="TestCase " + testcasename +" "+ orderStatusResult;
			CommonFunctions.updateResult(caseId, releaseVersion, orderStatusResult, testResultString, JIRA_Number, driver, "TRUE");			
			//System.out.println("Expected Value is %s :" + ExpectedValue);
			Reporter.log(String.format("[%s Exception] TestCase %s is %s ",CommonFunctions.getTimeStamp(),testcasename,orderStatusResult),true);
		
		}	
		catch(final Exception e)
		{
			    //Reporter.log(String.format("[%s Exception] Case could not be checked properly due to an exception thrown by Browser ",CommonFunctions.getTimeStamp()),true);
				Assert.fail("Exception details are  " + e.getMessage());
				driver.quit();
				
		}
		
	}
	
}