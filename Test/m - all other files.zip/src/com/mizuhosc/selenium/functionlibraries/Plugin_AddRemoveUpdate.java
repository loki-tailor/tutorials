package com.mizuhosc.selenium.functionlibraries;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Plugin_AddRemoveUpdate {

	WebDriver driver = null;
	
	@Parameters({"username", "password", "quattroEnv", "browser", "PluginAction", "PluginActionServer", "PluginName","PluginParamterXpath" ,"PluginParamterValue","ClientSesionXpath" ,"PluginTabXpath"})
	@Test
	public void Plugin_AddRemoveUpdate (
			 final String user, final String pass, final String monEnv, final String browser, final String PluginAction, final String PluginActionServer, final String PluginName,final String PluginParamterXpath ,final String PluginParamterValue,final String ClientSesionXpath, final String PluginTabXpath
) throws IOException, InterruptedException

	{

		final ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		
		if(browser.equals("Mozilla"))
		{
			driver = new FirefoxDriver();
		}
		else if(browser.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
		}
		else if(browser.equals("IE"))// Internet Explorer Driver
		{
			final File file = new File("drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
		}
		driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
		System.out.println("!!!!!!!!!!!Got the Page!!!!!!!!");
		driver.findElement(By.name("username")).sendKeys(user);
		driver.findElement(By.name("password")).sendKeys(pass);
		driver.findElement(By.id("signin")).submit();
		
		try
		{
			Reporter.log(String.format("[%s Switch:] In the Switch block", CommonFunctions.getTimeStamp()), true);
			switch(PluginAction)
			{
			case "Add": Reporter.log(String.format("[%s ADD:] In adding Plugin block", CommonFunctions.getTimeStamp()), true);
				        CommonFunctions.NavigateClientSession(driver, ClientSesionXpath ,PluginActionServer);
				        CommonFunctions.EditScreen(driver,PluginActionServer)  ;
				        CommonFunctions.SearchForPlugin(driver,PluginName,PluginActionServer);
				        CommonFunctions.AttachPlugin(driver,PluginName,PluginActionServer);
				        CommonFunctions.UpdatePlugin(driver, PluginName ,PluginActionServer,PluginParamterXpath,PluginParamterValue);
			            CommonFunctions.SaveChanges(driver,PluginActionServer,PluginParamterValue);
			            CommonFunctions.ReloadPlugin(driver,PluginActionServer);
			            CommonFunctions.SearchForPlugin(driver,PluginName,PluginActionServer);
			            break;
			
			case "Update": Reporter.log(String.format("[%s UPDATE:] In updating Plugin block", CommonFunctions.getTimeStamp()), true);
				           CommonFunctions.NavigateClientSession(driver, ClientSesionXpath ,PluginActionServer);
				           CommonFunctions.EditScreen(driver,PluginActionServer);
			               CommonFunctions.SelectPluginTab(driver,PluginTabXpath);
				           CommonFunctions.UpdatePlugin(driver, PluginName ,PluginActionServer,PluginParamterXpath,PluginParamterValue);
                           CommonFunctions.SaveChanges(driver,PluginActionServer,PluginParamterValue);
                           CommonFunctions.ReloadPlugin(driver,PluginActionServer);
                           break;
                            
                           
			case "Remove": Reporter.log(String.format("[%s REMOVE:] In removing Plugin block", CommonFunctions.getTimeStamp()), true);
				           CommonFunctions.NavigateClientSession(driver, ClientSesionXpath ,PluginActionServer);
				           CommonFunctions.EditScreen(driver,PluginActionServer)  ;
		                   CommonFunctions.SelectPluginTab(driver,PluginTabXpath);
		                   CommonFunctions.SearchForPlugin(driver,PluginName,PluginActionServer);
		                   CommonFunctions.RemovePlugin(driver, PluginName,PluginActionServer,PluginParamterValue);
				           CommonFunctions.SaveChanges(driver,PluginActionServer,PluginParamterValue);
				           CommonFunctions.ReloadPlugin(driver,PluginActionServer);
							break;     
				
			            
			}
			Reporter.log(String.format("[%s Switch:] Out of Switch block", CommonFunctions.getTimeStamp()), true);
			
			
			
		
		}	
		catch(final Exception e)
		{
			    //Reporter.log(String.format("[%s Exception] Case could not be checked properly due to an exception thrown by Browser ",CommonFunctions.getTimeStamp()),true);
				Assert.fail("Exception details are  " + e.getMessage());
				driver.quit();
				
		}
}

}