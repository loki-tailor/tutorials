package com.mizuhosc.selenium;

public class DelayBetweenMessages
{
	private final int _initialDelay;
	private final int _initialDelayMessageCount;
	private final int _normalDelay;
	
	private int _messagesCount;

	public DelayBetweenMessages()
	{
		_messagesCount = 0;
		_initialDelay = Integer.parseInt(Configuration.SINGLETON.getProperty("messages.delay.initial"));
		_initialDelayMessageCount = Integer.parseInt(Configuration.SINGLETON.getProperty(
			"messages.delay.initialCount"));
		_normalDelay = Integer.parseInt(Configuration.SINGLETON.getProperty(
			"messages.delay.normal"));
	}
	
	public int get()
	{
		_messagesCount++;
		if(_messagesCount < _initialDelayMessageCount)
		{
			return _initialDelay;
		}
		return _normalDelay;
	}
}
