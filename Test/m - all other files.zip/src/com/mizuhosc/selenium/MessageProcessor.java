package com.mizuhosc.selenium;

import com.mizuhosc.selenium.log.*;
import com.mizuhosc.selenium.message.*;
import com.mizuhosc.selenium.replay.*;
import com.mizuhosc.selenium.verification.*;
import java.util.concurrent.*;

/**
 * The core part of QBot. Processes test messages feed in(note this doesn't cover the messages received from Quattro
 * OrderEngine under test).
 */
public class MessageProcessor implements Runnable
{
	private final ExecutorService _executor = Executors.newSingleThreadExecutor(r -> new Thread(r, "MessageProcessor"));
	private final LinkedBlockingQueue<Message> _messages = new LinkedBlockingQueue<>();
	
	private final FIXReplayProcessor _fixReplayProcessor;
	private final FidessaReplayProcessor _fidessaReplayProcessor;
	private final CommandReplayProcessor _commandProcessor;
	private final Orders _orders;
	private final IOIs _iois;
	private final DelayBetweenMessages _delay;
	
	public MessageProcessor(
		final FIXReplayProcessor fixReplayProcessor,
		final FidessaReplayProcessor fidessaReplayProcessor,
		final CommandReplayProcessor commandProcessor,
		final Orders expectedOrderMessages,
		final IOIs iois)
	{
		_fixReplayProcessor = fixReplayProcessor;
		_fidessaReplayProcessor = fidessaReplayProcessor;
		_commandProcessor = commandProcessor;
		_orders = expectedOrderMessages;
		_iois = iois;
		_delay = new DelayBetweenMessages();
	}
	
	public void start()
	{
		_executor.submit(this);
	}
	
	public void onMessage(final Message msg)
	{
		_messages.add(msg);
	}
	
	public boolean isQueueEmpty()
	{
		return _messages.isEmpty();
	}
	
	@Override
	public void run()
	{
		try
		{
			while(true)
			{
				final Message msg = _messages.take();
				Log.info("Replaying message: %s", msg.getRaw());
				Log.info("Queue size: %s", _messages.size());
				
				// Catch exception when playing back one message. Avoid one message affecting the whole playback.
				try
				{
					if(Direction.OUT == msg.getDirection())
					{
						switch(msg.getType())
						{
							case FIX:
								_fixReplayProcessor.processMessage(msg);
								break;
							case FIDESSA:
								_fidessaReplayProcessor.processMessage(msg);
								break;
							case COMMAND:
							case ADD_EXECUTION:
							case CORRECT_EXECUTION:
							case BUST_EXECUTION:
								_commandProcessor.processCommandMessage(msg);
								break;
						}
					}
					if(Direction.IN == msg.getDirection())
					{
						if(MessageType.FIX == msg.getType() && msg.getRaw().get(0).contains("35=6"))
						{
							_iois.addExpected(msg);
						}
						else
						{
							_orders.addExpectedOrderMessages(msg);
						}
					}
				}
				catch(final Exception e)
				{
					Log.error(e, "Failed to playback message: %s", msg.getRaw());
				}
				Thread.sleep(_delay.get());
			}
		}
		catch(final InterruptedException e)
		{
			Thread.currentThread().interrupt();
		}
		catch(final Throwable t)
		{
			Log.error(t, "Error when processing message: ", t.getMessage());
		}
	}
	
}
