package com.mizuhosc.selenium.cache;

import com.mizuhosc.selenium.*;
import java.util.*;
import java.util.concurrent.*;
import javax.annotation.*;

public class ClOrdIDToATP
{
	private final ConcurrentHashMap<String, OrderMarketClOrdIDs> _orders = new ConcurrentHashMap<>();
	private final ConcurrentHashMap<String, String> _expectedClOrdIdToOrderId = new ConcurrentHashMap<>();
	
	private final Set<String> _clOrdIdsWithoutActualClOrdID;
	private final int _maxRetryToGetActualClOrdId;
	
	public ClOrdIDToATP()
	{
		final String retryConfig = Configuration.SINGLETON.getProperty("atp.actualClOrdID.rety.max.times");
		_maxRetryToGetActualClOrdId = retryConfig != null ? Integer.parseInt(retryConfig) : 100;
		_clOrdIdsWithoutActualClOrdID = new HashSet<>();
	}
	
	private OrderMarketClOrdIDs _get(final String orderId)
	{
		return _orders.computeIfAbsent(orderId, $ -> new OrderMarketClOrdIDs($));
		
	}
	
	public void addActualClOrdID(final String clOrdID, final String orderId)
	{
		final OrderMarketClOrdIDs ids = _get(orderId);
		ids.addActual(clOrdID);
	}
	
	public void addExpectedClOrdID(final String clOrdID, final String orderId)
	{
		final OrderMarketClOrdIDs ids = _get(orderId);
		ids.addExpected(clOrdID);
		_expectedClOrdIdToOrderId.put(clOrdID, orderId);
	}
	
	public Optional<String> getOrderIdFromExpectedClOrdID(final @Nullable String expectedClOrdID)
	{
		return Optional.ofNullable(expectedClOrdID).map(_expectedClOrdIdToOrderId::get);
	}
	
	public Optional<String> getActualClOrdID(final @Nullable String expectedClOrdID)
	{
		if(_clOrdIdsWithoutActualClOrdID.contains(expectedClOrdID))
		{
			return Optional.empty();
		}
		try
		{
			int retryCount = 0;
			do
			{
				final Optional<String> value = Optional
					.ofNullable(expectedClOrdID)
					.map($ -> _expectedClOrdIdToOrderId.get($))
					.filter(Objects::nonNull)
					.map($ -> _get($))
					.flatMap($ -> $.getActualFromExpected(expectedClOrdID));
				if(value.isPresent())
				{
					return value;
				}
				Thread.sleep(10);
				retryCount++;
			}
			while(retryCount <= _maxRetryToGetActualClOrdId);
		}
		catch(final InterruptedException e)
		{
			Thread.currentThread().interrupt();
		}
		_clOrdIdsWithoutActualClOrdID.add(expectedClOrdID);
		return Optional.empty();
	}
}
