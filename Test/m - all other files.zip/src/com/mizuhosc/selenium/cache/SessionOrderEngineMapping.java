package com.mizuhosc.selenium.cache;

import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.log.*;
import java.sql.*;
import java.util.*;

public class SessionOrderEngineMapping
{
	private final Map<String, String> _sessionNameToOrderEngineName;
	
	public SessionOrderEngineMapping()
	{
		_sessionNameToOrderEngineName = new HashMap<>();
		_loadSessionEngines();
	}
	
	public Optional<String> getOrderEngine(final String session)
	{
		return Optional.ofNullable(_sessionNameToOrderEngineName.get(session));
	}
	
	private void _loadSessionEngines()
	{
		try(Connection db = Configuration.SINGLETON.createConnection("QUATTRO_DB");)
		{
			final PreparedStatement stmt =
				db.prepareStatement("select name, orderEngine from Session " + " where deleted = 0 and enabled =1");
			final ResultSet rs = stmt.executeQuery();
			while(rs.next())
			{
				_sessionNameToOrderEngineName.put(rs.getString("name"), rs.getString("orderEngine"));
			}
			rs.close();
		}
		catch(final SQLException e)
		{
			Log.error(e, e.getMessage());
		}
	}
}
