package com.mizuhosc.selenium.cache;

import java.util.*;
import java.util.concurrent.*;
import javax.annotation.*;

public class OrderMarketClOrdIDs
{
	private final String _orderId;
	private final List<String> _actual = new CopyOnWriteArrayList<>();
	private final List<String> _expected = new CopyOnWriteArrayList<>();
	
	public OrderMarketClOrdIDs(final String orderId)
	{
		_orderId = orderId;
	}
	
	public void addActual(final String clOrdID)
	{
		if(!_actual.contains(clOrdID))
		{
			_actual.add(clOrdID);
		}
	}
	
	public void addExpected(final String clOrdID)
	{
		if(!_expected.contains(clOrdID))
		{
			_expected.add(clOrdID);
		}
	}
	
	public String getOrderId()
	{
		return _orderId;
	}
	
	public Optional<String> getActualFromExpected(final @Nullable String clOrdID)
	{
		return Optional
			.ofNullable(clOrdID)
			.map(_expected::indexOf)
			.filter(index -> index >= 0)
			.filter(index -> index < _actual.size())
			.map(_actual::get);
	}
}
