package com.mizuhosc.selenium.cache;

import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.replay.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * A cache of QuattroOrderId.
 */
public class QuattroOrderIdCache
{
	// A map from "SessionName:ClOrdID" to QuattroOrderId
	// The value QuattroOrderId is the value of DETAILS.ORIGINATOR_ORDER_ID in OrderRequest from OrderEngine
	// Client doens't repeat ClOrdID on the same day. Queuing clients doens't repeat ClOrdID in GOR.
	private final ConcurrentHashMap<String, String> _clientRefIdNewQuattroOrderId;
	
	// The order engine name here is with env prefix
	private final ConcurrentHashMap<String, String> _clientRefIdToOrderEngineName;
	
	// Used for Keyhole order, as in amend request, keyhole doesn't send ORIGINATOR_ORDER_ID
	private final ConcurrentHashMap<String, String> _omsOrderIdToNewQuattroOrderId;
	
	// Contains the orders that we cannot resolve order engine name
	private final Set<String> _ordersWithoutFidessaMessages;
	private final int _maxRetryToGetOrderEngineName;
	private final SessionOrderEngineMapping _sessionOrderEngineMapping;
	
	public QuattroOrderIdCache(final SessionOrderEngineMapping sessionOrderEngineMapping)
	{
		_clientRefIdNewQuattroOrderId = new ConcurrentHashMap<>();
		_clientRefIdToOrderEngineName = new ConcurrentHashMap<>();
		_omsOrderIdToNewQuattroOrderId = new ConcurrentHashMap<>();
		_sessionOrderEngineMapping = sessionOrderEngineMapping;
		
		// Only accessed by message replay thread
		_ordersWithoutFidessaMessages = new HashSet<>();
		final String retryConfig = Configuration.SINGLETON.getProperty("fidessa.orderenginename.rety.max.times");
		_maxRetryToGetOrderEngineName = retryConfig != null ? Integer.parseInt(retryConfig) : 100;
	}
	
	public void mapNewQuattroOrderId(final String clientRefId, final String quattroOrderId)
	{
		_clientRefIdNewQuattroOrderId.put(clientRefId, quattroOrderId);
	}
	
	public Optional<String> getNewQuattroOrderId(final String clientRefId)
	{
		return Optional.ofNullable(_clientRefIdNewQuattroOrderId.get(clientRefId));
	}
	
	public void mapClientRefIdToOrderEngineName(final String clientRefId, final String orderEngineName)
	{
		_clientRefIdToOrderEngineName.put(clientRefId, orderEngineName);
	}
	
	public Optional<String> getOrderEngineName(final String clientRefId)
	{
		if(_ordersWithoutFidessaMessages.contains(clientRefId))
		{
			return Optional.empty();
		}
		try
		{
			int retryCount = 0;
			do
			{
				final String name = _clientRefIdToOrderEngineName.get(clientRefId);
				if(name != null)
				{
					return Optional.of(name);
				}
				Thread.sleep(10);
				retryCount++;
			}
			while(retryCount <= _maxRetryToGetOrderEngineName);
			
		}
		catch(final InterruptedException e)
		{
			Thread.currentThread().interrupt();
		}
		
		// Add this to _ordersWithoutFidessaMessages so that next time we don't need to wait a long time to get same
		// answer.
		_ordersWithoutFidessaMessages.add(clientRefId);
		return Optional.empty();
	}
	
	public Optional<String> getOrderEngineNameFromOmsOrderId(final String omsOrderId)
	{
		
		final String orderId = _omsOrderIdToNewQuattroOrderId.get(omsOrderId);
		if(orderId != null)
		{
			final String normalized = new QuattroOrderID(orderId).normalize();
			final String clientRefId = extractClientRefIdFromQuattorOrderId(normalized);
			final String sessionName = extractSessionNameFromClientRefId(clientRefId);
			return _sessionOrderEngineMapping.getOrderEngine(sessionName);
		}
		return Optional.empty();
		
	}
	
	public Optional<String> getOrderEngineNameWithoutEnvPrefix(final String clientRefId)
	{
		return Optional.ofNullable(_clientRefIdToOrderEngineName.get(clientRefId)).map($ -> $.substring($.indexOf(":") +
			1));
	}
	
	public void mapOmsOrderIdToNewQuattroOrderId(final String omsOrderId, final String quattroOrderId)
	{
		_omsOrderIdToNewQuattroOrderId.put(omsOrderId, quattroOrderId);
	}
	
	public Optional<String> getQuattroOrderIdByOmsOrderId(final String omsOrderId)
	{
		return Optional.ofNullable(_omsOrderIdToNewQuattroOrderId.get(omsOrderId));
	}
	
	public static String extractClientRefIdFromQuattorOrderId(final String quattroOrderId)
	{
		// For the case of shorten order id, session number part may be removed.
		final int firstColonIndex = quattroOrderId.indexOf(":");
		final int lastColonIndex = quattroOrderId.lastIndexOf(":");
		
		return firstColonIndex == lastColonIndex
			? quattroOrderId
			: quattroOrderId.substring(firstColonIndex + 1);
	}
	
	public static String extractSessionNameFromClientRefId(final String clientRefId)
	{
		return clientRefId.substring(0, clientRefId.indexOf(":"));
	}
}
