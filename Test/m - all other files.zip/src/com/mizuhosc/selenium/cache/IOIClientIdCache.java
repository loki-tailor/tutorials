package com.mizuhosc.selenium.cache;

import com.mizuhosc.selenium.log.*;
import java.io.*;
import java.util.*;

public class IOIClientIdCache
{
	private final Map<String, String> _gorClientIdToQuattroClientId;
	
	public IOIClientIdCache()
	{
		_gorClientIdToQuattroClientId = new HashMap<>();
	}
	
	public void addMapping(final String gorClientId, final String quattroClientId)
	{
		_gorClientIdToQuattroClientId.put(gorClientId, quattroClientId);
	}
	
	public Optional<String> getQuattroClientId(final String gorClientId)
	{
		return Optional.ofNullable(_gorClientIdToQuattroClientId.get(gorClientId));
	}
	
	public void loadClientIdMapping(final String fileName) throws FileNotFoundException, IOException
	{
		if(fileName == null) return;
		try(final BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));)
		{
			String line = null;
			do
			{
				line = reader.readLine();
				if(line != null)
				{
					if(line.contains("GORClientId"))
					{
						continue;
					}
					if(line.replaceAll(",", "").trim().isEmpty())
					{
						continue;
					}
					final String[] ids = line.split(",");
					if(ids.length < 2)
					{
						Log.error("No mapping for: %s", line);
						continue;
					}
					if(ids[0].trim().isEmpty() || ids[1].trim().isEmpty())
					{
						continue;
					}
					_gorClientIdToQuattroClientId.put(ids[0], ids[1]);
				}
			}
			while(line != null);
		}
		Log.info("Client mappings: %s", _gorClientIdToQuattroClientId);
		
	}
}
