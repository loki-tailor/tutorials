package com.mizuhosc.selenium.tests;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.testng.annotations.*;

public class CsvExtractor
{
	WebDriver driver = null;
	
	@Test
	public void prepareCsvExtraction()
	{
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		try
		{
			
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
			
			driver.get("file:///D:/emailable-report.html");
			System.out.println("File found");
			// WebElement e = driver.findElement(By.xpath(""));
			
		}
		catch(Exception e)
		{
			
		}
	}
}
