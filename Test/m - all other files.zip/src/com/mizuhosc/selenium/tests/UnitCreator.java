package com.mizuhosc.selenium.tests;

import java.awt.*;
import java.awt.datatransfer.*;
import java.io.*;
import java.util.NoSuchElementException;
import java.util.concurrent.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;

public class UnitCreator
{
	WebDriver driver = null;
	int orderEngine = 10;
	
	@SuppressWarnings("unused")
	@Test
	public void runItTest() throws AWTException
	{
		String user = "selenium";
		String pass = "SSFSDFW";
		String monEnv = "tkqtrapq18";
		String browser = "Chrome";
		boolean status;
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		// Selects appropriate browser as declared by user in global declaration
		if(browser.equals("Mozilla"))
		{
			driver = new FirefoxDriver();
		}
		else if(browser.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
		}
		else if(browser.equals("IE"))
		{
			File file = new File("drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
		}
		driver.get("http://" + monEnv + ".mizuho-sc.com:9010/quattro/login");
		driver.findElement(By.name("username")).sendKeys(user);
		driver.findElement(By.name("password")).sendKeys(pass);
		driver.findElement(By.name("username")).submit();
		// Change if new case captured
		// Wait for the order
		WebElement waitForStatus =
			new WebDriverWait(driver, 30)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'14:14:18')]")));// 14:14:18
		
		System.out.println("Step 1 : Synthetic Spread Order is Active in Order Monitoring GUI");
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='menu']/li[1]")).click();// Redirects to engine manager screen
		try
		{
			Thread.sleep(3000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		// Alternative way to find links
		// WebElement webElement = driver.findElement(By.xpath("//*[@id='FO-engines']/tbody/tr[11]/td[1]/a"));
		// driver.findElement(By.linkText("RAD-2"));
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		try
		{
			// Right click on the session : Need to change this if env / session change -
			
			Actions action = new Actions(driver);
			
			// Keep adding the order engine here
			switch(orderEngine)
			{
				case 10:
					action.contextClick(driver.findElement(By.linkText("RAD-2"))).build().perform();
					// action
					// .contextClick(driver.findElement(By.xpath("//*[@id='FO-engines']/tbody/tr[11]/td[1]/a")))
					// .build()
					// .perform();
					break;
				
				case 9:
					action.contextClick(driver.findElement(By.linkText("RAD-1"))).build().perform();
					break;
				
				default:
					System.out.println("Invalid parameter : Please check the details after Step 1");
					System.exit(1);
					break;
			}
			
			try
			{
				Thread.sleep(2000);
			}
			
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			// Select appropraite option from right-click options
			WebElement recoveryUpload =
				driver.findElement(By.xpath("/html/body/q-right-click-menu[4]/q-button[5]/span[2]"));
			
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			action.moveToElement(recoveryUpload).click().perform();
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			
			System.out
				.println("Step 2 : Right Click on RAD-2 session and initiated recovery " + recoveryUpload.getText());
			
			WebElement uploadTextArea = driver.findElement(By.xpath("//*[@id='recovery-messages']"));
			
			Actions action2 = new Actions(driver);
			action2.moveToElement(uploadTextArea);
			action2.click().build().perform();
			Robot rb;
			// make sure you put the updated logs by copy pasting in exact format above : Add for every new captured
			// case
			rb = new Robot();
			
			switch(orderEngine)
			{
				case 10:
					
					StringSelection textToPaste =
						new StringSelection(
							"OrderID	ClOrdID	ExecID	ExecType	LastShares	LastPx	LastMkt	TransactTime	Side	Session	QuattroOrderId	ExecRefID	ExecutionVersion	FilledInDarkPool	LastCapacity"
								+ "\n"
								+ "201707280000014	LM:ATRGR2:1501218849846-SS	BTRD20170728000001-1	F	10	10	XOSE	20170728-14:30:00.000	S	BLAST_RAD-2					"
								+ "\n"
								+ "201707280000014	LM:ATRGR2:1501218849846-SS	BTRD20170728000002-1	F	10	20	XOSE	20170728-14:30:00.000	B	BLAST_RAD-2					"
								+ "\n");
					
					Toolkit.getDefaultToolkit().getSystemClipboard().setContents(textToPaste, null);
					break;
				
				case 9:
					StringSelection textToPaste1 =
						new StringSelection(
							"ExecID	ExecType	LastShares	LastPx	LastMkt	TransactTime	Side	Session	QuattroOrderId	ExecRefID	ExecutionVersion	FilledInDarkPool	LastCapacity"
								+ "\n"
								+ "201707280000014	LM:ATRGR2:1501218849846-SS	BTRD20170728000001-1	F	10	10	XOSE	20170728-14:30:00.000	S	BLAST_RAD-2					"
								+ "\n"
								+ "201707280000014	LM:ATRGR2:1501218849846-SS	BTRD20170728000002-1	F	10	20	XOSE	20170728-14:30:00.000	B	BLAST_RAD-2					"
								+ "\n");
					
					Toolkit.getDefaultToolkit().getSystemClipboard().setContents(textToPaste1, null);
					break;
				
				default:
					System.out.println("Something went wrong : Please check step 2");
			}
			
			rb.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
			rb.keyPress(java.awt.event.KeyEvent.VK_V);
			rb.keyRelease(java.awt.event.KeyEvent.VK_V);
			rb.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
			
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			
			// Upload button is clicked
			WebElement uploadButton =
				driver.findElement(By.xpath("//*[@id='upload-recovery-messages-form']/q-button[2]/span[2]"));
			
			System.out.println(
				"Step 3 : Uploaded Sucessfully : passing the control to Monitoring GUI " + uploadButton.getText());
			
			Actions action3 = new Actions(driver);
			// Comment below line to check cancel button
			action3.moveToElement(uploadButton).click().perform();
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			// Comment below line to check cancel button
			driver.switchTo().alert().accept();
			
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			driver.findElement(By.xpath("//*[@id='menu']/li[2]")).click();// Redirects to monitoring screen
			// driver.findElement(By.xpath("//*[@id='menu']/li[1]")).click();
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e1)
			{
				e1.printStackTrace();
			}
			// Checking the State of recovery : Change with new case
			String recoveryToolStatus =
				driver.findElement(By.xpath(".//*[@id='q-render-table-order-list']//tr[1]//td[6]")).getText();
			System.out.println("----> Value fetched : " + recoveryToolStatus);
			boolean recStatus;
			if(recoveryToolStatus != null && "PARTIALLY FILLED".equals(recoveryToolStatus))
			{
				Reporter.log("Recovery tool case " + ":" + " PASSED", true);
				
				try
				{
					Thread.sleep(5000);
				}
				catch(InterruptedException e2)
				{
					e2.printStackTrace();
				}
				System.out.println("Step 4 : Recovery tool case " + ":" + " PASSED " + ": Value passed is True");
				recStatus = true;
			}
			else
			{
				Reporter.log("Recovery tool case " + ":" + " FAILED", true);
				System.out.println("Step 4 : Recovery tool case " + ":" + " FAILED " + ": Value passed is False");
				recStatus = false;
				Assert.fail("Recovery tool failed to Partial fill : Expected Partial fill");
			}
			
			System.out.println("File Download check in Progress");
			// Change if session and env changes
			// Redirects to engine manager screen
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//*[@id='menu']/li[1]")).click();
			// Click on the desired session
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			switch(orderEngine)
			{
				// action.contextClick(driver.findElement(By.linkText("RAD-2")))
				case 10:
					driver.findElement(By.linkText("RAD-2")).click();
					break;
				
				case 9:
					driver.findElement(By.xpath("//*[@id='BBG-2']/td[1]")).click();
					break;
				
				default:
					System.out.println("Invalid parameter : Please check the details after Step 6");
					System.exit(1);
					break;
				
			}
			
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
			
			driver.findElement(By.id("engine-button")).click();
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e2)
			{
				e2.printStackTrace();
			}
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.xpath("/html/body/div[3]/ul/li[4]")).click();
			// Click on Upload template to download
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[3]/a")).click();
			
			try
			{
				Thread.sleep(4000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			
			String downloadPath = "C:\\Users\\gauravsa\\Downloads";
			// Make sure you delete this file if you have downloaded
			String fileName = "quattro-upload.xls";
			boolean flag = false;
			File dir = new File(downloadPath);
			File[] dir_contents = dir.listFiles();
			
			try
			{
				Thread.sleep(4000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			
			for(File dir_content : dir_contents)
			{
				
				if(dir_content.getName().equals(fileName))
				{
					status = true;
					System.out.println(
						"   -------> File downloaded Successfully at C:\\Users\\gauravsa\\Downloads --> Check = "
							+ status + " ");
					
				}
				else
				{
					status = false;
					System.out.println("   -------> File Download check = " + status + " Checking other files ");
					
				}
				
			}
			
			if(status = true)
			{
				Reporter.log(
					"-------> File downloaded Successfully at C:\\Users\\gauravsa\\Downloads --> Check = " + status);
			}
			else
			{
				Reporter.log("-------> File Download check failed " + status);
			}
			
			try
			{
				Thread.sleep(6000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			try
			{
				File file = new File("C:\\Users\\gauravsa\\Downloads\\quattro-upload.xls");
				
				if(file.delete())
				{
					System.out.println(file.getName() + " is deleted!!!");
				}
				else
				{
					System.out.println("No file to delete / Operation failed");
					Assert.fail("No file to delete / Operation failed");
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("Step 2 : Element is not attached to the page document " + e.getStackTrace());
			Assert.fail("Recovery tool case failed due to StaleElementReferenceException");
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Step 2 : Element was not found in DOM " + e.getStackTrace());
			Assert.fail("Recovery Tool Case failed due to NoSuchElementException");
		}
		catch(Exception e)
		{
			System.out.println("Step 2 : Element was not clickable " + e.getStackTrace());
			Assert.fail("Recovery Tool Case failed due to unknown exception");
		}
		
	}
	
}
