package com.mizuhosc.selenium.util.sql;

import java.io.*;
import java.nio.charset.*;
import java.sql.*;
import java.util.*;
import javax.annotation.concurrent.*;

/**
 * Utility class to get a JDBC connection to the specified database in the specified application.<br>
 * This class is intended to be used in evolutions only where we create scripts to interfere with databases defined in
 * application.conf.<br>
 * This class reads env from "~/env.conf" to know where environment's database should be used.
 */
public final @NotThreadSafe class QuattroDatabaseConnection
{
	private static final Charset _LATIN_1 = Charset.forName("ISO-8859-1");
	
	private QuattroDatabaseConnection()
	{
		// Don't instantiate.
	}
	
	/**
	 * @param application name of the application whose application.conf we should read to get database connection
	 *        details. This parameter name is the name of the folder under folder "~/quattro/".
	 * @return a JDBC connection to Quattro database(the default database without database name in application.conf).
	 * @throws FailedToCreateConnectionException
	 *         if failed to read from configuration file or close it, or
	 *         if application configuration file is not found, or
	 *         if a database access error occurs, or
	 *         if the JDBC driver class can't be found on class path.
	 */
	@SuppressWarnings("foo")
	public static Connection getQuattroDatabaseConnection(final @SuppressWarnings("foo") String application)
		throws FailedToCreateConnectionException
	{
		try
		{
			final Optional<String> env = _readEnvironmentFromConfigFile();
			if(env.isPresent())
			{
				return _createConnection(application, env.get(), null);
			}
		}
		catch(ClassNotFoundException | IOException | SQLException e)
		{
			throw new FailedToCreateConnectionException(e);
		}
		
		throw new FailedToCreateConnectionException("env not set in env.conf");
	}
	
	/**
	 * @param application name of the application whose application.conf we should read to get database connection
	 *        details. This parameter name is the name of the folder under folder "~/quattro/".
	 * @param databaseName the database name in application.conf. This is the string after "db." before ".url".
	 *        Example: for FDA in counterparty, database name is "tkfda".
	 * @return a JDBC connection to the specified non Quattro database.
	 * @throws FailedToCreateConnectionException
	 *         if failed to read from configuration file or close it, or
	 *         if application configuration file is not found, or
	 *         if a database access error occurs. or
	 *         if the JDBC driver class can't be found on class path.
	 */
	@SuppressWarnings("foo")
	public static Optional<Connection> getNonQuattroDatabaseConnection(
		final @SuppressWarnings("foo") String application,
		final @SuppressWarnings("foo") String databaseName)
		throws FailedToCreateConnectionException
	{
		try
		{
			final Optional<String> env = _readEnvironmentFromConfigFile();
			if(env.isPresent())
			{
				return Optional.of(_createConnection(application, env.get(), databaseName));
			}
		}
		catch(ClassNotFoundException | IOException | SQLException e)
		{
			throw new FailedToCreateConnectionException(e);
		}
		
		throw new FailedToCreateConnectionException("env not set in env.conf");
	}
	
	// Returns the environment of running system. Valid values are dev, qa, qa2, uat, prod ....
	private static Optional<String> _readEnvironmentFromConfigFile() throws FileNotFoundException, IOException
	{
		final File envConfFile = new File(System.getProperty("user.home") + File.separator + "env.conf");
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(
			new FileInputStream(envConfFile), _LATIN_1)))
		{
			final Properties envConf = new Properties();
			envConf.load(reader);
			return Optional.ofNullable((String)envConf.get("env"));
		}
	}
	
	/**
	 * @param databaseName the database name in application.conf. Null is treated as quattro's own database.
	 * @return a JDBC connection to specified database.
	 * @throws FileNotFoundException if application configuration file is not found.
	 * @throws IOException failed to read from configuration file or close it.
	 * @throws SQLException if a database access error occurs.
	 * @throws ClassNotFoundException if the JDBC driver class can't be found on class path.
	 */
	private static Connection _createConnection(final String application, final String env, final String databaseName)
		throws FileNotFoundException, IOException, SQLException, ClassNotFoundException
	{
		final String osName = System.getProperty("os.name");
		File configurationFile;
		
		// On windows, get the working folder of current project and then go to the application folder based on current
		// project
		if(osName.contains("Windows"))
		{
			configurationFile =
				new File(System.getProperty("user.dir")
					+ File.separator
					+ ".."
					+ File.separator
					+ ".."
					+ File.separator
					+ ".."
					+ File.separator
					+ application
					+ File.separator
					+ "server"
					+ File.separator
					+ "play"
					+ File.separator
					+ "conf"
					+ File.separator
					+ "application.conf");
		}
		// On linux
		else
		{
			final String configurationFilePath = System.getProperty("user.home")
				+ File.separator
				+ "quattro"
				+ File.separator
				+ application
				+ File.separator
				+ "server"
				+ File.separator
				+ "play"
				+ File.separator
				+ "conf"
				+ File.separator
				+ "application.conf";
			configurationFile = new File(configurationFilePath);
		}
		
		final Properties p = _readDatabaseConfigurations(configurationFile, env, databaseName);
		Class.forName(p.getProperty("driver"));
		return DriverManager.getConnection(p.getProperty("url"), p);
	}
	
	/**
	 * Reads the database configuration for specified database.
	 * 
	 * @return a Properties containing "url", "driver", "user" and "password" populated with values from
	 *         application.conf.
	 * @throws IOException if failed to read from application configuration file or failed to close the reader.
	 * @throws FileNotFoundException if application config file doesn't exist.
	 */
	private static Properties _readDatabaseConfigurations(
		final File applicationConfigurationFile,
		final String env,
		final String databaseName) throws FileNotFoundException, IOException
	{
		final Properties result = new Properties();
		try(BufferedReader reader =
			new BufferedReader(new InputStreamReader(new FileInputStream(applicationConfigurationFile), _LATIN_1)))
		{
			final String dbNameInConfig = databaseName == null ? "" : databaseName + ".";
			String line = null;
			do
			{
				line = reader.readLine();
				if(line != null)
				{
					// Get property for url
					final String urlStart = "%" + env + ".db." + dbNameInConfig + "url=";
					if(line.startsWith(urlStart))
					{
						result.setProperty("url", line.substring(urlStart.length()));
					}
					
					// Get property for driver
					final String driverStart = "%" + env + ".db." + dbNameInConfig + "driver=";
					if(line.startsWith(driverStart))
					{
						result.setProperty("driver", line.substring(driverStart.length()));
					}
					
					// Get property for user
					final String userStart = "%" + env + ".db." + dbNameInConfig + "user=";
					if(line.startsWith(userStart))
					{
						result.setProperty("user", line.substring(userStart.length()));
					}
					
					// Get property for password
					final String passwordStart = "%" + env + ".db." + dbNameInConfig + "pass=";
					if(line.startsWith(passwordStart))
					{
						result.setProperty("password", line.substring(passwordStart.length()));
					}
				}
			}
			while(line != null);
		}
		return result;
	}
}
