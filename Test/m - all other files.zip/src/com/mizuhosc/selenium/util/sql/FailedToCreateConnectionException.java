package com.mizuhosc.selenium.util.sql;

import javax.annotation.concurrent.*;

public final @Immutable class FailedToCreateConnectionException extends Exception
{
	public FailedToCreateConnectionException(final Exception cause)
	{
		super(cause);
	}
	
	public FailedToCreateConnectionException(final String message)
	{
		super(message);
	}
}
