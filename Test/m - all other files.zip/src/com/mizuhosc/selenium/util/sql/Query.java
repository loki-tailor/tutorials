package com.mizuhosc.selenium.util.sql;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import javax.annotation.*;

/**
 * Execute an SQL when provided with the database credentials and output the result to the provided file.
 */
public final class Query
{
	private final String _url;
	private final Properties _properties = new Properties();
	private final String _query;
	
	public Query(final String url, final String user, final String password, final String query)
	{
		_url = url;
		_properties.put("user", user);
		_properties.put("password", password);
		_query = query;
	}
	
	/**
	 * @param args the arguments for the command line. These are expected in the order of the {@code Args} enums, and in
	 *        the correct format.
	 */
	public static void main(final String... args)
	{
		if(args.length < Args.values().length)
		{
			// Let the wrapper script show the usage
			ExitCode.INVALID_PARAMS.exit("Not enough parameters.");
		}
		final String url = Args.DB_URL.getValueFrom(args);
		final String user = Args.DB_USER.getValueFrom(args);
		final String password = Args.DB_PASSWORD.getValueFrom(args);
		final String query = Args.QUERY.getValueFrom(args);
		final File outputFile = new File(Args.OUT_FILE.getValueFrom(args));
		
		try(LineWriter writer = new LineWriter(outputFile))
		{
			new Query(url, user, password, query).execute(writer);
		}
		catch(final FileAlreadyExistsException e)
		{
			ExitCode.FILE_EXISTS.exit("File already exists; won't overwrite: %s", outputFile.getAbsolutePath());
		}
		catch(final IOException e)
		{
			ExitCode.FILE_IO_ERROR.exit("Problem creating output file: %s", e.getMessage());
		}
		catch(final SQLException e)
		{
			ExitCode.DB_ERROR.exit("Problem querying database: %s", e.getMessage());
		}
	}
	
	/**
	 * Supply the result set of execution with the column headers and result rows to the consumer. Columns are separated
	 * by tabs.
	 */
	void execute(final LineWriter writer) throws SQLException, IOException
	{
		try(final Connection conn = DriverManager.getConnection(_url, _properties);
			final PreparedStatement statement = conn.prepareStatement(_query))
		{
			// Abort if there is no result
			if(!statement.execute()) return;
			
			try(final ResultSet resultSet = statement.getResultSet())
			{
				final ResultSetMetaData metaData = resultSet.getMetaData();
				final int columns = metaData.getColumnCount();
				
				// Write the header. Columns are tab-separated.
				final StringBuilder header = new StringBuilder();
				for(int i = 1; i <= columns; i++)
				{
					header.append(metaData.getColumnLabel(i)).append('\t');
				}
				writer.write(header.toString());
				
				// Write the rows. Columns are tab-separated.
				while(resultSet.next())
				{
					final StringBuilder row = new StringBuilder();
					for(int i = 1; i <= columns; i++)
					{
						row.append(resultSet.getObject(i)).append('\t');
					}
					writer.write(row.toString());
				}
			}
		}
	}
}

/**
 * Consumer to a line to a file.
 */
final class LineWriter implements AutoCloseable
{
	// UTF-8 charset
	private static final Charset _UTF_8 = Charset.forName("UTF-8");
	private final BufferedWriter _writer;
	
	LineWriter(final File file) throws IOException
	{
		// Abort if file exists already
		if(!file.createNewFile()) throw new FileAlreadyExistsException(file.getAbsolutePath());
		
		_writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), _UTF_8));
	}
	
	public void write(final String line) throws IOException
	{
		_writer.write(line);
		_writer.newLine();
	}
	
	@Override
	public void close() throws IOException
	{
		_writer.flush();
		_writer.close();
	}
}

enum ExitCode
{
	SUCCESS, // Ordinal 0 means success.
	INVALID_PARAMS,
	FILE_EXISTS,
	DB_ERROR,
	FILE_IO_ERROR;
	
	void exit(final @Nullable String message, final Object... parameters)
	{
		if(message != null) System.err.printf(message, parameters).println();
		System.exit(ordinal());
	}
}

enum Args
{
	DB_URL,
	DB_USER,
	DB_PASSWORD,
	QUERY,
	OUT_FILE;
	
	String getValueFrom(final String[] args)
	{
		return args[ordinal()];
	}
}
