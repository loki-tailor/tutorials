package com.mizuhosc.selenium.util.sql;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import javax.annotation.*;
import com.mizuhosc.selenium.functionlibraries.CommonFunctions;
import com.mizuhosc.quattro.util.value.*;
import com.mizuhosc.selenium.Configuration;
import com.mizuhosc.selenium.diff.*;
import com.mizuhosc.selenium.scripts.util.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.annotation.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.ie.*;
import org.openqa.selenium.support.ui.*;
import org.testng.*;
import org.testng.annotations.*;
import com.mizuhosc.selenium.functionlibraries.*;

//        java -cp $classpath \
// com.mizuhosc.quattro.util.sql.Query \
// "$url" "$user" "$pass" "$query" "$output"


public class RunQuery
{
			
			private static final String driver = 	 Configuration.SINGLETON.getProperty("db.FIDESSA_DB.driver");
	        private static final String url = 	 Configuration.SINGLETON.getProperty("db.FIDESSA_DB.url");
	        private static final String username = Configuration.SINGLETON.getProperty("db.FIDESSA_DB.username");
	        private static final String password = Configuration.SINGLETON.getProperty("db.FIDESSA_DB.password");
	        private static final String query = "select * from STB_MARKET_INSTRUMENT where INSTRUMENT_ID='6758'";
	        private static final String output = Configuration.SINGLETON.getProperty("db.FIDESSA_DB.output");
	        
	        public static void main(String[] args)throws Exception 
	        {
	        	new Query(url, username, password, query).execute(new LineWriter(new File(output)));;
				
			}
	
	
}