package com.mizuhosc.selenium;

import com.mizuhosc.selenium.log.*;
import java.util.concurrent.*;

public class MemoryMonitor
{
	public void start()
	{
		Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(() ->
		{
			Log.info(String.format(
				"Max memory: %s MB, total memory: %s MB, free memory: %s MB",
				format(java.lang.Runtime.getRuntime().maxMemory()),
				format(java.lang.Runtime.getRuntime().totalMemory()),
				format(java.lang.Runtime.getRuntime().freeMemory())));
		}, 30, 30, TimeUnit.SECONDS);
		
	}
	
	String format(final long value)
	{
		return String.format("%,.3f", value / 1024.0 / 1024.0);
	}
}
