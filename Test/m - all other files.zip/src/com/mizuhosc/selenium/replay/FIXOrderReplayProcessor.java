package com.mizuhosc.selenium.replay;

import com.javtech.appia.middleware.*;
import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.connection.fix.*;
import com.mizuhosc.selenium.message.*;
import java.util.*;
import java.util.stream.*;

public class FIXOrderReplayProcessor
{
	private final AppiaInProcess _appia;
	private final ClOrdIDToATP _clOrdIDToATP;
	
	public FIXOrderReplayProcessor(final AppiaInProcess appia, final ClOrdIDToATP clOrdIDToATP)
	{
		_appia = appia;
		_clOrdIDToATP = clOrdIDToATP;
	}
	
	public void replayOrderMessages(String fixMessage, final String msgType) throws Exception
	{
		final int indexOfSenderCompID = fixMessage.indexOf("|49=");
		
		// get SenderCompID
		final String senderCompID =
			fixMessage.substring(
				indexOfSenderCompID + "|49=".length(),
				fixMessage.indexOf("|", indexOfSenderCompID + "|49=".length()));
		
		// All session names in Appia are uppercase(this is appia behavior)
		final String fixConnectionName = senderCompID.toUpperCase();
		if("8".equals(msgType) || "9".equals(msgType))
		{
			fixMessage = replaceClOrdIDs(fixMessage);
		}
		
		_appia.getMiddleware().postRawString(
			UUID.randomUUID().toString(),
			fixConnectionName,
			"FIX",
			MiddlewareConfig.RAW_DATA,
			msgType,
			normalizeFIXLog(fixMessage));
	}
	
	String replaceClOrdIDs(final String fixMessage)
	{
		final Map<String, String> m = FIXMessage.ParseUlBridgeLog(fixMessage);
		final String clOrdID = m.get("11");
		final String actualClOrdID = "|11=" + _clOrdIDToATP.getActualClOrdID(clOrdID).orElse(clOrdID) + "|";
		final String clOrdIDReplaced = fixMessage.replace("|11=" + clOrdID + "|", actualClOrdID);
		final String origClOrdID = m.get("41");
		if(origClOrdID == null) return clOrdIDReplaced;
		final String actualOrigClOrdID = "|41=" + _clOrdIDToATP.getActualClOrdID(origClOrdID).orElse(origClOrdID) + "|";
		return clOrdIDReplaced.replace("|41=" + origClOrdID + "|", actualOrigClOrdID);
	}
	
	private static final String _FIX_DELIMITER = "\u0001";
	
	static String normalizeFIXLog(final String fixLog)
	{
		return FIXMessage
			.ParseUlBridgeLog(fixLog)
			.entrySet()
			.stream()
			.map($ -> $.getKey() + "=" + $.getValue())
			.collect(Collectors.joining(_FIX_DELIMITER));
	}
}
