package com.mizuhosc.selenium.replay;

import com.javtech.appia.middleware.*;
import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.connection.fix.*;
import com.mizuhosc.selenium.message.*;
import java.util.*;
import java.util.stream.*;

// SenderCompIDs:
// GOR: 49=NEPTUNE|56=MHSC_GOR
// Quattro: 49=NEPTUNE|56=MHSC_QUATTRO

public class FIXIOIReplayProcessor
{
	private final AppiaInProcess _appia;
	private final IOIClientIdCache _ioiClientIdCache;
	
	public FIXIOIReplayProcessor(final AppiaInProcess appia, final IOIClientIdCache ioiClientIdCache)
	{
		_appia = appia;
		_ioiClientIdCache = ioiClientIdCache;
	}
	
	public void replayIOIMessages(final String fixMessage, final String msgType) throws Exception
	{
		final int indexOfSenderCompID = fixMessage.indexOf("|49=");
		
		// get SenderCompID
		final String senderCompID =
			fixMessage.substring(
				indexOfSenderCompID + "|49=".length(),
				fixMessage.indexOf("|", indexOfSenderCompID + "|49=".length()));
		
		// All session names in Appia are uppercase(this is appia behavior)
		final String fixConnectionName = senderCompID.toUpperCase();
		
		final String targetCompIDReplaced = normalizeMessageForQuattro(fixMessage);
		_appia.getMiddleware().postRawString(
			UUID.randomUUID().toString(),
			fixConnectionName,
			"FIX",
			MiddlewareConfig.RAW_DATA,
			msgType,
			normalizeFIXLog(targetCompIDReplaced));
		
	}
	
	public String normalizeMessageForQuattro(final String fixMessage)
	{
		final String clientIdsReplaced = _replaceIOIClientIds(fixMessage);
		final String targetCompIDReplaced = clientIdsReplaced.replace("56=MHSC_GOR", "56=MHSC_QUATTRO");
		return targetCompIDReplaced;
	}
	
	private String _replaceIOIClientIds(final String fixMessage)
	{
		final String clientIdsTag = "|8070=";
		final int indexOfClientIds = fixMessage.indexOf(clientIdsTag);
		final int nextTagStartIndex = fixMessage.indexOf("|", indexOfClientIds + clientIdsTag.length() + 1);
		final String clientIds = fixMessage.substring(
			indexOfClientIds + clientIdsTag.length(),
			nextTagStartIndex);
		
		return fixMessage.substring(0, indexOfClientIds) +
			clientIdsTag +
			replaceClientIds(clientIds) +
			fixMessage.substring(nextTagStartIndex);
	}
	
	private String replaceClientIds(final String clientIds)
	{
		return Stream
			.of(clientIds.split(","))
			.map($ -> _ioiClientIdCache.getQuattroClientId($).orElse($))
			.collect(Collectors.joining(","));
	}
	
	private static final String _FIX_DELIMITER = "\u0001";
	
	static String normalizeFIXLog(final String fixLog)
	{
		return FIXMessage
			.ParseUlBridgeLog(fixLog)
			.entrySet()
			.stream()
			.map($ -> $.getKey() + "=" + $.getValue())
			.collect(Collectors.joining(_FIX_DELIMITER));
	}
}
