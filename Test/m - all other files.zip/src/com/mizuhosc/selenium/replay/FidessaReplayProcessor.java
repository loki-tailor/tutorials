package com.mizuhosc.selenium.replay;

import com.fidessa.inf.utl.*;
import com.mizuhosc.selenium.*;
import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.connection.fidessa.*;
import com.mizuhosc.selenium.connection.fidessa.AgencyAndHireiheibunStreamService.*;
import com.mizuhosc.selenium.log.Log;
import com.mizuhosc.selenium.message.*;
import java.text.*;
import java.util.*;

public class FidessaReplayProcessor
{
	private final JmisStreamService _jmis;
	private final AgencyAndHireiheibunStreamService _agencyAndHireiHaibun;
	private final OnewayStreamService _oneway;
	private final NYOWStreamService _nyow;
	private final OmarTransactionService _omarTransactionService;
	private final JmisTransactionService _jmisTransactionService;
	
	private final QuattroOrderIdCache _quattroOrderIdCache;
	private final ReplayMode _replayMode;
	
	private int _microseconds = 0;
	private final SimpleDateFormat _format = new SimpleDateFormat("yyyyMMdd HH:mm:ss.SSS");
	
	public FidessaReplayProcessor(
		final OmarTransactionService omarTransactionService,
		final JmisTransactionService jmisTransactionService,
		final JmisStreamService jmis,
		final AgencyAndHireiheibunStreamService agencyAndHireiHaibun,
		final SwapStreamService swap,
		final OnewayStreamService oneway,
		final NYOWStreamService nyow,
		final QuattroOrderIdCache quattroOrderIdCache,
		final ReplayMode replayMode)
	{
		_omarTransactionService = omarTransactionService;
		_jmisTransactionService = jmisTransactionService;
		_jmis = jmis;
		_agencyAndHireiHaibun = agencyAndHireiHaibun;
		_oneway = oneway;
		_nyow = nyow;
		_quattroOrderIdCache = quattroOrderIdCache;
		_replayMode = replayMode;
	}
	
	static final String ORDER_ORIGINATOR_ID_TAG = "DETAILS.ORDER_ORIGINATOR_ID";
	
	public void processMessage(final Message msg)
	{
		final StructuredSet ss = toStructuredSet(msg);
		
		// Set new value in DATASTREAM_REF
		{
			_microseconds = (_microseconds + 1) % 1000;
			final String tagValue = _format.format(new Date()) + String.format("%03d", _microseconds) + " +0900";
			ss.remove("DATASTREAM_REF");
			ss.add("DATASTREAM_REF", tagValue);
		}
		
		if(isOmarTxnNackMessage(ss))
		{
			_omarTransactionService._sendTxnNack(createOmarNackMessage(ss));
		}
		else if(isJmisTxnNackMessage(ss))
		{
			_jmisTransactionService._sendTxnNack(createJmisNackMessage(ss));
		}
		
		else if(isJMisOrder(ss))
		{
			final String clientRefId =
				QuattroOrderIdCache.extractClientRefIdFromQuattorOrderId(new QuattroOrderID((String)ss.get(
					"DETAILS.CUST_EXT_REF2")).normalize());
			final Optional<String> orderEngineName = _quattroOrderIdCache.getOrderEngineName(clientRefId);
			
			_quattroOrderIdCache
				.getNewQuattroOrderId(clientRefId)
				.ifPresent(newQuattroOrderId ->
				{
					ss.remove("DETAILS.CUST_EXT_REF2");
					ss.add("DETAILS.CUST_EXT_REF2", newQuattroOrderId);
				});
			
			final String omsOrderId = (String)ss.get("DETAILS.JMIS_ORDER_ID");
			_quattroOrderIdCache.mapOmsOrderIdToNewQuattroOrderId(
				omsOrderId,
				new QuattroOrderID((String)ss.get("DETAILS.CUST_EXT_REF2")).normalize());
			
			Log.info("Trying to send JMIS message to order engine %s: %s", orderEngineName, ss);
			if(orderEngineName.isPresent())
			{
				_jmis.send(orderEngineName.get(), ss);
			}
		}
		else if(_replayMode == ReplayMode.ONE_WAY_ORDERS)
		{
			Log.info("Trying to send oneway message to user %s: %s", "GOR", ss);
			_oneway.send("GOR", ss);
		}
		else if(_replayMode == ReplayMode.NYOW_ORDERS)
		{
			Log.info("Trying to send NYOW message to user %s: %s", "GOR", ss);
			_nyow.send("GOR", ss);
		}
		else
		{
			final String clientRefId =
				QuattroOrderIdCache.extractClientRefIdFromQuattorOrderId(new QuattroOrderID((String)ss.get(
					"DETAILS.ORIGINATOR_ORDER_ID")).normalize());
			final Optional<String> orderEngineName = _quattroOrderIdCache.getOrderEngineName(clientRefId);
			
			_quattroOrderIdCache
				.getNewQuattroOrderId(clientRefId)
				.ifPresent(newQuattroOrderId ->
				{
					ss.remove("DETAILS.ORIGINATOR_ORDER_ID");
					ss.add("DETAILS.ORIGINATOR_ORDER_ID", newQuattroOrderId);
				});
			
			// Set DETAILS.ORDER_ORIGINATOR_ID to QTR-OMAR if it is not. QBot is designed for Quattro and Quattro
			// checks DETAILS.ORDER_ORIGINATOR_ID for OMAR messages.
			// Feels like Quattro should not do it(quattro doesn't do it for DMA), but don't want to touch quattro
			// code for qbot
			final String orderOriginatorId = (String)ss.get(ORDER_ORIGINATOR_ID_TAG);
			if(!"QTR-OMAR".equals(orderOriginatorId))
			{
				ss.remove(ORDER_ORIGINATOR_ID_TAG);
				ss.add(ORDER_ORIGINATOR_ID_TAG, "QTR-OMAR");
			}
			
			final String omsOrderId = (String)ss.get("DETAILS.ORDER_ID");
			_quattroOrderIdCache.mapOmsOrderIdToNewQuattroOrderId(
				omsOrderId,
				new QuattroOrderID((String)ss.get("DETAILS.ORIGINATOR_ORDER_ID")).normalize());
				
			if(orderEngineName.isPresent())
			{
				Log.info("Trying to send OMAR message to order engine %s: %s", orderEngineName.get(), ss);
					_agencyAndHireiHaibun.send(orderEngineName.get(), StreamName.DS_QUATTRO_ORDSTATUS, ss);
			}
			
			// For Hireihaibun JMIS order fills
			else
			{
				_quattroOrderIdCache.getOrderEngineNameFromOmsOrderId(clientRefId).ifPresent($ ->
				{
					Log.info("Trying to send Hireihaibun fill message to order engine %s: %s", $, ss);
					_agencyAndHireiHaibun.send(
						$,
						StreamName.DS_QUATTRO_HH_EXECS,
						ss);
				});
			}
		}
	}
	
	boolean isJMisOrder(final StructuredSet ss)
	{
		return ss.get("DETAILS.JMIS_ORDER_ID") != null;
	}
	
	boolean isOnewayOrder(final StructuredSet ss)
	{
		return ss.get("DETAILS.JMIS_ORDER_ID") != null;
	}
	
	// This is based on JPOmarConverters.getRejectionEventType in GOR
	static boolean isOmarTxnNackMessage(final StructuredSet ss)
	{
		final String omarRequestEventType = (String)ss.get("MESSAGE_TYPE");
		final String omarRejectEventType = (String)ss.get("EVENT.EVENT_TYPE");
		final boolean orderRequestNack =
			"TXN_CLIENT_ORDER_ENTRY".equals(omarRequestEventType) && "OrderEntry-rejected".equals(omarRejectEventType);
		final boolean orderEntrySplitRequestNack = "TXN_CLIENT_ORDER_ENTRY_AND_SPLIT".equals(omarRequestEventType) &&
			"OrderEntry-rejected".equals(omarRejectEventType);
		final boolean amendRequestNack = "TXN_CLIENT_ORDER_REPLACE".equals(omarRequestEventType) &&
			"OrderAmend-rejected".equals(omarRejectEventType);
		final boolean strategyAmendNack =
			"TXN_ORDER_ASSIGN".equals(omarRequestEventType) && "OrderAmend-rejected".equals(omarRejectEventType);
		final boolean cancelRequestNack = "TXN_ORDER_COMPLETE".equals(omarRequestEventType) &&
			"OrderCancel-rejected".equals(omarRejectEventType);
		return orderRequestNack ||
			orderEntrySplitRequestNack ||
			amendRequestNack ||
			strategyAmendNack ||
			cancelRequestNack;
		
	}
	
	// This is based on JmisConnector._buildRejectionMessage in GOR.
	static boolean isJmisTxnNackMessage(final StructuredSet ss)
	{
		final String jmisRequestEventType = (String)ss.get("XP_DATA.EVENT.EVENT_TYPE");
		final String jmisRejectEventType = (String)ss.get("EVENT_TYPE");
		final boolean orderRequestNack = "OrderEntry-request".equals(jmisRequestEventType) &&
			"OrderEntry-rejected".equals(jmisRejectEventType);
		final boolean amendRequestNack =
			"OrderAmend-request".equals(jmisRequestEventType) && "OrderAmend-rejected".equals(jmisRejectEventType);
		final boolean cancelRequestNack =
			"OrderCancel-request".equals(jmisRequestEventType) && "OrderCancel-rejected".equals(jmisRejectEventType);
		return orderRequestNack || amendRequestNack || cancelRequestNack;
		
	}
	
	// TXN_NACK message stored in database is not exactly as the one we received.
	// Set fields necessary for OE to process NACK
	static StructuredSet createOmarNackMessage(final StructuredSet ss)
	{
		ss.remove("MESSAGE_TYPE");
		ss.add("MESSAGE_TYPE", "TXN_NACK");
		ss.remove("EVENT.EVENT_TYPE");
		final String reason = (String)ss.get("EVENT.REASON_TEXT");
		ss.add("ERROR[0].ERROR_TEXT", reason);
		ss.remove("EVENT.REASON_TEXT");
		
		// USER_NAME, VALIDATE, IGNORE_WARDINGS, MF_VERSION, SHORT_ACK were from original request message.
		// Leave them as they are not read when procesing nack
		return ss;
	}
	
	static StructuredSet createJmisNackMessage(final StructuredSet ss)
	{
		ss.remove("MESSAGE_TYPE");
		ss.add("MESSAGE_TYPE", "TXN_NACK");
		ss.remove("EVENT_TYPE");
		final String reason = (String)ss.get("DETAILS.REASON_TEXT");
		ss.add("ERROR[0].ERROR_TEXT", reason);
		ss.remove("DETAILS.REASON_TEXT");
		ss.remove("DETAILS.CUST_EXT_REF2");
		return ss;
	}
	
	public static StructuredSet toStructuredSet(final Message msg)
	{
		final List<String> raw = msg.getRaw();
		final StructuredSet ss = new StructuredSet();
		
		for(final String s: raw)
		{
			final int indexOfEquals = s.indexOf("=");
			final String tag = s.substring(0, indexOfEquals).trim();
			final String value = s.substring(indexOfEquals + 1).trim();
			setTagValue(ss, tag, value);
		}
		return ss;
	}
	
	static void setTagValue(final StructuredSet ss, final String tag, final String value)
	{
		
		if(tag.endsWith(".s"))
		{
			final String tagName = tag.substring(0, tag.length() - 2);
			final String tagValue = value.substring(1, value.length() - 1);
			ss.add(tagName, tagValue);
		}
		if(tag.endsWith(".i32"))
		{
			final String tagName = tag.substring(0, tag.length() - ".i32".length());
			final int tagValue = Integer.parseInt(value);
			ss.add(tagName, tagValue);
		}
		
		if(tag.endsWith(".f64"))
		{
			final String tagName = tag.substring(0, tag.length() - ".f64".length());
			final double tagValue = Double.parseDouble(value);
			ss.add(tagName, tagValue);
		}
		if(tag.endsWith(".b"))
		{
			final String tagName = tag.substring(0, tag.length() - ".b".length());
			final Byte tagValue = Byte.valueOf(Integer
				.valueOf(value.substring(0, value.indexOf("(")).trim())
				.byteValue());
			ss.add(tagName, tagValue);
		}
	}
}
