package com.mizuhosc.selenium.replay;

import com.mizuhosc.quattro.util.*;
import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.connection.orderengine.*;
import com.mizuhosc.selenium.log.*;
import com.mizuhosc.selenium.message.*;
import java.text.*;
import java.util.*;

public class CommandReplayProcessor
{
	private final ThreadLocal<SimpleDateFormat> _format = new ThreadLocal<SimpleDateFormat>()
	{
		@Override
		protected SimpleDateFormat initialValue()
		{
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z");
		}
	};
	private final OrderEngineOrderService _orderService;
	private final QuattroOrderIdCache _idCache;
	private final SessionOrderEngineMapping _sessionOrderEngineMapping;
	
	public CommandReplayProcessor(
		final OrderEngineOrderService orderService,
		final QuattroOrderIdCache idCache,
		final SessionOrderEngineMapping sessionOrderEngineMapping)
	{
		_orderService = orderService;
		_idCache = idCache;
		_sessionOrderEngineMapping = sessionOrderEngineMapping;
	}
	
	public void processCommandMessage(final Message msg)
	{
		final String line = msg.getRaw().get(0);
		try
		{
			final MessageMap map = MessageMap.parseString(line);
			String orderEngineName = null;
			if(MessageType.COMMAND == msg.getType())
			{
				orderEngineName = map.getString("InstanceId");
				final String quattroOrderId = map.getString("OrderId");
				final String clientRefId = QuattroOrderIdCache.extractClientRefIdFromQuattorOrderId(quattroOrderId);
				final String sessionName = QuattroOrderIdCache.extractSessionNameFromClientRefId(clientRefId);
				if(orderEngineName == null)
				{
					// To uppercase is required for Lsehub since it's session name in quattro would be in uppercase
					orderEngineName = _idCache.getOrderEngineNameWithoutEnvPrefix(clientRefId.toUpperCase()).orElse(
						_sessionOrderEngineMapping.getOrderEngine(sessionName).orElse(null));
					map.set("InstanceId", orderEngineName);
					map.set("MESSAGE_SEND_TIME", _format.get().format(new Date()));
					map.set("MESSAGE_SENDER", "qbot");
				}
				final String newQuattroOrderId = _idCache.getNewQuattroOrderId(clientRefId).orElse(quattroOrderId);
				map.set("OrderId", newQuattroOrderId);
			}
			else
			{
				orderEngineName = map.getString("INSTANCE_ID");
				final String quattroOrderId = new QuattroOrderID(map.getString("QUATTRO_ORDER_ID")).normalize();
				final String clientRefId = QuattroOrderIdCache.extractClientRefIdFromQuattorOrderId(quattroOrderId);
				final String sessionName = QuattroOrderIdCache.extractSessionNameFromClientRefId(clientRefId);
				if(orderEngineName == null)
				{
					// To uppercase is required for Lsehub since it's session name in quattro would be in uppercase
					orderEngineName = _idCache.getOrderEngineNameWithoutEnvPrefix(clientRefId.toUpperCase()).orElse(
						_sessionOrderEngineMapping.getOrderEngine(sessionName).orElse(null));
					map.set("INSTANCE_ID", orderEngineName);
					map.set("MESSAGE_SEND_TIME", _format.get().format(new Date()));
					map.set("MESSAGE_SENDER", "qbot");
				}
				final String newQuattroOrderId = _idCache.getNewQuattroOrderId(clientRefId).orElse(quattroOrderId);
				map.set("QUATTRO_ORDER_ID", newQuattroOrderId);
				
				// Special thing for EXECUTION_MARKET_PREV_REF_ID. GOR adds "H" to the beginning of tag 17 from ATP.
				// When doing manual execution correct/bust, we need to fix the EXECUTION_MARKET_PREV_REF_ID.
				// Example: ATP sends 17=00012552110EXHK1, OspreyGUI will send
				// EXECUTION_MARKET_PREV_REF_ID=H00012552110EXHK1 to keyhole when busting the fill
				final String executionMarketPrevRefId = map.getString("EXECUTION_MARKET_PREV_REF_ID");
				if(executionMarketPrevRefId != null &&
					executionMarketPrevRefId.startsWith("H") &&
					executionMarketPrevRefId.contains("EXHK"))
				{
					map.set("EXECUTION_MARKET_PREV_REF_ID", executionMarketPrevRefId.substring(1));
				}
			}
			_orderService.sendCommandToOrderEngine(orderEngineName, msg.getType(), map);
		}
		catch(final MessagingException e)
		{
			Log.error(e, "Error when parsing replayed message %s", line);
		}
	}
}
