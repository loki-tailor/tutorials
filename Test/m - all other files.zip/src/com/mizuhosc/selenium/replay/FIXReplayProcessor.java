package com.mizuhosc.selenium.replay;

import com.mizuhosc.selenium.cache.*;
import com.mizuhosc.selenium.connection.fix.*;
import com.mizuhosc.selenium.message.*;
import java.util.*;
import java.util.stream.*;

public class FIXReplayProcessor
{
	private static final String _IOI_MSG_TYPE = "6";
	private final FIXOrderReplayProcessor _orderReplayProcessor;
	private final Set<String> _orderMsgTypes;
	private final FIXIOIReplayProcessor _fixioiReplayProcessor;
	
	public FIXReplayProcessor(
		final AppiaInProcess appia,
		final ClOrdIDToATP clOrdIDToATP,
		final IOIClientIdCache ioiClientIdCache)
	{
		_orderMsgTypes = Stream.of("D", "G", "F", "8", "9", "Q", "E").collect(Collectors.toSet());
		_orderReplayProcessor = new FIXOrderReplayProcessor(appia, clOrdIDToATP);
		_fixioiReplayProcessor = new FIXIOIReplayProcessor(appia, ioiClientIdCache);
	}
	
	public void processMessage(final Message message) throws Exception
	{
		// Each FIX message is only in 1 line
		final String fixMessage = message.getRaw().get(0);
		
		final int startOfMsgType = fixMessage.indexOf("|35=");
		final String msgType = fixMessage.substring(
			startOfMsgType + "|35=".length(),
			fixMessage.indexOf("|", startOfMsgType + "|35=".length()));
		
		// Order messages
		if(_orderMsgTypes.contains(msgType))
		{
			_orderReplayProcessor.replayOrderMessages(fixMessage, msgType);
		}
		
		// IOI messages
		else if(_IOI_MSG_TYPE.equals(msgType))
		{
			_fixioiReplayProcessor.replayIOIMessages(fixMessage, msgType);
		}
	}
	
}
