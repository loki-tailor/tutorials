package com.mizuhosc.selenium.replay;

public class QuattroOrderID
{
	private final String _rawOrderID;
	
	public QuattroOrderID(final String rawOrderID)
	{
		_rawOrderID = rawOrderID;
	}
	
	public String normalize()
	{
		return _normalize(_rawOrderID);
	}

	private String _normalize(final String originalOrderID)
	{
		return originalOrderID.replaceAll("\\bLSEHub\\b", "LSEHUB");
	}
}
